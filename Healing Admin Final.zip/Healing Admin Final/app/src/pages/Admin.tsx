import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Download, RefreshCw, Lock, Users, LogOut, Radio,
  Edit3, Star, Eye, Plus, Trash2, Save, ChevronDown, ChevronUp, X, Check, Bell, BarChart2, Palette,
  LayoutDashboard, GitBranch, TrendingUp, Settings, Search, MessageCircle, Image, Zap, Link2, Menu
} from 'lucide-react';
import { DEFAULTS as CONTENT_DEFAULTS } from '../hooks/useSiteContent';
import DashboardTab from './admin/DashboardTab';
import CRMTab from './admin/CRMTab';
import ReportsTab from './admin/ReportsTab';
import SettingsTab from './admin/SettingsTab';
import SEOTab from './admin/SEOTab';
import WhatsAppTab from './admin/WhatsAppTab';
import MediaTab from './admin/MediaTab';
import AutomationTab from './admin/AutomationTab';
import IntegrationsTab from './admin/IntegrationsTab';

/* ───── Types ───── */
interface Registration { id: number; name: string; email: string; whatsapp: string; created_at: string; }
interface Testimonial { id: number; name: string; role: string; problem: string; type: string; content: string; image_url: string; sort_order: number; active: boolean; }
interface FAQ { id: number; question: string; answer: string; sort_order: number; }
interface NotifEntry { id: number; name: string; location: string; message: string; time_ago: string; sort_order: number; active: boolean; }
type SiteContent = Record<string, string>;
type AdminTab = 'dashboard' | 'leads' | 'crm' | 'content' | 'social' | 'notifications' | 'tracking' | 'colors' | 'abtests' | 'reports' | 'settings' | 'seo' | 'whatsapp' | 'media' | 'automation' | 'integrations';

/* ───── AB Tests types ───── */
interface ABTestStats {
  id: number; name: string; label: string;
  variant_a_text: string; variant_b_text: string;
  active: boolean; created_at: string;
  impressions_a: string; impressions_b: string;
  conversions_a: string; conversions_b: string;
}

const ADMIN_PASSWORD = 'healing2025';
const AUTO_REFRESH = 30_000;

/* ───── Helpers ───── */
const Field = ({ label, value, onChange, textarea, rows = 3 }: { label: string; value: string; onChange: (v: string) => void; textarea?: boolean; rows?: number }) => (
  <div className="mb-4">
    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">{label}</label>
    {textarea ? (
      <textarea
        rows={rows}
        value={value}
        onChange={e => onChange(e.target.value)}
        className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B] resize-y transition-all"
      />
    ) : (
      <input
        type="text"
        value={value}
        onChange={e => onChange(e.target.value)}
        className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B] transition-all"
      />
    )}
  </div>
);

const SectionCard = ({ title, children }: { title: string; children: React.ReactNode }) => {
  const [open, setOpen] = useState(true);
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm mb-4 overflow-hidden">
      <button
        className="w-full flex items-center justify-between px-5 py-4 text-left hover:bg-gray-50 transition-colors"
        onClick={() => setOpen(o => !o)}
      >
        <span className="font-semibold text-gray-900 text-sm">{title}</span>
        {open ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
      </button>
      {open && <div className="px-5 pb-5 border-t border-gray-100">{children}</div>}
    </div>
  );
};

/* ───── Image Field with upload + URL input + preview ───── */
const ImageField = ({ label, contentKey, value, onChange }: { label: string; contentKey: string; value: string; onChange: (v: string) => void }) => {
  const [uploading, setUploading] = useState(false);
  const [uploadErr, setUploadErr] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true); setUploadErr('');
    const fd = new FormData();
    fd.append('image', file);
    try {
      const res = await fetch('/api/upload', { method: 'POST', body: fd });
      const data = await res.json();
      if (data.url) onChange(data.url);
      else setUploadErr(data.error || 'Upload failed');
    } catch { setUploadErr('Upload failed'); }
    setUploading(false);
    if (inputRef.current) inputRef.current.value = '';
  };

  const displaySrc = value || '';

  return (
    <div className="mb-5 p-4 bg-gray-50 rounded-xl border border-gray-100">
      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">{label}</label>
      <div className="flex gap-4 items-start">
        {/* Preview */}
        <div className="w-24 h-24 flex-shrink-0 rounded-xl overflow-hidden border-2 border-gray-200 bg-gray-100 flex items-center justify-center">
          {displaySrc ? (
            <img src={displaySrc} alt={label} className="w-full h-full object-cover" onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
          ) : (
            <span className="text-gray-300 text-xs text-center px-1">No image</span>
          )}
        </div>
        <div className="flex-1 min-w-0 space-y-2">
          {/* URL input */}
          <input
            type="text"
            value={value}
            onChange={e => onChange(e.target.value)}
            placeholder="Paste image URL or upload below"
            className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B] transition-all bg-white"
          />
          {/* Upload button */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => inputRef.current?.click()}
              disabled={uploading}
              className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-white border border-gray-200 hover:border-[#FF3B6B] hover:text-[#FF3B6B] transition-all cursor-pointer disabled:opacity-60"
            >
              {uploading ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3" />}
              {uploading ? 'Uploading…' : 'Upload Image'}
            </button>
            <span className="text-[10px] text-gray-400">JPG, PNG, WebP · max 10MB</span>
          </div>
          {uploadErr && <p className="text-xs text-red-500">{uploadErr}</p>}
          <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="hidden" onChange={handleFile} />
        </div>
      </div>
    </div>
  );
};

/* ───── Content Editor ───── */
const ContentEditor = () => {
  const [content, setContent] = useState<SiteContent>(CONTENT_DEFAULTS);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch('/api/content')
      .then(r => r.json())
      .then((data: SiteContent) => setContent({ ...CONTENT_DEFAULTS, ...data }))
      .catch(() => {});
  }, []);

  const set = (key: string, val: string) => setContent(c => ({ ...c, [key]: val }));
  const g = (key: string) => content[key] ?? '';

  const saveAll = async () => {
    setSaving(true);
    try {
      await fetch('/api/content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(content) });
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch { /* ignore */ }
    setSaving(false);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-lg font-bold text-gray-900">Content Editor</h2>
        <button
          onClick={saveAll}
          disabled={saving}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${saved ? 'bg-green-500 text-white' : 'bg-[#FF3B6B] hover:bg-[#e02d5a] text-white'} disabled:opacity-60`}
        >
          {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          {saved ? 'Saved!' : saving ? 'Saving…' : 'Save All Changes'}
        </button>
      </div>

      <SectionCard title="🖼️ Images">
        <div className="pt-4">
          <p className="text-xs text-gray-500 mb-4">Upload or paste a URL for each image on the landing page. Changes take effect after saving.</p>
          <ImageField label="Healer Portrait (About Section)" contentKey="about_portrait_url" value={g('about_portrait_url')} onChange={v => set('about_portrait_url', v)} />
          <ImageField label="Certificate Image (About Section)" contentKey="about_cert_url" value={g('about_cert_url')} onChange={v => set('about_cert_url', v)} />
          <ImageField label="Secret Card 1 — Release Emotional Blocks" contentKey="secrets_img_1_url" value={g('secrets_img_1_url')} onChange={v => set('secrets_img_1_url', v)} />
          <ImageField label="Secret Card 2 — Target the Root Cause" contentKey="secrets_img_2_url" value={g('secrets_img_2_url')} onChange={v => set('secrets_img_2_url', v)} />
          <ImageField label="Secret Card 3 — Heal from Anywhere" contentKey="secrets_img_3_url" value={g('secrets_img_3_url')} onChange={v => set('secrets_img_3_url', v)} />
        </div>
      </SectionCard>

      <SectionCard title="📢 Announcement Bar">
        <div className="pt-4">
          <Field label="Announcement Text" value={g('announce_text')} onChange={v => set('announce_text', v)} />
          <Field label="CTA Button Text" value={g('announce_cta')} onChange={v => set('announce_cta', v)} />
        </div>
      </SectionCard>

      <SectionCard title="🦸 Hero Section">
        <div className="pt-4">
          <Field label="Badge Text" value={g('hero_badge')} onChange={v => set('hero_badge', v)} />
          <Field label="Main Headline" value={g('hero_headline')} onChange={v => set('hero_headline', v)} textarea rows={3} />
          <Field label="Highlighted Text (must be part of headline)" value={g('hero_highlighted')} onChange={v => set('hero_highlighted', v)} />
          <Field label="Sub Text" value={g('hero_subtext')} onChange={v => set('hero_subtext', v)} />
          <Field label="CTA Button 1" value={g('hero_cta1')} onChange={v => set('hero_cta1', v)} />
          <Field label="CTA Button 2" value={g('hero_cta2')} onChange={v => set('hero_cta2', v)} />
          <Field label="CTA 2 Subtitle" value={g('hero_cta2_sub')} onChange={v => set('hero_cta2_sub', v)} />
          <Field label="YouTube Video URL (embed)" value={g('hero_video_url')} onChange={v => set('hero_video_url', v)} />
          <Field label="Info Item 1" value={g('hero_info_1')} onChange={v => set('hero_info_1', v)} />
          <Field label="Info Item 2" value={g('hero_info_2')} onChange={v => set('hero_info_2', v)} />
          <Field label="Info Item 3" value={g('hero_info_3')} onChange={v => set('hero_info_3', v)} />
        </div>
      </SectionCard>

      <SectionCard title="👤 About Section">
        <div className="pt-4">
          <Field label="Section Title" value={g('about_title')} onChange={v => set('about_title', v)} />
          <Field label="Paragraph 1" value={g('about_p1')} onChange={v => set('about_p1', v)} textarea rows={3} />
          <Field label="Paragraph 2" value={g('about_p2')} onChange={v => set('about_p2', v)} textarea rows={3} />
          <Field label="Paragraph 3" value={g('about_p3')} onChange={v => set('about_p3', v)} textarea rows={3} />
          <Field label="Achievement Highlight" value={g('about_achievement')} onChange={v => set('about_achievement', v)} textarea rows={2} />
          <Field label="CTA Button Text" value={g('about_cta')} onChange={v => set('about_cta', v)} />
          <Field label="Certificate Title" value={g('about_cert_title')} onChange={v => set('about_cert_title', v)} />
        </div>
      </SectionCard>

      <SectionCard title="⚡ Mid CTA Banner">
        <div className="pt-4">
          <Field label="Headline" value={g('midcta_headline')} onChange={v => set('midcta_headline', v)} />
          <Field label="Subtitle" value={g('midcta_subtitle')} onChange={v => set('midcta_subtitle', v)} />
        </div>
      </SectionCard>

      <SectionCard title="💬 Testimonials Section">
        <div className="pt-4">
          <Field label="Section Title" value={g('testimonials_title')} onChange={v => set('testimonials_title', v)} />
          <Field label="Section Subtitle" value={g('testimonials_subtitle')} onChange={v => set('testimonials_subtitle', v)} textarea rows={2} />
        </div>
      </SectionCard>

      <SectionCard title="❓ FAQ Section">
        <div className="pt-4">
          <Field label="Section Title" value={g('faq_title')} onChange={v => set('faq_title', v)} />
        </div>
      </SectionCard>

      <SectionCard title="🎯 Final CTA Section">
        <div className="pt-4">
          <Field label="Headline" value={g('finalcta_headline')} onChange={v => set('finalcta_headline', v)} textarea rows={2} />
          <Field label="CTA Button Text" value={g('finalcta_cta')} onChange={v => set('finalcta_cta', v)} />
          <Field label="Subtitle" value={g('finalcta_sub')} onChange={v => set('finalcta_sub', v)} />
        </div>
      </SectionCard>

      <SectionCard title="📋 Registration Modal — Form">
        <div className="pt-4">
          <Field label="Modal Title" value={g('modal_title')} onChange={v => set('modal_title', v)} />
          <Field label="Modal Subtitle (e.g. FREE Today)" value={g('modal_subtitle')} onChange={v => set('modal_subtitle', v)} />
          <Field label="Submit Button Text" value={g('modal_submit_text')} onChange={v => set('modal_submit_text', v)} />
          <Field label="Submit Hint Text (below button)" value={g('modal_submit_hint')} onChange={v => set('modal_submit_hint', v)} />
          <Field label="Footer Note (bottom of form)" value={g('modal_footer_text')} onChange={v => set('modal_footer_text', v)} textarea rows={2} />
        </div>
      </SectionCard>

      <SectionCard title="✅ Registration Modal — Success / WhatsApp Screen">
        <div className="pt-4">
          <Field label="Success Title" value={g('modal_success_title')} onChange={v => set('modal_success_title', v)} />
          <Field label="Success Description" value={g('modal_success_desc')} onChange={v => set('modal_success_desc', v)} textarea rows={3} />
          <Field label="WhatsApp Group Button Text" value={g('modal_wa_btn_text')} onChange={v => set('modal_wa_btn_text', v)} />
          <Field label="WhatsApp Group Invite Link" value={g('modal_wa_group_url')} onChange={v => set('modal_wa_group_url', v)} />
          <div className="mb-4">
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Button Gradient Colors</label>
            <div className="flex items-center gap-3 flex-wrap">
              <div className="flex items-center gap-2">
                <input type="color" value={g('modal_wa_btn_color_from') || '#25D366'} onChange={e => set('modal_wa_btn_color_from', e.target.value)} className="w-9 h-9 rounded-lg border border-gray-200 cursor-pointer p-0.5" />
                <span className="text-xs text-gray-500">From</span>
              </div>
              <span className="text-gray-300">→</span>
              <div className="flex items-center gap-2">
                <input type="color" value={g('modal_wa_btn_color_to') || '#128C7E'} onChange={e => set('modal_wa_btn_color_to', e.target.value)} className="w-9 h-9 rounded-lg border border-gray-200 cursor-pointer p-0.5" />
                <span className="text-xs text-gray-500">To</span>
              </div>
              {/* live preview */}
              <div
                className="flex-1 min-w-[120px] h-9 rounded-lg flex items-center justify-center text-white text-xs font-bold shadow-sm gap-2"
                style={{ background: `linear-gradient(135deg, ${g('modal_wa_btn_color_from') || '#25D366'}, ${g('modal_wa_btn_color_to') || '#128C7E'})` }}
              >
                <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                {g('modal_wa_btn_text') || 'Join WhatsApp Group'}
              </div>
            </div>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="🔻 Footer">
        <div className="pt-4">
          <Field label="Copyright Text" value={g('footer_text')} onChange={v => set('footer_text', v)} />
        </div>
      </SectionCard>

      <div className="flex justify-end mt-2">
        <button
          onClick={saveAll}
          disabled={saving}
          className={`flex items-center gap-2 px-6 py-2.5 rounded-lg text-sm font-semibold transition-all cursor-pointer ${saved ? 'bg-green-500 text-white' : 'bg-[#FF3B6B] hover:bg-[#e02d5a] text-white'} disabled:opacity-60`}
        >
          {saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
          {saved ? 'Saved!' : saving ? 'Saving…' : 'Save All Changes'}
        </button>
      </div>
    </div>
  );
};

/* ───── Social Proof Manager ───── */
const emptyTestimonial = (): Partial<Testimonial> => ({ name: '', role: '', problem: '', type: 'text', content: '', image_url: '', sort_order: 0, active: true });
const emptyFAQ = (): Partial<FAQ> => ({ question: '', answer: '', sort_order: 0 });

const SocialProofManager = () => {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [subTab, setSubTab] = useState<'testimonials' | 'faqs'>('testimonials');

  const [tForm, setTForm] = useState<Partial<Testimonial>>(emptyTestimonial());
  const [editTId, setEditTId] = useState<number | null>(null);
  const [showTForm, setShowTForm] = useState(false);

  const [fForm, setFForm] = useState<Partial<FAQ>>(emptyFAQ());
  const [editFId, setEditFId] = useState<number | null>(null);
  const [showFForm, setShowFForm] = useState(false);

  const [msg, setMsg] = useState('');

  const flash = (m: string) => { setMsg(m); setTimeout(() => setMsg(''), 2500); };

  const fetchTestimonials = useCallback(() => {
    fetch('/api/testimonials/all').then(r => r.json()).then(setTestimonials).catch(() => {});
  }, []);

  const fetchFAQs = useCallback(() => {
    fetch('/api/faqs').then(r => r.json()).then(setFaqs).catch(() => {});
  }, []);

  useEffect(() => { fetchTestimonials(); fetchFAQs(); }, [fetchTestimonials, fetchFAQs]);

  /* ── Testimonial CRUD ── */
  const saveTestimonial = async () => {
    const method = editTId ? 'PUT' : 'POST';
    const url = editTId ? `/api/testimonials/${editTId}` : '/api/testimonials';
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(tForm) });
    if (res.ok) { flash('Testimonial saved!'); setShowTForm(false); setEditTId(null); setTForm(emptyTestimonial()); fetchTestimonials(); }
  };

  const deleteTestimonial = async (id: number) => {
    if (!confirm('Delete this testimonial?')) return;
    await fetch(`/api/testimonials/${id}`, { method: 'DELETE' });
    flash('Deleted.'); fetchTestimonials();
  };

  const toggleActive = async (t: Testimonial) => {
    await fetch(`/api/testimonials/${t.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ active: !t.active }) });
    fetchTestimonials();
  };

  const editTestimonial = (t: Testimonial) => {
    setTForm({ name: t.name, role: t.role, problem: t.problem, type: t.type, content: t.content, image_url: t.image_url, sort_order: t.sort_order, active: t.active });
    setEditTId(t.id); setShowTForm(true);
  };

  /* ── FAQ CRUD ── */
  const saveFAQ = async () => {
    const method = editFId ? 'PUT' : 'POST';
    const url = editFId ? `/api/faqs/${editFId}` : '/api/faqs';
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(fForm) });
    if (res.ok) { flash('FAQ saved!'); setShowFForm(false); setEditFId(null); setFForm(emptyFAQ()); fetchFAQs(); }
  };

  const deleteFAQ = async (id: number) => {
    if (!confirm('Delete this FAQ?')) return;
    await fetch(`/api/faqs/${id}`, { method: 'DELETE' });
    flash('Deleted.'); fetchFAQs();
  };

  const editFAQ = (f: FAQ) => {
    setFForm({ question: f.question, answer: f.answer, sort_order: f.sort_order });
    setEditFId(f.id); setShowFForm(true);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-lg font-bold text-gray-900">Social Proof Manager</h2>
        {msg && (
          <span className="text-sm bg-green-100 text-green-700 px-3 py-1 rounded-full font-medium">{msg}</span>
        )}
      </div>

      {/* Sub tabs */}
      <div className="flex gap-2 mb-6 bg-gray-100 rounded-lg p-1 w-fit">
        {(['testimonials', 'faqs'] as const).map(t => (
          <button
            key={t}
            onClick={() => setSubTab(t)}
            className={`px-4 py-2 rounded-md text-sm font-semibold capitalize transition-all cursor-pointer ${subTab === t ? 'bg-white shadow text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}
          >
            {t === 'testimonials' ? '⭐ Testimonials' : '❓ FAQs'}
          </button>
        ))}
      </div>

      {/* ── Testimonials ── */}
      {subTab === 'testimonials' && (
        <div>
          <button
            onClick={() => { setTForm(emptyTestimonial()); setEditTId(null); setShowTForm(true); }}
            className="flex items-center gap-2 mb-4 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold px-4 py-2 rounded-lg transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Add Testimonial
          </button>

          {showTForm && (
            <div className="bg-white border border-gray-200 rounded-xl p-5 mb-5 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-gray-900">{editTId ? 'Edit Testimonial' : 'New Testimonial'}</h3>
                <button onClick={() => setShowTForm(false)} className="text-gray-400 hover:text-gray-600 cursor-pointer"><X className="w-4 h-4" /></button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
                <Field label="Name *" value={tForm.name || ''} onChange={v => setTForm(f => ({ ...f, name: v }))} />
                <Field label="Role / Profession" value={tForm.role || ''} onChange={v => setTForm(f => ({ ...f, role: v }))} />
                <Field label="Problem Solved" value={tForm.problem || ''} onChange={v => setTForm(f => ({ ...f, problem: v }))} />
                <div className="mb-4">
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Type</label>
                  <select
                    value={tForm.type || 'text'}
                    onChange={e => setTForm(f => ({ ...f, type: e.target.value }))}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B]"
                  >
                    <option value="text">Text Review</option>
                    <option value="whatsapp">WhatsApp Chat</option>
                    <option value="image">Image/Photo</option>
                  </select>
                </div>
              </div>
              {(tForm.type === 'text' || tForm.type === 'whatsapp') && (
                <Field label="Message / Review Text" value={tForm.content || ''} onChange={v => setTForm(f => ({ ...f, content: v }))} textarea rows={3} />
              )}
              {tForm.type === 'image' && (
                <Field label="Image URL (e.g. /images/testimonial-3.jpg)" value={tForm.image_url || ''} onChange={v => setTForm(f => ({ ...f, image_url: v }))} />
              )}
              <Field label="Sort Order (lower = first)" value={String(tForm.sort_order ?? 0)} onChange={v => setTForm(f => ({ ...f, sort_order: Number(v) }))} />
              <div className="flex gap-2 mt-2">
                <button
                  onClick={saveTestimonial}
                  className="flex items-center gap-2 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold px-4 py-2 rounded-lg transition-all cursor-pointer"
                >
                  <Save className="w-4 h-4" /> Save
                </button>
                <button onClick={() => setShowTForm(false)} className="px-4 py-2 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 cursor-pointer">Cancel</button>
              </div>
            </div>
          )}

          <div className="space-y-3">
            {testimonials.map(t => (
              <div key={t.id} className={`bg-white rounded-xl border p-4 flex items-center gap-4 shadow-sm ${!t.active ? 'opacity-50' : 'border-gray-200'}`}>
                <div className="w-10 h-10 rounded-full bg-[#FF3B6B]/10 flex items-center justify-center flex-shrink-0 text-[#FF3B6B] font-bold">
                  {t.name.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold text-gray-900 text-sm">{t.name}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${t.type === 'image' ? 'bg-blue-100 text-blue-700' : t.type === 'whatsapp' ? 'bg-green-100 text-green-700' : 'bg-purple-100 text-purple-700'}`}>
                      {t.type}
                    </span>
                    {!t.active && <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-gray-100 text-gray-500">hidden</span>}
                  </div>
                  {t.problem && <p className="text-xs text-[#FF3B6B] mt-0.5">✓ {t.problem}</p>}
                  {t.content && <p className="text-xs text-gray-500 mt-1 truncate max-w-xs">{t.content}</p>}
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button onClick={() => toggleActive(t)} title={t.active ? 'Hide' : 'Show'} className="p-1.5 rounded-lg hover:bg-gray-100 cursor-pointer text-gray-400 hover:text-gray-700 transition-colors">
                    <Eye className="w-4 h-4" />
                  </button>
                  <button onClick={() => editTestimonial(t)} className="p-1.5 rounded-lg hover:bg-blue-50 cursor-pointer text-gray-400 hover:text-blue-600 transition-colors">
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button onClick={() => deleteTestimonial(t.id)} className="p-1.5 rounded-lg hover:bg-red-50 cursor-pointer text-gray-400 hover:text-red-500 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
            {testimonials.length === 0 && (
              <div className="text-center py-12 text-gray-400 text-sm">No testimonials yet. Add one above.</div>
            )}
          </div>
        </div>
      )}

      {/* ── FAQs ── */}
      {subTab === 'faqs' && (
        <div>
          <button
            onClick={() => { setFForm(emptyFAQ()); setEditFId(null); setShowFForm(true); }}
            className="flex items-center gap-2 mb-4 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold px-4 py-2 rounded-lg transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Add FAQ
          </button>

          {showFForm && (
            <div className="bg-white border border-gray-200 rounded-xl p-5 mb-5 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <h3 className="font-semibold text-gray-900">{editFId ? 'Edit FAQ' : 'New FAQ'}</h3>
                <button onClick={() => setShowFForm(false)} className="text-gray-400 hover:text-gray-600 cursor-pointer"><X className="w-4 h-4" /></button>
              </div>
              <Field label="Question *" value={fForm.question || ''} onChange={v => setFForm(f => ({ ...f, question: v }))} />
              <Field label="Answer *" value={fForm.answer || ''} onChange={v => setFForm(f => ({ ...f, answer: v }))} textarea rows={4} />
              <Field label="Sort Order (lower = first)" value={String(fForm.sort_order ?? 0)} onChange={v => setFForm(f => ({ ...f, sort_order: Number(v) }))} />
              <div className="flex gap-2 mt-2">
                <button
                  onClick={saveFAQ}
                  className="flex items-center gap-2 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold px-4 py-2 rounded-lg transition-all cursor-pointer"
                >
                  <Save className="w-4 h-4" /> Save
                </button>
                <button onClick={() => setShowFForm(false)} className="px-4 py-2 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 cursor-pointer">Cancel</button>
              </div>
            </div>
          )}

          <div className="space-y-3">
            {faqs.map((f, i) => (
              <div key={f.id} className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
                <div className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-[#FF3B6B]/10 text-[#FF3B6B] text-xs font-bold flex items-center justify-center flex-shrink-0 mt-0.5">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm">{f.question}</p>
                    <p className="text-gray-500 text-xs mt-1 line-clamp-2">{f.answer}</p>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                    <button onClick={() => editFAQ(f)} className="p-1.5 rounded-lg hover:bg-blue-50 cursor-pointer text-gray-400 hover:text-blue-600 transition-colors">
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button onClick={() => deleteFAQ(f.id)} className="p-1.5 rounded-lg hover:bg-red-50 cursor-pointer text-gray-400 hover:text-red-500 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
            {faqs.length === 0 && (
              <div className="text-center py-12 text-gray-400 text-sm">No FAQs yet. Add one above.</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

/* ───── Live Preview ───── */
const LivePreview = () => {
  const [key, setKey] = useState(0);
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold text-gray-900">Live Preview</h2>
        <button
          onClick={() => setKey(k => k + 1)}
          className="flex items-center gap-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-semibold px-4 py-2 rounded-lg transition-all cursor-pointer"
        >
          <RefreshCw className="w-4 h-4" /> Refresh Preview
        </button>
      </div>
      <p className="text-sm text-gray-500 mb-3">This shows your live landing page. After saving changes, click "Refresh Preview" to see them.</p>
      <div className="rounded-xl overflow-hidden border border-gray-200 shadow-sm" style={{ height: 'calc(100vh - 220px)' }}>
        <iframe
          key={key}
          src="/"
          title="Landing Page Preview"
          className="w-full h-full"
          style={{ border: 'none' }}
        />
      </div>
    </div>
  );
};

/* ───── Leads Table ───── */
const LeadsTable = () => {
  const [registrations, setRegistrations] = useState<Registration[]>([]);
  const [newIds, setNewIds] = useState<Set<number>>(new Set());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastRefreshed, setLastRefreshed] = useState<Date | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [countdown, setCountdown] = useState(AUTO_REFRESH / 1000);
  const knownIdsRef = useRef<Set<number>>(new Set());
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchRegistrations = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/registrations');
      if (!res.ok) throw new Error('Failed to load registrations');
      const data: Registration[] = await res.json();
      if (knownIdsRef.current.size > 0) {
        const freshIds = new Set<number>();
        for (const r of data) { if (!knownIdsRef.current.has(r.id)) freshIds.add(r.id); }
        if (freshIds.size > 0) {
          setNewIds(prev => new Set([...prev, ...freshIds]));
          setTimeout(() => setNewIds(prev => { const next = new Set(prev); freshIds.forEach(id => next.delete(id)); return next; }), 8000);
        }
      }
      knownIdsRef.current = new Set(data.map(r => r.id));
      setRegistrations(data); setLastRefreshed(new Date());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally { if (!silent) setLoading(false); }
  }, []);

  useEffect(() => { fetchRegistrations(); }, [fetchRegistrations]);

  const startPolling = useCallback(() => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    if (countdownRef.current) clearInterval(countdownRef.current);
    setCountdown(AUTO_REFRESH / 1000);
    intervalRef.current = setInterval(() => { fetchRegistrations(true); setCountdown(AUTO_REFRESH / 1000); }, AUTO_REFRESH);
    countdownRef.current = setInterval(() => { setCountdown(prev => prev <= 1 ? AUTO_REFRESH / 1000 : prev - 1); }, 1000);
  }, [fetchRegistrations]);

  const stopPolling = useCallback(() => {
    if (intervalRef.current) { clearInterval(intervalRef.current); intervalRef.current = null; }
    if (countdownRef.current) { clearInterval(countdownRef.current); countdownRef.current = null; }
  }, []);

  useEffect(() => { if (autoRefresh) startPolling(); else stopPolling(); return stopPolling; }, [autoRefresh, startPolling, stopPolling]);

  const downloadCSV = () => {
    const headers = ['ID', 'Name', 'Email', 'WhatsApp', 'Registered At'];
    const rows = registrations.map(r => [r.id, `"${r.name.replace(/"/g, '""')}"`, `"${r.email.replace(/"/g, '""')}"`, `"${r.whatsapp.replace(/"/g, '""')}"`, `"${new Date(r.created_at).toLocaleString()}"`]);
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `leads-${new Date().toISOString().slice(0, 10)}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <div className="mb-5 flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <span className="text-2xl font-bold text-gray-900">{registrations.length}</span>
          <span className="text-gray-500 text-sm">total leads</span>
          {newIds.size > 0 && <span className="ml-1 bg-green-500 text-white text-xs font-semibold px-2 py-0.5 rounded-full animate-pulse">+{newIds.size} new</span>}
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setAutoRefresh(v => !v)} className={`flex items-center gap-1.5 text-sm px-3 py-2 rounded-lg transition-all cursor-pointer font-medium ${autoRefresh ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
            <Radio className={`w-4 h-4 ${autoRefresh ? 'animate-pulse' : ''}`} />
            {autoRefresh ? `Live · ${countdown}s` : 'Live Off'}
          </button>
          <button onClick={() => fetchRegistrations()} disabled={loading} className="flex items-center gap-1.5 text-sm text-gray-600 bg-gray-100 hover:bg-gray-200 px-3 py-2 rounded-lg cursor-pointer disabled:opacity-50">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Refresh
          </button>
          <button onClick={downloadCSV} disabled={registrations.length === 0} className="flex items-center gap-1.5 text-sm text-white bg-[#28A745] hover:bg-[#218838] px-3 py-2 rounded-lg cursor-pointer disabled:opacity-50">
            <Download className="w-4 h-4" /> CSV
          </button>
        </div>
      </div>
      {lastRefreshed && <p className="text-xs text-gray-400 mb-4">Updated {lastRefreshed.toLocaleTimeString()}{autoRefresh && <span className="ml-1 text-green-500">· live</span>}</p>}
      {error && <div className="mb-4 bg-red-50 border border-red-200 rounded-lg px-4 py-3 text-red-600 text-sm">{error}</div>}
      {loading && registrations.length === 0 ? (
        <div className="text-center py-20 text-gray-400">Loading…</div>
      ) : registrations.length === 0 ? (
        <div className="text-center py-20 text-gray-400"><Users className="w-10 h-10 mx-auto mb-3 opacity-30" /><p className="text-sm">No registrations yet.</p></div>
      ) : (
        <div className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  {['#', 'Name', 'Email', 'WhatsApp', 'Registered'].map(h => (
                    <th key={h} className="text-left px-4 py-3 font-semibold text-gray-600 text-xs uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {registrations.map((r, i) => {
                  const isNew = newIds.has(r.id);
                  return (
                    <tr key={r.id} className={`border-b border-gray-100 ${i === registrations.length - 1 ? 'border-0' : ''} ${isNew ? 'bg-green-50' : 'hover:bg-gray-50'}`}>
                      <td className="px-4 py-3 text-gray-400 font-mono text-xs">
                        {isNew && <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-1.5 animate-pulse" />}
                        {r.id}
                      </td>
                      <td className="px-4 py-3 font-medium text-gray-900">
                        {r.name}
                        {isNew && <span className="ml-2 text-[10px] bg-green-100 text-green-700 font-semibold px-1.5 py-0.5 rounded-full uppercase">New</span>}
                      </td>
                      <td className="px-4 py-3 text-gray-600">{r.email}</td>
                      <td className="px-4 py-3 text-gray-600">
                        <a href={`https://wa.me/91${r.whatsapp.replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer" className="text-green-600 hover:underline">{r.whatsapp}</a>
                      </td>
                      <td className="px-4 py-3 text-gray-400 text-xs">
                        {new Date(r.created_at).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

/* ───── Notifications Manager ───── */
const emptyNotif = (): Partial<NotifEntry> => ({ name: '', location: '', message: 'Registered to Healing Workshop', time_ago: 'just now', sort_order: 0, active: true });

const NotificationsManager: React.FC = () => {
  const [entries, setEntries] = useState<NotifEntry[]>([]);
  const [settings, setSettings] = useState<SiteContent>({});
  const [form, setForm] = useState<Partial<NotifEntry>>(emptyNotif());
  const [editId, setEditId] = useState<number | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [msg, setMsg] = useState('');
  const [settingsSaved, setSettingsSaved] = useState(false);

  const flash = (m: string) => { setMsg(m); setTimeout(() => setMsg(''), 2500); };

  const fetchAll = useCallback(() => {
    fetch('/api/notifications/all').then(r => r.json()).then(setEntries).catch(() => {});
    fetch('/api/content').then(r => r.json()).then((d: SiteContent) => {
      setSettings({
        notif_enabled: d.notif_enabled ?? 'true',
        notif_initial_delay: d.notif_initial_delay ?? '3',
        notif_show_duration: d.notif_show_duration ?? '4',
        notif_gap: d.notif_gap ?? '2',
        notif_icon_color_from: d.notif_icon_color_from ?? '#FF3B6B',
        notif_icon_color_to: d.notif_icon_color_to ?? '#FF6B8A',
        notif_source_name: d.notif_source_name ?? 'FlexiFunnels',
        notif_position: d.notif_position ?? 'bottom-left',
      });
    }).catch(() => {});
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  const saveSettings = async () => {
    await fetch('/api/content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(settings) });
    setSettingsSaved(true); setTimeout(() => setSettingsSaved(false), 2500);
  };

  const saveEntry = async () => {
    const method = editId ? 'PUT' : 'POST';
    const url = editId ? `/api/notifications/${editId}` : '/api/notifications';
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    if (res.ok) { flash('Saved!'); setShowForm(false); setEditId(null); setForm(emptyNotif()); fetchAll(); }
  };

  const deleteEntry = async (id: number) => {
    if (!confirm('Delete this notification?')) return;
    await fetch(`/api/notifications/${id}`, { method: 'DELETE' });
    flash('Deleted.'); fetchAll();
  };

  const toggleActive = async (n: NotifEntry) => {
    await fetch(`/api/notifications/${n.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ active: !n.active }) });
    fetchAll();
  };

  const editEntry = (n: NotifEntry) => {
    setForm({ name: n.name, location: n.location, message: n.message, time_ago: n.time_ago, sort_order: n.sort_order, active: n.active });
    setEditId(n.id); setShowForm(true);
  };

  const setSetting = (key: string, val: string) => setSettings(s => ({ ...s, [key]: val }));

  // Live preview of notification
  const previewFrom = settings.notif_icon_color_from || '#FF3B6B';
  const previewTo = settings.notif_icon_color_to || '#FF6B8A';

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-lg font-bold text-gray-900">Notification Popups</h2>
        {msg && <span className="text-sm bg-green-100 text-green-700 px-3 py-1 rounded-full font-medium">{msg}</span>}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Settings Panel */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Bell className="w-4 h-4 text-[#FF3B6B]" /> Notification Settings
          </h3>

          {/* Enable/disable */}
          <div className="flex items-center justify-between mb-4 p-3 bg-gray-50 rounded-lg">
            <div>
              <p className="text-sm font-semibold text-gray-900">Enable Notifications</p>
              <p className="text-xs text-gray-500">Show popup on the landing page</p>
            </div>
            <button
              onClick={() => setSetting('notif_enabled', settings.notif_enabled === 'true' ? 'false' : 'true')}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${settings.notif_enabled === 'true' ? 'bg-[#FF3B6B]' : 'bg-gray-300'}`}
            >
              <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${settings.notif_enabled === 'true' ? 'translate-x-6' : 'translate-x-1'}`} />
            </button>
          </div>

          {/* Timing */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            {[
              { key: 'notif_initial_delay', label: 'Initial Delay', hint: 'seconds before first show' },
              { key: 'notif_show_duration', label: 'Show Duration', hint: 'seconds visible' },
              { key: 'notif_gap', label: 'Gap Between', hint: 'seconds between each' },
            ].map(({ key, label, hint }) => (
              <div key={key}>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">{label}</label>
                <div className="relative">
                  <input
                    type="number" min="1" max="60"
                    value={settings[key] || ''}
                    onChange={e => setSetting(key, e.target.value)}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm pr-8 focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B]"
                  />
                  <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-gray-400">s</span>
                </div>
                <p className="text-[10px] text-gray-400 mt-0.5">{hint}</p>
              </div>
            ))}
          </div>

          {/* Design */}
          <div className="mb-4">
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Icon Gradient Colors</label>
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <input type="color" value={settings.notif_icon_color_from || '#FF3B6B'} onChange={e => setSetting('notif_icon_color_from', e.target.value)} className="w-9 h-9 rounded-lg border border-gray-200 cursor-pointer p-0.5" />
                <span className="text-xs text-gray-500">From</span>
              </div>
              <span className="text-gray-300">→</span>
              <div className="flex items-center gap-2">
                <input type="color" value={settings.notif_icon_color_to || '#FF6B8A'} onChange={e => setSetting('notif_icon_color_to', e.target.value)} className="w-9 h-9 rounded-lg border border-gray-200 cursor-pointer p-0.5" />
                <span className="text-xs text-gray-500">To</span>
              </div>
              {/* Live color preview */}
              <div className="w-9 h-9 rounded-full flex-shrink-0 ml-2 shadow-sm" style={{ background: `linear-gradient(135deg, ${previewFrom}, ${previewTo})` }} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Source Name</label>
              <input type="text" value={settings.notif_source_name || ''} onChange={e => setSetting('notif_source_name', e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B]" placeholder="e.g. FlexiFunnels" />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Position</label>
              <select value={settings.notif_position || 'bottom-left'} onChange={e => setSetting('notif_position', e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B]">
                <option value="bottom-left">Bottom Left</option>
                <option value="bottom-right">Bottom Right</option>
              </select>
            </div>
          </div>

          <button onClick={saveSettings}
            className={`w-full flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer ${settingsSaved ? 'bg-green-500 text-white' : 'bg-[#FF3B6B] hover:bg-[#e02d5a] text-white'}`}>
            {settingsSaved ? <><Check className="w-4 h-4" /> Saved!</> : <><Save className="w-4 h-4" /> Save Settings</>}
          </button>
        </div>

        {/* Live Preview */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Live Preview</h3>
          <div className="bg-gray-100 rounded-xl p-6 flex items-end justify-start min-h-[220px] relative">
            <p className="absolute top-4 left-1/2 -translate-x-1/2 text-xs text-gray-400">Landing page area</p>
            <div className="bg-white rounded-xl shadow-[0_4px_24px_rgba(0,0,0,0.18)] p-3 flex items-center gap-3 border border-gray-100 max-w-[280px]">
              <div className="w-11 h-11 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm"
                style={{ background: `linear-gradient(135deg, ${previewFrom}, ${previewTo})` }}>
                <span className="text-white text-lg">🔥</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[13px] font-semibold text-gray-900 truncate">
                  {entries[0]?.name || 'Ashish Gupta'}{entries[0]?.location ? `, ${entries[0].location}` : ', Maharashtra'}
                </p>
                <p className="text-xs text-gray-500 truncate">{entries[0]?.message || 'Registered to Healing Workshop'}</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-[11px] text-gray-400">{entries[0]?.time_ago || '1 year ago'}</span>
                  {settings.notif_source_name && (
                    <span className="text-[11px] text-gray-400 flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-green-500 inline-block" />
                      {settings.notif_source_name}
                    </span>
                  )}
                </div>
              </div>
              <div className="p-1 rounded-full text-gray-300 ml-1"><X className="w-3.5 h-3.5" /></div>
            </div>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2 text-center">
            <div className="bg-gray-50 rounded-lg p-2">
              <p className="text-lg font-bold text-[#FF3B6B]">{settings.notif_initial_delay || 3}s</p>
              <p className="text-[10px] text-gray-400">First appears</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-2">
              <p className="text-lg font-bold text-[#FF3B6B]">{settings.notif_show_duration || 4}s</p>
              <p className="text-[10px] text-gray-400">Stays visible</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-2">
              <p className="text-lg font-bold text-[#FF3B6B]">{settings.notif_gap || 2}s</p>
              <p className="text-[10px] text-gray-400">Gap between</p>
            </div>
          </div>
        </div>
      </div>

      {/* Entries List */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-gray-900">Notification Entries ({entries.length})</h3>
          <button onClick={() => { setForm(emptyNotif()); setEditId(null); setShowForm(true); }}
            className="flex items-center gap-2 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold px-4 py-2 rounded-lg transition-all cursor-pointer">
            <Plus className="w-4 h-4" /> Add Entry
          </button>
        </div>

        {showForm && (
          <div className="border border-gray-200 rounded-xl p-4 mb-4 bg-gray-50">
            <div className="flex justify-between items-center mb-3">
              <h4 className="font-semibold text-gray-900 text-sm">{editId ? 'Edit Entry' : 'New Entry'}</h4>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-600 cursor-pointer"><X className="w-4 h-4" /></button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
              <Field label="Name *" value={form.name || ''} onChange={v => setForm(f => ({ ...f, name: v }))} />
              <Field label="Location (e.g. Maharashtra)" value={form.location || ''} onChange={v => setForm(f => ({ ...f, location: v }))} />
              <Field label="Message" value={form.message || ''} onChange={v => setForm(f => ({ ...f, message: v }))} />
              <Field label="Time Ago (e.g. 2 days ago)" value={form.time_ago || ''} onChange={v => setForm(f => ({ ...f, time_ago: v }))} />
              <Field label="Sort Order" value={String(form.sort_order ?? 0)} onChange={v => setForm(f => ({ ...f, sort_order: Number(v) }))} />
            </div>
            <div className="flex gap-2">
              <button onClick={saveEntry} className="flex items-center gap-2 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold px-4 py-2 rounded-lg cursor-pointer">
                <Save className="w-4 h-4" /> Save
              </button>
              <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-100 cursor-pointer">Cancel</button>
            </div>
          </div>
        )}

        <div className="space-y-2">
          {entries.map((n, i) => (
            <div key={n.id} className={`flex items-center gap-3 p-3 rounded-xl border transition-colors ${n.active ? 'border-gray-100 bg-white hover:bg-gray-50' : 'border-gray-100 bg-gray-50 opacity-50'}`}>
              <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-white text-xs font-bold shadow-sm"
                style={{ background: `linear-gradient(135deg, ${previewFrom}, ${previewTo})` }}>
                {i + 1}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-gray-900 truncate">{n.name}{n.location ? `, ${n.location}` : ''}</p>
                <p className="text-xs text-gray-500 truncate">{n.message} · <span className="text-gray-400">{n.time_ago}</span></p>
              </div>
              <div className="flex items-center gap-1 flex-shrink-0">
                <button onClick={() => toggleActive(n)} title={n.active ? 'Hide' : 'Show'}
                  className={`p-1.5 rounded-lg cursor-pointer transition-colors ${n.active ? 'text-green-500 hover:bg-green-50' : 'text-gray-300 hover:bg-gray-100'}`}>
                  <Eye className="w-4 h-4" />
                </button>
                <button onClick={() => editEntry(n)} className="p-1.5 rounded-lg hover:bg-blue-50 cursor-pointer text-gray-400 hover:text-blue-600 transition-colors">
                  <Edit3 className="w-4 h-4" />
                </button>
                <button onClick={() => deleteEntry(n.id)} className="p-1.5 rounded-lg hover:bg-red-50 cursor-pointer text-gray-400 hover:text-red-500 transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
          {entries.length === 0 && <div className="text-center py-10 text-gray-400 text-sm">No entries. Add one above.</div>}
        </div>
      </div>
    </div>
  );
};

/* ───── Tracking Manager ───── */
const TrackingManager: React.FC = () => {
  const [settings, setSettings] = useState<SiteContent>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch('/api/content').then(r => r.json()).then((d: SiteContent) => {
      setSettings({
        fb_pixel_id: d.fb_pixel_id ?? '',
        fb_pixel_enabled: d.fb_pixel_enabled ?? 'false',
        ga_id: d.ga_id ?? '',
        ga_enabled: d.ga_enabled ?? 'false',
        custom_head_code: d.custom_head_code ?? '',
        custom_head_enabled: d.custom_head_enabled ?? 'false',
      });
    }).catch(() => {});
  }, []);

  const set = (key: string, val: string) => setSettings(s => ({ ...s, [key]: val }));
  const toggle = (key: string) => setSettings(s => ({ ...s, [key]: s[key] === 'true' ? 'false' : 'true' }));

  const save = async () => {
    setSaving(true);
    await fetch('/api/content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(settings) });
    setSaved(true); setTimeout(() => setSaved(false), 2500); setSaving(false);
  };

  const Toggle = ({ k, label, hint }: { k: string; label: string; hint: string }) => (
    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg mb-3">
      <div>
        <p className="text-sm font-semibold text-gray-900">{label}</p>
        <p className="text-xs text-gray-500">{hint}</p>
      </div>
      <button onClick={() => toggle(k)}
        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer flex-shrink-0 ml-3 ${settings[k] === 'true' ? 'bg-[#FF3B6B]' : 'bg-gray-300'}`}>
        <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${settings[k] === 'true' ? 'translate-x-6' : 'translate-x-1'}`} />
      </button>
    </div>
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Tracking & Analytics</h2>
          <p className="text-sm text-gray-500 mt-0.5">Paste your IDs below — scripts inject automatically on the landing page.</p>
        </div>
        <button onClick={save} disabled={saving}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer disabled:opacity-60 ${saved ? 'bg-green-500 text-white' : 'bg-[#FF3B6B] hover:bg-[#e02d5a] text-white'}`}>
          {saved ? <><Check className="w-4 h-4" /> Saved!</> : <><Save className="w-4 h-4" />{saving ? 'Saving…' : 'Save'}</>}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">

        {/* Facebook Pixel */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: '#1877F2' }}>
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white"><path d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.41c0-3.025 1.792-4.697 4.533-4.697 1.312 0 2.686.236 2.686.236v2.97h-1.513c-1.491 0-1.956.93-1.956 1.886v2.267h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z"/></svg>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Facebook Pixel</h3>
              <p className="text-xs text-gray-500">Track visitors & conversions from Facebook Ads</p>
            </div>
          </div>
          <Toggle k="fb_pixel_enabled" label="Enable Facebook Pixel" hint="Inject pixel script on landing page" />
          <div className={settings.fb_pixel_enabled === 'true' ? '' : 'opacity-50 pointer-events-none'}>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Pixel ID</label>
            <input type="text" value={settings.fb_pixel_id || ''} onChange={e => set('fb_pixel_id', e.target.value)}
              placeholder="e.g. 1234567890123456"
              className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B] transition-all" />
            <p className="text-xs text-gray-400 mt-1.5">Find it in Events Manager → Your Pixel → Settings</p>
          </div>
          {settings.fb_pixel_enabled === 'true' && settings.fb_pixel_id && (
            <div className="mt-3 flex items-center gap-2 text-xs text-green-700 bg-green-50 rounded-lg px-3 py-2">
              <Check className="w-3.5 h-3.5 flex-shrink-0" /> Pixel <strong>{settings.fb_pixel_id}</strong> is active
            </div>
          )}
        </div>

        {/* Google Analytics */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: '#E37400' }}>
              <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white"><path d="M22.84 0H1.16C.52 0 0 .52 0 1.16v21.68C0 23.48.52 24 1.16 24h21.68c.64 0 1.16-.52 1.16-1.16V1.16C24 .52 23.48 0 22.84 0zm-6.07 18.29c0 .85-.69 1.54-1.54 1.54s-1.54-.69-1.54-1.54V9.54c0-.85.69-1.54 1.54-1.54s1.54.69 1.54 1.54v8.75zm-5.54 0c0 .85-.69 1.54-1.54 1.54s-1.54-.69-1.54-1.54v-4.04c0-.85.69-1.54 1.54-1.54s1.54.69 1.54 1.54v4.04zm-5.54 0c0 .85-.69 1.54-1.54 1.54S2.67 19.14 2.67 18.29v-1.25c0-.85.69-1.54 1.54-1.54s1.54.69 1.54 1.54v1.25z"/></svg>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">Google Analytics 4</h3>
              <p className="text-xs text-gray-500">Track traffic, sessions & user behaviour</p>
            </div>
          </div>
          <Toggle k="ga_enabled" label="Enable Google Analytics" hint="Inject GA4 script on landing page" />
          <div className={settings.ga_enabled === 'true' ? '' : 'opacity-50 pointer-events-none'}>
            <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Measurement ID</label>
            <input type="text" value={settings.ga_id || ''} onChange={e => set('ga_id', e.target.value)}
              placeholder="e.g. G-XXXXXXXXXX"
              className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B] transition-all" />
            <p className="text-xs text-gray-400 mt-1.5">Find it in GA4 Admin → Data Streams → your stream</p>
          </div>
          {settings.ga_enabled === 'true' && settings.ga_id && (
            <div className="mt-3 flex items-center gap-2 text-xs text-green-700 bg-green-50 rounded-lg px-3 py-2">
              <Check className="w-3.5 h-3.5 flex-shrink-0" /> Tracking ID <strong>{settings.ga_id}</strong> is active
            </div>
          )}
        </div>
      </div>

      {/* Custom Head Code */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gray-800 flex items-center justify-center flex-shrink-0">
            <span className="text-white text-sm font-mono font-bold">&lt;/&gt;</span>
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Custom Head Code</h3>
            <p className="text-xs text-gray-500">Add any custom script or meta tag (injected into &lt;head&gt;)</p>
          </div>
        </div>
        <Toggle k="custom_head_enabled" label="Enable Custom Code" hint="Inject custom code into page head" />
        <div className={settings.custom_head_enabled === 'true' ? '' : 'opacity-50 pointer-events-none'}>
          <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Custom &lt;head&gt; Code</label>
          <textarea
            rows={6}
            value={settings.custom_head_code || ''}
            onChange={e => set('custom_head_code', e.target.value)}
            placeholder={'<!-- Example: Google Tag Manager, Hotjar, Clarity, etc. -->\n<script>\n  // your code here\n</script>'}
            className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B] resize-y transition-all"
          />
          <p className="text-xs text-gray-400 mt-1.5">⚠️ Only paste code from trusted sources. Incorrect code can break the page.</p>
        </div>
      </div>

      {/* How it works info box */}
      <div className="mt-4 bg-blue-50 border border-blue-100 rounded-xl p-4 flex gap-3">
        <BarChart2 className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-blue-800">
          <p className="font-semibold mb-1">How tracking works</p>
          <ul className="text-xs text-blue-700 space-y-1 list-disc list-inside">
            <li>Scripts are injected automatically when enabled — no code editing needed.</li>
            <li>Only runs on the landing page (<code className="bg-blue-100 px-1 rounded">/</code>), never on the admin panel.</li>
            <li>Changes take effect immediately after saving.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

/* ───── A/B Tests Manager ───── */
const AB_PRESET_NAMES = [
  { value: 'hero_headline', label: 'Hero Headline' },
  { value: 'hero_cta1', label: 'Hero Primary CTA Button' },
  { value: 'hero_cta2', label: 'Hero Secondary CTA Button' },
  { value: 'announce_text', label: 'Announcement Bar Text' },
  { value: 'hero_badge', label: 'Hero Badge Text' },
];

const ABTestsManager: React.FC = () => {
  const [tests, setTests] = useState<ABTestStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ name: 'hero_headline', label: '', variant_a_text: '', variant_b_text: '' });
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch('/api/ab-tests');
      setTests(await r.json());
    } catch { /* ignore */ }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const create = async () => {
    if (!form.variant_a_text || !form.variant_b_text) return;
    setSaving(true);
    try {
      await fetch('/api/ab-tests', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
      setCreating(false);
      setForm({ name: 'hero_headline', label: '', variant_a_text: '', variant_b_text: '' });
      load();
    } catch { /* ignore */ }
    setSaving(false);
  };

  const toggleActive = async (test: ABTestStats) => {
    await fetch(`/api/ab-tests/${test.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ active: !test.active }) });
    load();
  };

  const deleteTest = async (id: number) => {
    if (!confirm('Delete this test and all its event data?')) return;
    await fetch(`/api/ab-tests/${id}`, { method: 'DELETE' });
    load();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-bold text-gray-900">A/B Tests</h2>
          <p className="text-sm text-gray-500 mt-0.5">Split visitors 50/50 between two text variants. Conversions are tracked when someone registers.</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={load} className="p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-all cursor-pointer"><RefreshCw className="w-4 h-4" /></button>
          <button onClick={() => setCreating(true)} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold transition-all cursor-pointer"><Plus className="w-4 h-4" /> New Test</button>
        </div>
      </div>

      {creating && (
        <div className="bg-white border border-gray-200 rounded-xl shadow-sm p-5 mb-6">
          <h3 className="font-semibold text-gray-900 mb-4">Create A/B Test</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1.5">What to test</label>
              <select value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#FF3B6B] bg-white">
                {AB_PRESET_NAMES.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1.5">Test label (optional)</label>
              <input type="text" placeholder="e.g. Headline Aug 2025" value={form.label}
                onChange={e => setForm(f => ({ ...f, label: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#FF3B6B]" />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1.5">Variant A — Control</label>
              <textarea rows={3} placeholder="Original / current text…" value={form.variant_a_text}
                onChange={e => setForm(f => ({ ...f, variant_a_text: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#FF3B6B] resize-none" />
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1.5">Variant B — Challenger</label>
              <textarea rows={3} placeholder="Alternative text to test…" value={form.variant_b_text}
                onChange={e => setForm(f => ({ ...f, variant_b_text: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#FF3B6B] resize-none" />
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={create} disabled={saving || !form.variant_a_text || !form.variant_b_text}
              className="px-4 py-2 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white rounded-lg text-sm font-semibold transition-all disabled:opacity-60 cursor-pointer">
              {saving ? 'Creating…' : 'Create Test'}
            </button>
            <button onClick={() => setCreating(false)} className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-sm font-semibold transition-all cursor-pointer">Cancel</button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="text-center text-gray-400 py-16 text-sm">Loading…</div>
      ) : tests.length === 0 ? (
        <div className="bg-white border-2 border-dashed border-gray-200 rounded-xl p-14 text-center">
          <Radio className="w-8 h-8 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500 font-semibold">No A/B tests yet</p>
          <p className="text-gray-400 text-sm mt-1">Create your first test to start discovering which copy converts better.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {tests.map(test => {
            const impA = parseInt(test.impressions_a) || 0;
            const impB = parseInt(test.impressions_b) || 0;
            const convA = parseInt(test.conversions_a) || 0;
            const convB = parseInt(test.conversions_b) || 0;
            const rateA = impA > 0 ? ((convA / impA) * 100).toFixed(1) : null;
            const rateB = impB > 0 ? ((convB / impB) * 100).toFixed(1) : null;
            const enoughData = impA >= 5 && impB >= 5;
            const winnerA = enoughData && rateA !== null && rateB !== null && parseFloat(rateA) > parseFloat(rateB);
            const winnerB = enoughData && rateA !== null && rateB !== null && parseFloat(rateB) > parseFloat(rateA);
            return (
              <div key={test.id} className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
                <div className="p-4 flex items-center justify-between gap-4 border-b border-gray-100">
                  <div className="flex items-center gap-3 min-w-0">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold ${test.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                      {test.active ? '● Live' : '◌ Paused'}
                    </span>
                    <div className="min-w-0">
                      <p className="font-semibold text-gray-900 text-sm">{test.label || AB_PRESET_NAMES.find(p => p.value === test.name)?.label || test.name}</p>
                      <p className="text-xs text-gray-400 font-mono">{test.name}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button onClick={() => toggleActive(test)}
                      className="px-3 py-1.5 text-xs font-semibold rounded-lg border border-gray-200 hover:border-gray-300 transition-all cursor-pointer text-gray-600 hover:bg-gray-50">
                      {test.active ? 'Pause' : 'Resume'}
                    </button>
                    <button onClick={() => deleteTest(test.id)}
                      className="p-1.5 text-gray-400 hover:text-red-500 transition-colors cursor-pointer rounded-lg hover:bg-red-50">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-2 divide-x divide-gray-100">
                  {(['a', 'b'] as const).map(v => {
                    const isWinner = v === 'a' ? winnerA : winnerB;
                    const imp = v === 'a' ? impA : impB;
                    const conv = v === 'a' ? convA : convB;
                    const rate = v === 'a' ? rateA : rateB;
                    const txt = v === 'a' ? test.variant_a_text : test.variant_b_text;
                    return (
                      <div key={v} className={`p-4 ${isWinner ? 'bg-green-50' : ''}`}>
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-xs font-bold text-gray-400 uppercase tracking-wide">Variant {v.toUpperCase()}</span>
                          {isWinner && <span className="text-xs bg-green-100 text-green-700 font-semibold px-2 py-0.5 rounded-full">Winning</span>}
                        </div>
                        <p className="text-sm text-gray-700 line-clamp-2 mb-3 leading-snug">{txt}</p>
                        <div className="flex gap-4 text-xs text-gray-400 flex-wrap">
                          <span><strong className="text-gray-800 text-sm">{imp}</strong> <span>views</span></span>
                          <span><strong className="text-gray-800 text-sm">{conv}</strong> <span>signups</span></span>
                          <span><strong className={`text-sm ${isWinner ? 'text-green-600' : 'text-gray-800'}`}>{rate !== null ? `${rate}%` : '—'}</strong> <span>rate</span></span>
                        </div>
                      </div>
                    );
                  })}
                </div>
                {!enoughData && (impA + impB) > 0 && (
                  <div className="px-4 py-2.5 bg-amber-50 border-t border-amber-100 text-xs text-amber-700">
                    Need at least 5 views per variant to determine a winner. Collecting data…
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

/* ───── Colors Manager ───── */

interface ColorField { key: string; label: string; default: string; hint?: string; }
interface ComponentColorConfig { id: string; label: string; icon: string; description: string; fields: ColorField[]; }

const COMPONENT_COLOR_CONFIGS: ComponentColorConfig[] = [
  {
    id: 'announce', label: 'Announcement Bar', icon: '📢', description: 'Top sticky bar gradient',
    fields: [
      { key: 'color_announce_from', label: 'Left Color', default: '#FF3B6B' },
      { key: 'color_announce_to', label: 'Right Color', default: '#FF6B8A' },
    ],
  },
  {
    id: 'hero', label: 'Hero Section', icon: '🌅', description: 'Main banner background & highlight text',
    fields: [
      { key: 'color_hero_from', label: 'Gradient Start', default: '#4ECDC4', hint: 'Top-left color' },
      { key: 'color_hero_mid', label: 'Gradient Middle', default: '#0F4C81', hint: 'Centre blend' },
      { key: 'color_hero_to', label: 'Gradient End', default: '#1A1A6C', hint: 'Bottom-right color' },
      { key: 'color_highlight', label: 'Headline Highlight', default: '#FFE66D', hint: 'Coloured keyword in headline' },
    ],
  },
  {
    id: 'buttons', label: 'CTA Buttons', icon: '🔘', description: 'All call-to-action button gradient',
    fields: [
      { key: 'color_btn_from', label: 'Button Start', default: '#FF3B6B' },
      { key: 'color_btn_to', label: 'Button End', default: '#FF6B8A' },
    ],
  },
  {
    id: 'about', label: 'About Section', icon: 'ℹ️', description: 'Accent borders & dividers',
    fields: [
      { key: 'color_about_accent', label: 'Accent Color', default: '#FF3B6B', hint: 'Border & highlight lines' },
    ],
  },
  {
    id: 'midcta', label: 'Mid-Page CTA Banner', icon: '📣', description: 'Full-width clickable banner gradient',
    fields: [
      { key: 'color_midcta_from', label: 'Banner Start', default: '#FF3B6B' },
      { key: 'color_midcta_to', label: 'Banner End', default: '#FF6B8A' },
    ],
  },
  {
    id: 'testimonials', label: 'Testimonials Section', icon: '💬', description: 'Dark section background gradient',
    fields: [
      { key: 'color_testimonials_bg_from', label: 'Background Start', default: '#1A1A2E' },
      { key: 'color_testimonials_bg_to', label: 'Background End', default: '#0A0A0A' },
    ],
  },
  {
    id: 'benefits', label: 'Who Benefits Section', icon: '✅', description: 'Dark background & icon accent',
    fields: [
      { key: 'color_benefits_bg_from', label: 'Background Start', default: '#1A1A2E' },
      { key: 'color_benefits_bg_to', label: 'Background End', default: '#0A0A0A' },
      { key: 'color_benefits_accent', label: 'Icon Accent', default: '#FF3B6B', hint: 'Arrow icon color on cards' },
    ],
  },
  {
    id: 'faq', label: 'FAQ Section', icon: '❓', description: 'Accordion card colors',
    fields: [
      { key: 'color_faq_card_bg', label: 'Card Background', default: '#F0EFFF' },
      { key: 'color_faq_card_border', label: 'Card Border', default: '#E0D8FF' },
      { key: 'color_faq_icon', label: 'Icon Color', default: '#7C3AED', hint: 'Help icon & chevron' },
    ],
  },
  {
    id: 'footer', label: 'Footer', icon: '🔗', description: 'Footer background color',
    fields: [
      { key: 'color_footer_bg', label: 'Background', default: '#1A1A2E' },
    ],
  },
];

const ColorPreview: React.FC<{ id: string; colors: SiteContent }> = ({ id, colors }) => {
  const g = (key: string, def: string) => colors[key] || def;
  switch (id) {
    case 'announce':
      return (
        <div className="rounded-xl overflow-hidden shadow-sm">
          <div style={{ background: `linear-gradient(90deg, ${g('color_announce_from','#FF3B6B')}, ${g('color_announce_to','#FF6B8A')})` }} className="px-4 py-3 flex items-center justify-between gap-2">
            <span className="text-white text-xs font-medium truncate">Heal Naturally — Right from Your Home</span>
            <span className="bg-[#28A745] text-white text-xs font-bold px-3 py-1 rounded-full flex-shrink-0">Book Now</span>
          </div>
        </div>
      );
    case 'hero':
      return (
        <div style={{ background: `linear-gradient(135deg, ${g('color_hero_from','#4ECDC4')} 0%, ${g('color_hero_mid','#0F4C81')} 50%, ${g('color_hero_to','#1A1A6C')} 100%)` }} className="rounded-xl p-5 text-center min-h-[90px] flex flex-col items-center justify-center shadow-sm">
          <p className="text-white text-xs font-bold leading-snug">
            Transform{' '}<span style={{ color: g('color_highlight','#FFE66D') }}>Your Health &amp; Well-being</span>{' '}with Energy Healing
          </p>
        </div>
      );
    case 'buttons':
      return (
        <div className="space-y-2">
          <div style={{ background: `linear-gradient(to right, ${g('color_btn_from','#FF3B6B')}, ${g('color_btn_to','#FF6B8A')})` }} className="rounded-lg px-4 py-3 text-center shadow-sm">
            <span className="text-white font-semibold text-sm">Yes, I Want My Free Healing Session →</span>
          </div>
          <div style={{ background: `linear-gradient(to right, ${g('color_btn_from','#FF3B6B')}, ${g('color_btn_to','#FF6B8A')})` }} className="rounded-lg px-4 py-2 text-center shadow-sm">
            <span className="text-white font-semibold text-xs">Claim My Free Session →</span>
          </div>
        </div>
      );
    case 'about':
      return (
        <div className="bg-white border border-gray-100 rounded-xl p-4 shadow-sm">
          <div className="border-t-2 border-dashed mb-3" style={{ borderColor: g('color_about_accent','#FF3B6B') }} />
          <div className="border-l-4 pl-3" style={{ borderColor: g('color_about_accent','#FF3B6B') }}>
            <p className="text-sm text-gray-700 font-medium">I've helped many people release chronic pain through natural healing.</p>
          </div>
        </div>
      );
    case 'midcta':
      return (
        <div style={{ background: `linear-gradient(135deg, ${g('color_midcta_from','#FF3B6B')}, ${g('color_midcta_to','#FF6B8A')})` }} className="rounded-xl p-5 text-center shadow-sm">
          <p className="text-white font-bold text-sm">When Medicine Fails, Energy Healing Works</p>
          <p className="text-white/80 text-xs mt-1">Book your 1-to-1 online healing session today →</p>
        </div>
      );
    case 'testimonials':
      return (
        <div style={{ background: `linear-gradient(180deg, ${g('color_testimonials_bg_from','#1A1A2E')} 0%, ${g('color_testimonials_bg_to','#0A0A0A')} 100%)` }} className="rounded-xl p-4 shadow-sm">
          <div className="bg-[#1F2C34] rounded-xl p-3">
            <p className="text-white/90 text-xs leading-relaxed">"I had chronic pain for years and after 3 sessions, I feel completely healed."</p>
            <p className="text-white/50 text-xs mt-2">— Meena Sharma, Homemaker</p>
          </div>
        </div>
      );
    case 'benefits':
      return (
        <div style={{ background: `linear-gradient(180deg, ${g('color_benefits_bg_from','#1A1A2E')} 0%, ${g('color_benefits_bg_to','#0A0A0A')} 100%)` }} className="rounded-xl p-4 shadow-sm">
          <div className="grid grid-cols-2 gap-2">
            {['Pain Relief', 'Stress Relief', 'Better Sleep', 'More Energy'].map(t => (
              <div key={t} className="bg-white/5 border border-white/10 rounded-lg p-2 text-center">
                <div className="w-3 h-3 rounded-full mx-auto mb-1.5" style={{ background: g('color_benefits_accent','#FF3B6B') }} />
                <p className="text-white text-xs font-medium">{t}</p>
              </div>
            ))}
          </div>
        </div>
      );
    case 'faq':
      return (
        <div className="space-y-2">
          {['Is the first session really free?', 'What is energy healing?'].map((q, i) => (
            <div key={i} className="rounded-xl border p-3 flex items-center gap-2.5" style={{ background: g('color_faq_card_bg','#F0EFFF'), borderColor: g('color_faq_card_border','#E0D8FF') }}>
              <div className="w-4 h-4 rounded-full flex-shrink-0" style={{ background: g('color_faq_icon','#7C3AED') }} />
              <p className="text-gray-800 text-xs font-semibold">{q}</p>
            </div>
          ))}
        </div>
      );
    case 'footer':
      return (
        <div style={{ background: g('color_footer_bg','#1A1A2E') }} className="rounded-xl p-4 text-center shadow-sm">
          <p className="text-white/60 text-xs">© 2025 Ankit Kumar. All Rights Reserved</p>
        </div>
      );
    default:
      return null;
  }
};

const ColorsManager: React.FC = () => {
  const [selectedId, setSelectedId] = useState('announce');
  const [colors, setColors] = useState<SiteContent>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch('/api/content')
      .then(r => r.json())
      .then((d: SiteContent) => {
        const c: SiteContent = {};
        COMPONENT_COLOR_CONFIGS.forEach(comp => comp.fields.forEach(f => { c[f.key] = d[f.key] || f.default; }));
        setColors(c);
      })
      .catch(() => {
        const c: SiteContent = {};
        COMPONENT_COLOR_CONFIGS.forEach(comp => comp.fields.forEach(f => { c[f.key] = f.default; }));
        setColors(c);
      });
  }, []);

  const setValue = (key: string, val: string) => {
    setColors(c => ({ ...c, [key]: val }));
    document.documentElement.style.setProperty(`--${key.replace(/_/g, '-')}`, val);
  };

  const saveAll = async () => {
    setSaving(true);
    try {
      await fetch('/api/content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(colors) });
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    } catch { /* ignore */ }
    setSaving(false);
  };

  const resetComponent = (config: ComponentColorConfig) => {
    const updates: SiteContent = {};
    config.fields.forEach(f => {
      updates[f.key] = f.default;
      document.documentElement.style.setProperty(`--${f.key.replace(/_/g, '-')}`, f.default);
    });
    setColors(c => ({ ...c, ...updates }));
  };

  const selected = COMPONENT_COLOR_CONFIGS.find(c => c.id === selectedId)!;

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Color Theme</h2>
          <p className="text-sm text-gray-500 mt-0.5">Select a component, adjust its colors — changes apply live on the page.</p>
        </div>
        <button
          onClick={saveAll} disabled={saving}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all cursor-pointer disabled:opacity-60 ${saved ? 'bg-green-500 text-white' : 'bg-[#FF3B6B] hover:bg-[#e02d5a] text-white'}`}
        >
          {saved ? <><Check className="w-4 h-4" /> Saved!</> : <><Save className="w-4 h-4" />{saving ? 'Saving…' : 'Save All Colors'}</>}
        </button>
      </div>

      <div className="flex flex-col lg:flex-row gap-4">
        {/* Sidebar */}
        <div className="flex flex-row lg:flex-col gap-1.5 overflow-x-auto lg:overflow-visible pb-1 lg:pb-0 lg:w-52 flex-shrink-0">
          {COMPONENT_COLOR_CONFIGS.map(config => (
            <button
              key={config.id}
              onClick={() => setSelectedId(config.id)}
              className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-left transition-all cursor-pointer whitespace-nowrap lg:whitespace-normal w-full ${
                selectedId === config.id
                  ? 'bg-[#FF3B6B] text-white shadow-sm'
                  : 'bg-white border border-gray-200 text-gray-700 hover:border-rose-200 hover:bg-rose-50'
              }`}
            >
              <span className="text-base flex-shrink-0">{config.icon}</span>
              <div className="min-w-0">
                <p className="text-sm font-semibold leading-tight truncate">{config.label}</p>
                <p className={`text-xs leading-tight mt-0.5 hidden lg:block ${selectedId === config.id ? 'text-white/70' : 'text-gray-400'}`}>
                  {config.fields.length} color{config.fields.length > 1 ? 's' : ''}
                </p>
              </div>
            </button>
          ))}
        </div>

        {/* Right panel */}
        <div className="flex-1 bg-white border border-gray-200 rounded-xl shadow-sm p-5 min-w-0">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-3">
              <span className="text-2xl">{selected.icon}</span>
              <div>
                <h3 className="font-bold text-gray-900">{selected.label}</h3>
                <p className="text-xs text-gray-400 mt-0.5">{selected.description}</p>
              </div>
            </div>
            <button
              onClick={() => resetComponent(selected)}
              className="text-xs text-gray-400 hover:text-gray-700 px-3 py-1.5 rounded-lg border border-gray-200 hover:border-gray-300 transition-all cursor-pointer flex-shrink-0"
            >
              Reset defaults
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-3">
              {selected.fields.map(field => (
                <div key={field.key} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl border border-gray-100">
                  <input
                    type="color"
                    value={colors[field.key] || field.default}
                    onChange={e => setValue(field.key, e.target.value)}
                    className="w-12 h-12 rounded-xl border-2 border-white shadow cursor-pointer p-0.5 flex-shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm">{field.label}</p>
                    {field.hint && <p className="text-xs text-gray-400 mt-0.5">{field.hint}</p>}
                    <p className="text-xs font-mono text-gray-500 mt-1">{colors[field.key] || field.default}</p>
                  </div>
                </div>
              ))}
            </div>

            <div>
              <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">Live Preview</p>
              <ColorPreview id={selectedId} colors={colors} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

/* ───── Main Admin Page ───── */
const ADMIN_SIDEBAR: { group: string; items: { id: AdminTab; label: string; icon: React.ReactNode }[] }[] = [
  {
    group: 'Overview',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
      { id: 'reports', label: 'Reports', icon: <TrendingUp className="w-4 h-4" /> },
    ],
  },
  {
    group: 'Leads & CRM',
    items: [
      { id: 'leads', label: 'All Leads', icon: <Users className="w-4 h-4" /> },
      { id: 'crm', label: 'CRM Pipeline', icon: <GitBranch className="w-4 h-4" /> },
      { id: 'automation', label: 'Automation', icon: <Zap className="w-4 h-4" /> },
    ],
  },
  {
    group: 'Page Design',
    items: [
      { id: 'content', label: 'Content Editor', icon: <Edit3 className="w-4 h-4" /> },
      { id: 'social', label: 'Social Proof', icon: <Star className="w-4 h-4" /> },
      { id: 'colors', label: 'Colors', icon: <Palette className="w-4 h-4" /> },
      { id: 'media', label: 'Media Library', icon: <Image className="w-4 h-4" /> },
    ],
  },
  {
    group: 'Marketing',
    items: [
      { id: 'abtests', label: 'A/B Tests', icon: <Radio className="w-4 h-4" /> },
      { id: 'whatsapp', label: 'WhatsApp', icon: <MessageCircle className="w-4 h-4" /> },
      { id: 'seo', label: 'SEO', icon: <Search className="w-4 h-4" /> },
    ],
  },
  {
    group: 'Configuration',
    items: [
      { id: 'notifications', label: 'Notifications', icon: <Bell className="w-4 h-4" /> },
      { id: 'tracking', label: 'Tracking', icon: <BarChart2 className="w-4 h-4" /> },
      { id: 'integrations', label: 'Integrations', icon: <Link2 className="w-4 h-4" /> },
      { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4" /> },
    ],
  },
];

const AdminPage: React.FC = () => {
  const [authed, setAuthed] = useState(() => sessionStorage.getItem('admin_auth') === '1');
  const [passwordInput, setPasswordInput] = useState('');
  const [authError, setAuthError] = useState('');
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordInput === ADMIN_PASSWORD) { sessionStorage.setItem('admin_auth', '1'); setAuthed(true); setAuthError(''); }
    else { setAuthError('Incorrect password.'); setPasswordInput(''); }
  };

  const handleLogout = () => { sessionStorage.removeItem('admin_auth'); setAuthed(false); };

  if (!authed) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#1A1A6C] to-[#0F4C81] p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-8">
          <div className="flex flex-col items-center mb-6">
            <div className="w-14 h-14 rounded-full bg-[#FF3B6B]/10 flex items-center justify-center mb-3">
              <Lock className="w-7 h-7 text-[#FF3B6B]" />
            </div>
            <h1 className="text-xl font-bold text-gray-900">Admin Login</h1>
            <p className="text-sm text-gray-500 mt-1">Divine Healing Dashboard</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-4">
            <input
              type="password" placeholder="Password" value={passwordInput}
              onChange={e => setPasswordInput(e.target.value)} autoFocus
              className="w-full border border-gray-200 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B]"
            />
            {authError && <p className="text-red-500 text-sm text-center">{authError}</p>}
            <button type="submit" className="w-full bg-gradient-to-r from-[#FF3B6B] to-[#FF6B8A] text-white font-bold py-3 rounded-lg hover:shadow-lg transition-all cursor-pointer">
              Sign In
            </button>
          </form>
        </div>
      </div>
    );
  }

  const navigate = (tab: AdminTab) => { setActiveTab(tab); setSidebarOpen(false); };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/40 z-20 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed top-0 left-0 h-full w-60 bg-white border-r border-gray-200 z-30 flex flex-col transition-transform duration-300
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 lg:static lg:z-auto`}>

        {/* Logo */}
        <div className="px-4 py-4 border-b border-gray-100 flex items-center gap-3 flex-shrink-0">
          <div className="w-9 h-9 rounded-xl bg-[#FF3B6B]/10 flex items-center justify-center flex-shrink-0">
            <span className="text-xl">✨</span>
          </div>
          <div className="min-w-0">
            <p className="font-bold text-gray-900 text-sm leading-tight truncate">Divine Healing</p>
            <p className="text-xs text-gray-400">Admin Panel</p>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="ml-auto text-gray-400 hover:text-gray-600 lg:hidden cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-3 px-2">
          {ADMIN_SIDEBAR.map(group => (
            <div key={group.group} className="mb-4">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest px-2 mb-1">{group.group}</p>
              {group.items.map(item => (
                <button
                  key={item.id}
                  onClick={() => navigate(item.id)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-all cursor-pointer mb-0.5
                    ${activeTab === item.id
                      ? 'bg-[#FF3B6B] text-white shadow-sm'
                      : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'}`}
                >
                  {item.icon}
                  {item.label}
                </button>
              ))}
            </div>
          ))}
        </nav>

        {/* Sidebar Footer */}
        <div className="border-t border-gray-100 p-3 flex-shrink-0 space-y-1">
          <a href="/" target="_blank" rel="noopener noreferrer"
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition-all cursor-pointer">
            <Eye className="w-4 h-4" />
            View Landing Page
          </a>
          <button onClick={handleLogout}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium text-red-500 hover:bg-red-50 transition-all cursor-pointer">
            <LogOut className="w-4 h-4" />
            Logout
          </button>
        </div>
      </aside>

      {/* Main area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar (mobile) */}
        <header className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 lg:hidden sticky top-0 z-10">
          <button onClick={() => setSidebarOpen(true)} className="p-1.5 text-gray-500 hover:text-gray-800 cursor-pointer">
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <span className="text-lg">✨</span>
            <span className="font-bold text-gray-900 text-sm">Divine Healing Admin</span>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-4 sm:p-6 overflow-auto">
          {activeTab === 'dashboard' && <DashboardTab />}
          {activeTab === 'leads' && <LeadsTable />}
          {activeTab === 'crm' && <CRMTab />}
          {activeTab === 'reports' && <ReportsTab />}
          {activeTab === 'content' && <ContentEditor />}
          {activeTab === 'social' && <SocialProofManager />}
          {activeTab === 'notifications' && <NotificationsManager />}
          {activeTab === 'tracking' && <TrackingManager />}
          {activeTab === 'colors' && <ColorsManager />}
          {activeTab === 'abtests' && <ABTestsManager />}
          {activeTab === 'seo' && <SEOTab />}
          {activeTab === 'whatsapp' && <WhatsAppTab />}
          {activeTab === 'media' && <MediaTab />}
          {activeTab === 'automation' && <AutomationTab />}
          {activeTab === 'integrations' && <IntegrationsTab />}
          {activeTab === 'settings' && <SettingsTab />}
        </main>
      </div>
    </div>
  );
};

export default AdminPage;
