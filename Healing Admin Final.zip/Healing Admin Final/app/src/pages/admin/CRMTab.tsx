import React, { useState, useEffect, useCallback } from 'react';
import { RefreshCw, ChevronDown, Save, Check, BarChart2, Users } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

interface Lead {
  id: number; name: string; email: string; whatsapp: string;
  created_at: string; crm_stage: string; notes: string; tags: string;
}

const STAGES = [
  { id: 'new', label: 'New', color: 'bg-blue-500', light: 'bg-blue-50 border-blue-200' },
  { id: 'contacted', label: 'Contacted', color: 'bg-yellow-500', light: 'bg-yellow-50 border-yellow-200' },
  { id: 'interested', label: 'Interested', color: 'bg-purple-500', light: 'bg-purple-50 border-purple-200' },
  { id: 'follow_up', label: 'Follow Up', color: 'bg-orange-500', light: 'bg-orange-50 border-orange-200' },
  { id: 'qualified', label: 'Qualified', color: 'bg-teal-500', light: 'bg-teal-50 border-teal-200' },
  { id: 'proposal', label: 'Proposal Sent', color: 'bg-indigo-500', light: 'bg-indigo-50 border-indigo-200' },
  { id: 'converted', label: 'Converted', color: 'bg-green-500', light: 'bg-green-50 border-green-200' },
  { id: 'lost', label: 'Lost', color: 'bg-red-400', light: 'bg-red-50 border-red-200' },
];

const SubNav = ({ tabs, active, onChange }: { tabs: { id: string; label: string }[]; active: string; onChange: (id: string) => void }) => (
  <div className="flex gap-1 border-b border-gray-200 mb-5 overflow-x-auto">
    {tabs.map(t => (
      <button key={t.id} onClick={() => onChange(t.id)}
        className={`px-4 py-2.5 text-sm font-semibold border-b-2 whitespace-nowrap transition-all cursor-pointer ${active === t.id ? 'border-[#FF3B6B] text-[#FF3B6B]' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
        {t.label}
      </button>
    ))}
  </div>
);

const LeadCard = ({ lead, onStageChange, onUpdate }: {
  lead: Lead; onStageChange: (id: number, stage: string) => void;
  onUpdate: (id: number, notes: string, tags: string) => void;
}) => {
  const [expanded, setExpanded] = useState(false);
  const [notes, setNotes] = useState(lead.notes || '');
  const [tags, setTags] = useState(lead.tags || '');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const save = async () => {
    setSaving(true);
    await onUpdate(lead.id, notes, tags);
    setSaved(true); setTimeout(() => setSaved(false), 2000); setSaving(false);
  };

  const date = new Date(lead.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });

  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm mb-2 overflow-hidden">
      <div className="p-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#FF3B6B] to-[#FF6B8A] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">{lead.name[0]?.toUpperCase()}</div>
            <div className="min-w-0"><p className="text-sm font-semibold text-gray-900 truncate">{lead.name}</p><p className="text-xs text-gray-400">{date}</p></div>
          </div>
          <button onClick={() => setExpanded(e => !e)} className="p-1 text-gray-400 hover:text-gray-600 cursor-pointer flex-shrink-0">
            <ChevronDown className={`w-4 h-4 transition-transform ${expanded ? 'rotate-180' : ''}`} />
          </button>
        </div>
        <div className="flex items-center gap-1.5 mt-2 flex-wrap">
          <a href={`https://wa.me/${lead.whatsapp.replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer"
            className="text-xs text-green-600 bg-green-50 px-2 py-0.5 rounded-full font-medium hover:bg-green-100">📱 {lead.whatsapp}</a>
          {lead.tags && lead.tags.split(',').filter(Boolean).map(tag => (
            <span key={tag} className="text-xs bg-purple-50 text-purple-600 px-2 py-0.5 rounded-full">{tag.trim()}</span>
          ))}
        </div>
        <select value={lead.crm_stage || 'new'} onChange={e => onStageChange(lead.id, e.target.value)}
          className="w-full mt-2 text-xs border border-gray-200 rounded-lg px-2 py-1.5 focus:outline-none focus:border-[#FF3B6B] bg-white cursor-pointer font-medium">
          {STAGES.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
        </select>
      </div>
      {expanded && (
        <div className="border-t border-gray-100 p-3 bg-gray-50 space-y-2">
          <p className="text-xs text-gray-500 truncate">📧 {lead.email}</p>
          <div>
            <label className="text-xs font-semibold text-gray-500 block mb-1">Notes</label>
            <textarea rows={2} value={notes} onChange={e => setNotes(e.target.value)} placeholder="Add notes..."
              className="w-full text-xs border border-gray-200 rounded-lg px-2 py-1.5 focus:outline-none focus:border-[#FF3B6B] resize-none bg-white" />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-500 block mb-1">Tags</label>
            <input type="text" value={tags} onChange={e => setTags(e.target.value)} placeholder="hot-lead, pain, delhi"
              className="w-full text-xs border border-gray-200 rounded-lg px-2 py-1.5 focus:outline-none focus:border-[#FF3B6B] bg-white" />
          </div>
          <button onClick={save} disabled={saving}
            className={`w-full flex items-center justify-center gap-1 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${saved ? 'bg-green-500 text-white' : 'bg-[#FF3B6B] text-white hover:bg-[#e02d5a]'}`}>
            {saved ? <><Check className="w-3 h-3" /> Saved</> : saving ? 'Saving…' : <><Save className="w-3 h-3" /> Save Notes</>}
          </button>
        </div>
      )}
    </div>
  );
};

const CRMTab: React.FC = () => {
  const [sub, setSub] = useState('pipeline');
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try { const r = await fetch('/api/registrations'); setLeads(await r.json()); } catch { }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const updateStage = async (id: number, crm_stage: string) => {
    await fetch(`/api/registrations/${id}/crm`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ crm_stage }) });
    setLeads(l => l.map(lead => lead.id === id ? { ...lead, crm_stage } : lead));
  };

  const updateNotesTags = async (id: number, notes: string, tags: string) => {
    await fetch(`/api/registrations/${id}/crm`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ notes, tags }) });
    setLeads(l => l.map(lead => lead.id === id ? { ...lead, notes, tags } : lead));
  };

  const filtered = leads.filter(l => !search || l.name.toLowerCase().includes(search.toLowerCase()) || l.email.toLowerCase().includes(search.toLowerCase()) || l.whatsapp.includes(search));
  const getStageLeads = (stageId: string) => filtered.filter(l => (l.crm_stage || 'new') === stageId);
  const total = leads.length;

  // Analytics data
  const analyticsData = STAGES.map(s => ({
    name: s.label, count: getStageLeads(s.id).length,
    pct: total > 0 ? Math.round((getStageLeads(s.id).length / total) * 100) : 0,
  })).filter(s => s.count > 0);

  const conversionRate = total > 0 ? Math.round((getStageLeads('converted').length / total) * 100) : 0;

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-lg font-bold text-gray-900">CRM Pipeline</h2>
          <p className="text-sm text-gray-500 mt-0.5">Track leads through every stage of your process</p>
        </div>
        <div className="flex gap-2">
          <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search leads..."
            className="border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B] w-48" />
          <button onClick={load} className="p-2 border border-gray-200 rounded-lg text-gray-500 hover:bg-gray-50 cursor-pointer">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>
      <SubNav tabs={[{ id: 'pipeline', label: `📋 Pipeline (${total})` }, { id: 'analytics', label: '📊 Analytics' }]} active={sub} onChange={setSub} />

      {sub === 'pipeline' && (
        loading ? <div className="flex items-center justify-center py-20"><RefreshCw className="w-6 h-6 text-[#FF3B6B] animate-spin" /></div>
        : (
          <div className="overflow-x-auto">
            <div className="flex gap-3 min-w-max pb-4">
              {STAGES.map(stage => {
                const stageLeads = getStageLeads(stage.id);
                return (
                  <div key={stage.id} className="w-[190px] flex-shrink-0">
                    <div className={`flex items-center gap-2 px-3 py-2 rounded-lg mb-3 border ${stage.light}`}>
                      <div className={`w-2.5 h-2.5 rounded-full ${stage.color}`} />
                      <span className="text-xs font-bold text-gray-700 truncate">{stage.label}</span>
                      <span className="ml-auto text-xs font-bold text-gray-500 bg-white px-1.5 py-0.5 rounded-full border">{stageLeads.length}</span>
                    </div>
                    <div style={{ minHeight: 80 }}>
                      {stageLeads.map(lead => (
                        <LeadCard key={lead.id} lead={lead} onStageChange={updateStage} onUpdate={updateNotesTags} />
                      ))}
                      {stageLeads.length === 0 && (
                        <div className="border-2 border-dashed border-gray-200 rounded-xl p-4 text-center">
                          <p className="text-xs text-gray-400">No leads</p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )
      )}

      {sub === 'analytics' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Pipeline Overview</h3>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="bg-gray-50 rounded-xl p-4 text-center">
                <p className="text-2xl font-bold text-gray-900">{total}</p>
                <p className="text-xs text-gray-500 mt-0.5">Total Leads</p>
              </div>
              <div className="bg-green-50 rounded-xl p-4 text-center">
                <p className="text-2xl font-bold text-green-600">{conversionRate}%</p>
                <p className="text-xs text-gray-500 mt-0.5">Conversion Rate</p>
              </div>
              <div className="bg-blue-50 rounded-xl p-4 text-center">
                <p className="text-2xl font-bold text-blue-600">{getStageLeads('new').length}</p>
                <p className="text-xs text-gray-500 mt-0.5">New Leads</p>
              </div>
              <div className="bg-orange-50 rounded-xl p-4 text-center">
                <p className="text-2xl font-bold text-orange-600">{getStageLeads('follow_up').length}</p>
                <p className="text-xs text-gray-500 mt-0.5">Need Follow Up</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Leads by Stage</h3>
            {analyticsData.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={analyticsData} layout="vertical" margin={{ top: 0, right: 0, left: 20, bottom: 0 }}>
                  <XAxis type="number" tick={{ fontSize: 10, fill: '#9ca3af' }} tickLine={false} axisLine={false} allowDecimals={false} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: '#374151' }} tickLine={false} axisLine={false} width={85} />
                  <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e5e7eb', fontSize: 12 }} formatter={(v: number) => [`${v} leads`, '']} />
                  <Bar dataKey="count" fill="#FF3B6B" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : <div className="flex items-center justify-center h-[200px] text-gray-400 text-sm">No data yet</div>}
          </div>
          <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Stage-by-Stage Breakdown</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
              {STAGES.map((stage, i) => {
                const count = getStageLeads(stage.id).length;
                const pct = total > 0 ? Math.round((count / total) * 100) : 0;
                return (
                  <div key={stage.id} className={`rounded-xl p-3 border text-center ${stage.light}`}>
                    <p className="text-xl font-bold text-gray-900">{count}</p>
                    <p className="text-xs text-gray-600 font-medium truncate">{stage.label}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{pct}%</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CRMTab;
