import React, { useState, useEffect } from 'react';
import { Save, Check, RefreshCw } from 'lucide-react';

const Field = ({ label, value, onChange, type = 'text', hint }: {
  label: string; value: string; onChange: (v: string) => void; type?: string; hint?: string;
}) => (
  <div className="mb-4">
    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">{label}</label>
    <input
      type={type} value={value} onChange={e => onChange(e.target.value)}
      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B] transition-all"
    />
    {hint && <p className="text-xs text-gray-400 mt-1">{hint}</p>}
  </div>
);

const Section = ({ title, icon, children }: { title: string; icon: string; children: React.ReactNode }) => (
  <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 mb-4">
    <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
      <span>{icon}</span> {title}
    </h3>
    {children}
  </div>
);

const SettingsTab: React.FC = () => {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/content').then(r => r.json()).then((d: Record<string, string>) => {
      setSettings({
        site_name: d.site_name || 'Divine Healing',
        site_tagline: d.site_tagline || '1:1 Energy Healing for All Illnesses',
        admin_email: d.admin_email || '',
        admin_whatsapp: d.admin_whatsapp || '',
        contact_phone: d.contact_phone || '',
        timezone: d.timezone || 'Asia/Kolkata',
        language: d.language || 'hi,en',
        logo_url: d.logo_url || '',
        favicon_url: d.favicon_url || '',
        smtp_host: d.smtp_host || '',
        smtp_port: d.smtp_port || '587',
        smtp_user: d.smtp_user || '',
        smtp_pass: d.smtp_pass || '',
        smtp_from: d.smtp_from || '',
        privacy_url: d.privacy_url || '',
        terms_url: d.terms_url || '',
        refund_url: d.refund_url || '',
        thankyou_redirect: d.thankyou_redirect || '',
      });
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const set = (key: string, val: string) => setSettings(s => ({ ...s, [key]: val }));

  const save = async () => {
    setSaving(true);
    await fetch('/api/content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(settings) });
    setSaved(true); setTimeout(() => setSaved(false), 2500); setSaving(false);
  };

  if (loading) return <div className="flex items-center justify-center py-20"><RefreshCw className="w-5 h-5 animate-spin text-[#FF3B6B]" /></div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Settings</h2>
          <p className="text-sm text-gray-500 mt-0.5">General site configuration</p>
        </div>
        <button onClick={save} disabled={saving}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold cursor-pointer transition-all ${saved ? 'bg-green-500 text-white' : 'bg-[#FF3B6B] hover:bg-[#e02d5a] text-white'} disabled:opacity-60`}>
          {saved ? <><Check className="w-4 h-4" /> Saved!</> : <><Save className="w-4 h-4" />{saving ? 'Saving…' : 'Save Settings'}</>}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div>
          <Section title="General" icon="🏠">
            <Field label="Site Name" value={settings.site_name} onChange={v => set('site_name', v)} hint="Appears in browser tab and emails" />
            <Field label="Tagline" value={settings.site_tagline} onChange={v => set('site_tagline', v)} />
            <Field label="Logo URL" value={settings.logo_url} onChange={v => set('logo_url', v)} hint="Paste a direct image URL" />
            <Field label="Favicon URL" value={settings.favicon_url} onChange={v => set('favicon_url', v)} hint="Small icon shown in browser tab" />
            <div className="mb-4">
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Timezone</label>
              <select value={settings.timezone} onChange={e => set('timezone', e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B]">
                <option value="Asia/Kolkata">Asia/Kolkata (IST +5:30)</option>
                <option value="Asia/Dubai">Asia/Dubai (GST +4)</option>
                <option value="America/New_York">America/New_York (EST)</option>
                <option value="America/Los_Angeles">America/Los_Angeles (PST)</option>
                <option value="Europe/London">Europe/London (GMT)</option>
                <option value="UTC">UTC</option>
              </select>
            </div>
          </Section>

          <Section title="Contact Info" icon="📞">
            <Field label="Admin Email" value={settings.admin_email} onChange={v => set('admin_email', v)} type="email" hint="Used for lead notifications" />
            <Field label="Admin WhatsApp Number" value={settings.admin_whatsapp} onChange={v => set('admin_whatsapp', v)} hint="Include country code e.g. +919876543210" />
            <Field label="Contact Phone" value={settings.contact_phone} onChange={v => set('contact_phone', v)} hint="Shown on landing page if applicable" />
          </Section>

          <Section title="Legal Pages" icon="📄">
            <Field label="Privacy Policy URL" value={settings.privacy_url} onChange={v => set('privacy_url', v)} />
            <Field label="Terms & Conditions URL" value={settings.terms_url} onChange={v => set('terms_url', v)} />
            <Field label="Refund Policy URL" value={settings.refund_url} onChange={v => set('refund_url', v)} />
          </Section>
        </div>

        <div>
          <Section title="Email / SMTP" icon="📧">
            <div className="bg-blue-50 border border-blue-100 rounded-lg p-3 mb-4 text-xs text-blue-700">
              Configure SMTP to send automated emails to leads when they register.
            </div>
            <Field label="SMTP Host" value={settings.smtp_host} onChange={v => set('smtp_host', v)} hint="e.g. smtp.gmail.com" />
            <Field label="SMTP Port" value={settings.smtp_port} onChange={v => set('smtp_port', v)} hint="Usually 587 (TLS) or 465 (SSL)" />
            <Field label="SMTP Username / Email" value={settings.smtp_user} onChange={v => set('smtp_user', v)} type="email" />
            <Field label="SMTP Password / App Password" value={settings.smtp_pass} onChange={v => set('smtp_pass', v)} type="password" hint="Use an App Password for Gmail" />
            <Field label="From Email (shown to recipient)" value={settings.smtp_from} onChange={v => set('smtp_from', v)} hint="e.g. Ankit Kumar <ankit@divinehealing.in>" />
          </Section>

          <Section title="Post-Registration" icon="🎯">
            <Field label="Thank You Redirect URL" value={settings.thankyou_redirect} onChange={v => set('thankyou_redirect', v)} hint="Leave blank to show the default success screen. Or enter a URL to redirect after registration." />
          </Section>

          <Section title="Admin Password" icon="🔒">
            <div className="bg-amber-50 border border-amber-100 rounded-lg p-3 text-xs text-amber-700">
              The admin password is currently set in the code. To change it, edit the <code className="bg-amber-100 px-1 rounded">ADMIN_PASSWORD</code> constant in <code className="bg-amber-100 px-1 rounded">app/src/pages/Admin.tsx</code>.
            </div>
          </Section>
        </div>
      </div>
    </div>
  );
};

export default SettingsTab;
