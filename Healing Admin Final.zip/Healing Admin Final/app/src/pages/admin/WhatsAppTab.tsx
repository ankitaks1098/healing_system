import React, { useState, useEffect } from 'react';
import { Save, Check, RefreshCw, Copy } from 'lucide-react';

const Field = ({ label, value, onChange, textarea, rows = 3, hint, placeholder }: {
  label: string; value: string; onChange: (v: string) => void;
  textarea?: boolean; rows?: number; hint?: string; placeholder?: string;
}) => (
  <div className="mb-4">
    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">{label}</label>
    {textarea ? (
      <textarea rows={rows} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B] resize-y" />
    ) : (
      <input type="text" value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B]" />
    )}
    {hint && <p className="text-xs text-gray-400 mt-1">{hint}</p>}
  </div>
);

const TEMPLATE_VARS = ['{name}', '{email}', '{whatsapp}', '{date}', '{time}'];

const WhatsAppTab: React.FC = () => {
  const [s, setS] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState('');

  useEffect(() => {
    fetch('/api/content').then(r => r.json()).then((d: Record<string, string>) => {
      setS({
        wa_admin_number: d.wa_admin_number || '',
        wa_group_link: d.wa_group_link || d.modal_wa_group_url || '',
        wa_welcome_template: d.wa_welcome_template || 'Hi {name}! 🙏\n\nThank you for registering for a FREE 1-on-1 Healing Session!\n\nWe will contact you shortly on WhatsApp to book your session.\n\nTo join our healing community, click this link:\n{group_link}\n\nGod bless you! ✨\n— Ankit Kumar',
        wa_admin_notify_template: d.wa_admin_notify_template || '🔔 New Lead!\n\nName: {name}\nEmail: {email}\nWhatsApp: {whatsapp}\nTime: {date} {time}',
        wa_followup_template: d.wa_followup_template || 'Hi {name}! 🙏\n\nJust checking in — have you had a chance to book your FREE healing session?\n\nReply YES and I will arrange it for you today!\n\n— Ankit Kumar',
        wa_click_to_chat_text: d.wa_click_to_chat_text || 'I want to book a FREE healing session',
        wa_enable_admin_notify: d.wa_enable_admin_notify || 'true',
        wa_enable_welcome: d.wa_enable_welcome || 'false',
      });
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const set = (key: string, val: string) => setS(prev => ({ ...prev, [key]: val }));
  const toggle = (key: string) => setS(prev => ({ ...prev, [key]: prev[key] === 'true' ? 'false' : 'true' }));

  const save = async () => {
    setSaving(true);
    const payload = { ...s, modal_wa_group_url: s.wa_group_link };
    await fetch('/api/content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    setSaved(true); setTimeout(() => setSaved(false), 2500); setSaving(false);
  };

  const copy = (text: string, key: string) => {
    navigator.clipboard.writeText(text).then(() => { setCopied(key); setTimeout(() => setCopied(''), 2000); });
  };

  const buildWALink = (number: string, msg: string) =>
    `https://wa.me/${number.replace(/\D/g, '')}?text=${encodeURIComponent(msg)}`;

  const Toggle = ({ k, label, hint }: { k: string; label: string; hint: string }) => (
    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg mb-3">
      <div><p className="text-sm font-semibold text-gray-900">{label}</p><p className="text-xs text-gray-500">{hint}</p></div>
      <button onClick={() => toggle(k)}
        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer flex-shrink-0 ml-3 ${s[k] === 'true' ? 'bg-[#FF3B6B]' : 'bg-gray-300'}`}>
        <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${s[k] === 'true' ? 'translate-x-6' : 'translate-x-1'}`} />
      </button>
    </div>
  );

  if (loading) return <div className="flex items-center justify-center py-20"><RefreshCw className="w-5 h-5 animate-spin text-[#FF3B6B]" /></div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-bold text-gray-900">WhatsApp</h2>
          <p className="text-sm text-gray-500 mt-0.5">Configure WhatsApp numbers, templates and click-to-chat links</p>
        </div>
        <button onClick={save} disabled={saving}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold cursor-pointer transition-all ${saved ? 'bg-green-500 text-white' : 'bg-[#25D366] hover:bg-[#1da851] text-white'} disabled:opacity-60`}>
          {saved ? <><Check className="w-4 h-4" /> Saved!</> : <><Save className="w-4 h-4" />{saving ? 'Saving…' : 'Save'}</>}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 mb-4">
            <h3 className="font-semibold text-gray-900 mb-4">📱 WhatsApp Numbers</h3>
            <Field label="Admin WhatsApp Number" value={s.wa_admin_number} onChange={v => set('wa_admin_number', v)}
              placeholder="+919876543210" hint="Your number — where admin notifications are sent. Include country code." />
            <Field label="WhatsApp Group Invite Link" value={s.wa_group_link} onChange={v => set('wa_group_link', v)}
              placeholder="https://chat.whatsapp.com/xxxx" hint="Leads are sent to this group after registering." />

            {s.wa_admin_number && (
              <div className="mt-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-xs font-semibold text-green-700 mb-2">Click-to-Chat Preview</p>
                <a
                  href={buildWALink(s.wa_admin_number, s.wa_click_to_chat_text)}
                  target="_blank" rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-3 py-2 bg-[#25D366] text-white text-xs font-semibold rounded-lg hover:bg-[#1da851] transition-colors"
                >
                  <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                  Open WhatsApp Chat
                </a>
              </div>
            )}
          </div>

          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 mb-4">
            <h3 className="font-semibold text-gray-900 mb-4">🔔 Notifications</h3>
            <Toggle k="wa_enable_admin_notify" label="Admin Lead Notification" hint="Notify admin WhatsApp when a new lead registers" />
            <Toggle k="wa_enable_welcome" label="Auto Welcome Message" hint="Auto-send welcome message to lead (requires WhatsApp Business API)" />
            <div className="mt-3 p-3 bg-amber-50 border border-amber-100 rounded-lg text-xs text-amber-700">
              ⚠️ Auto-sending messages requires WhatsApp Business API (Meta approved). For now, use the template below to manually send.
            </div>
          </div>
        </div>

        <div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 mb-4">
            <h3 className="font-semibold text-gray-900 mb-2">📝 Message Templates</h3>
            <p className="text-xs text-gray-500 mb-1">Available variables:</p>
            <div className="flex flex-wrap gap-1 mb-4">
              {TEMPLATE_VARS.map(v => (
                <span key={v} className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded font-mono cursor-pointer hover:bg-gray-200"
                  onClick={() => copy(v, v)}>{v}</span>
              ))}
              <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded font-mono cursor-pointer hover:bg-gray-200"
                onClick={() => copy('{group_link}', '{group_link}')}>{'{group_link}'}</span>
            </div>

            <div className="mb-4">
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Welcome Message (to Lead)</label>
                <button onClick={() => copy(s.wa_welcome_template, 'welcome')}
                  className="text-xs text-gray-400 hover:text-gray-600 flex items-center gap-1 cursor-pointer">
                  <Copy className="w-3 h-3" />{copied === 'welcome' ? 'Copied!' : 'Copy'}
                </button>
              </div>
              <textarea rows={6} value={s.wa_welcome_template} onChange={e => set('wa_welcome_template', e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#FF3B6B] resize-y font-mono text-xs" />
            </div>

            <div className="mb-4">
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Admin Notification (to You)</label>
                <button onClick={() => copy(s.wa_admin_notify_template, 'admin')}
                  className="text-xs text-gray-400 hover:text-gray-600 flex items-center gap-1 cursor-pointer">
                  <Copy className="w-3 h-3" />{copied === 'admin' ? 'Copied!' : 'Copy'}
                </button>
              </div>
              <textarea rows={5} value={s.wa_admin_notify_template} onChange={e => set('wa_admin_notify_template', e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#FF3B6B] resize-y font-mono text-xs" />
            </div>

            <div className="mb-4">
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">Follow-Up Message</label>
                <button onClick={() => copy(s.wa_followup_template, 'followup')}
                  className="text-xs text-gray-400 hover:text-gray-600 flex items-center gap-1 cursor-pointer">
                  <Copy className="w-3 h-3" />{copied === 'followup' ? 'Copied!' : 'Copy'}
                </button>
              </div>
              <textarea rows={5} value={s.wa_followup_template} onChange={e => set('wa_followup_template', e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#FF3B6B] resize-y font-mono text-xs" />
            </div>

            <Field label="Click-to-Chat Default Message" value={s.wa_click_to_chat_text} onChange={v => set('wa_click_to_chat_text', v)}
              hint="Pre-filled message when someone clicks your WhatsApp button" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default WhatsAppTab;
