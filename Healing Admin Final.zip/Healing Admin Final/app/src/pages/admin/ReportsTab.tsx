import React, { useState, useEffect, useCallback } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid, PieChart, Pie, Cell } from 'recharts';
import { RefreshCw, TrendingUp, Calendar, Download } from 'lucide-react';

interface DailyData { date: string; count: string; }
interface StageData { crm_stage: string; count: string; }

const STAGE_LABELS: Record<string, string> = { new: 'New', contacted: 'Contacted', interested: 'Interested', follow_up: 'Follow Up', converted: 'Converted', lost: 'Lost' };
const PIE_COLORS = ['#FF3B6B', '#3B82F6', '#8B5CF6', '#F59E0B', '#10B981', '#EF4444'];

const SubNav = ({ tabs, active, onChange }: { tabs: { id: string; label: string }[]; active: string; onChange: (id: string) => void }) => (
  <div className="flex gap-1 border-b border-gray-200 mb-5 overflow-x-auto">
    {tabs.map(t => (
      <button key={t.id} onClick={() => onChange(t.id)}
        className={`px-4 py-2.5 text-sm font-semibold border-b-2 whitespace-nowrap transition-all cursor-pointer ${active === t.id ? 'border-[#FF3B6B] text-[#FF3B6B]' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
        {t.label}
      </button>
    ))}
  </div>
);

const ReportsTab: React.FC = () => {
  const [sub, setSub] = useState('daily');
  const [daily, setDaily] = useState<DailyData[]>([]);
  const [stages, setStages] = useState<StageData[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<'7' | '14' | '30'>('30');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch('/api/stats');
      const data = await r.json();
      setDaily(data.daily || []);
      setStages(data.byStage || []);
    } catch { }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const filteredDaily = daily.slice(-parseInt(period));
  const chartData = filteredDaily.map(d => ({ date: new Date(d.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }), leads: parseInt(d.count) }));
  const stageData = stages.map(s => ({ name: STAGE_LABELS[s.crm_stage] || s.crm_stage, value: parseInt(s.count) }));
  const totalPeriod = filteredDaily.reduce((s, d) => s + parseInt(d.count), 0);
  const avg = filteredDaily.length > 0 ? (totalPeriod / filteredDaily.length).toFixed(1) : '0';
  const peak = filteredDaily.length > 0 ? Math.max(...filteredDaily.map(d => parseInt(d.count))) : 0;
  const totalAll = daily.reduce((s, d) => s + parseInt(d.count), 0);

  // Group by week
  const weeklyData: Record<string, number> = {};
  daily.forEach(d => {
    const dt = new Date(d.date);
    const weekStart = new Date(dt); weekStart.setDate(dt.getDate() - dt.getDay());
    const key = weekStart.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
    weeklyData[key] = (weeklyData[key] || 0) + parseInt(d.count);
  });
  const weeklyChartData = Object.entries(weeklyData).slice(-8).map(([date, leads]) => ({ date, leads }));

  // Group by month
  const monthlyData: Record<string, number> = {};
  daily.forEach(d => {
    const key = new Date(d.date).toLocaleDateString('en-IN', { month: 'short', year: '2-digit' });
    monthlyData[key] = (monthlyData[key] || 0) + parseInt(d.count);
  });
  const monthlyChartData = Object.entries(monthlyData).map(([date, leads]) => ({ date, leads }));

  const exportCSV = () => {
    const rows = [['Date', 'Leads'], ...filteredDaily.map(d => [d.date, d.count])];
    const csv = rows.map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `leads-report-${period}d.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Reports & Analytics</h2>
          <p className="text-sm text-gray-500 mt-0.5">Lead trends and performance insights</p>
        </div>
        <div className="flex gap-2">
          <div className="flex bg-gray-100 rounded-lg p-1 gap-1">
            {(['7', '14', '30'] as const).map(p => (
              <button key={p} onClick={() => setPeriod(p)}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold cursor-pointer transition-all ${period === p ? 'bg-white shadow text-gray-900' : 'text-gray-500 hover:text-gray-700'}`}>{p}d</button>
            ))}
          </div>
          <button onClick={exportCSV} className="flex items-center gap-2 px-3 py-2 border border-gray-200 rounded-lg text-sm text-gray-600 hover:bg-gray-50 cursor-pointer">
            <Download className="w-4 h-4" /> Export CSV
          </button>
          <button onClick={load} className="p-2 border border-gray-200 rounded-lg text-gray-500 hover:bg-gray-50 cursor-pointer">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>
      <SubNav tabs={[{ id: 'daily', label: '📅 Daily' }, { id: 'weekly', label: '📆 Weekly' }, { id: 'monthly', label: '🗓 Monthly' }, { id: 'conversion', label: '🎯 Conversion' }, { id: 'export', label: '📤 Export' }]} active={sub} onChange={setSub} />

      <div className="grid grid-cols-3 gap-4 mb-5">
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 text-center"><p className="text-2xl font-bold text-gray-900">{totalAll}</p><p className="text-xs text-gray-500 mt-0.5">Total All Time</p></div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 text-center"><p className="text-2xl font-bold text-gray-900">{avg}</p><p className="text-xs text-gray-500 mt-0.5">Avg/Day ({period}d)</p></div>
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 text-center"><p className="text-2xl font-bold text-gray-900">{peak}</p><p className="text-xs text-gray-500 mt-0.5">Peak Day ({period}d)</p></div>
      </div>

      {sub === 'daily' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Daily Leads — Bar Chart</h3>
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#9ca3af' }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
                  <YAxis tick={{ fontSize: 10, fill: '#9ca3af' }} tickLine={false} axisLine={false} allowDecimals={false} />
                  <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e5e7eb', fontSize: 12 }} formatter={(v: number) => [`${v} leads`, 'Leads']} />
                  <Bar dataKey="leads" fill="#FF3B6B" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : <div className="flex items-center justify-center h-[220px] text-gray-400 text-sm">No data for this period</div>}
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Daily Leads — Line Chart</h3>
            {chartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={220}>
                <LineChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="date" tick={{ fontSize: 10, fill: '#9ca3af' }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
                  <YAxis tick={{ fontSize: 10, fill: '#9ca3af' }} tickLine={false} axisLine={false} allowDecimals={false} />
                  <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e5e7eb', fontSize: 12 }} formatter={(v: number) => [`${v} leads`, 'Leads']} />
                  <Line type="monotone" dataKey="leads" stroke="#FF3B6B" strokeWidth={2} dot={{ fill: '#FF3B6B', r: 3 }} activeDot={{ r: 5 }} />
                </LineChart>
              </ResponsiveContainer>
            ) : <div className="flex items-center justify-center h-[220px] text-gray-400 text-sm">No data</div>}
          </div>
        </div>
      )}

      {sub === 'weekly' && (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Weekly Leads</h3>
          {weeklyChartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={weeklyChartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#9ca3af' }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e5e7eb', fontSize: 12 }} formatter={(v: number) => [`${v} leads`, 'Leads']} />
                <Bar dataKey="leads" fill="#8B5CF6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : <div className="flex items-center justify-center h-[280px] text-gray-400 text-sm">No data</div>}
        </div>
      )}

      {sub === 'monthly' && (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Monthly Leads</h3>
          {monthlyChartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={monthlyChartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#9ca3af' }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e5e7eb', fontSize: 12 }} formatter={(v: number) => [`${v} leads`, 'Leads']} />
                <Bar dataKey="leads" fill="#10B981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : <div className="flex items-center justify-center h-[280px] text-gray-400 text-sm">No data</div>}
        </div>
      )}

      {sub === 'conversion' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Leads by CRM Stage</h3>
            {stageData.length > 0 ? (
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie data={stageData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, value }) => `${name}: ${value}`} labelLine={false}>
                    {stageData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ borderRadius: 8, border: '1px solid #e5e7eb', fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            ) : <div className="flex items-center justify-center h-[220px] text-gray-400 text-sm">No data</div>}
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Stage Breakdown</h3>
            {stageData.length > 0 ? (
              <div className="space-y-3">
                {stageData.map((s, i) => (
                  <div key={s.name} className="flex items-center gap-3">
                    <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />
                    <span className="flex-1 text-sm text-gray-700">{s.name}</span>
                    <div className="w-24 bg-gray-100 rounded-full h-2 overflow-hidden">
                      <div className="h-2 rounded-full" style={{ width: `${totalAll > 0 ? (s.value / totalAll) * 100 : 0}%`, background: PIE_COLORS[i % PIE_COLORS.length] }} />
                    </div>
                    <span className="text-sm font-bold text-gray-900 w-6 text-right">{s.value}</span>
                  </div>
                ))}
              </div>
            ) : <p className="text-center py-8 text-gray-400 text-sm">No stage data yet.</p>}
          </div>
        </div>
      )}

      {sub === 'export' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Export Reports</h3>
            <div className="space-y-3">
              {[
                { label: 'Export Daily Leads (Last 7 days)', period: '7', desc: 'Date + count CSV' },
                { label: 'Export Daily Leads (Last 14 days)', period: '14', desc: 'Date + count CSV' },
                { label: 'Export Daily Leads (Last 30 days)', period: '30', desc: 'Date + count CSV' },
              ].map(e => (
                <div key={e.period} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <div>
                    <p className="text-sm font-semibold text-gray-800">{e.label}</p>
                    <p className="text-xs text-gray-400">{e.desc}</p>
                  </div>
                  <button onClick={() => {
                    const rows = [['Date', 'Leads'], ...daily.slice(-parseInt(e.period)).map(d => [d.date, d.count])];
                    const csv = rows.map(r => r.join(',')).join('\n');
                    const blob = new Blob([csv], { type: 'text/csv' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a'); a.href = url; a.download = `leads-${e.period}d.csv`; a.click();
                    URL.revokeObjectURL(url);
                  }} className="flex items-center gap-2 px-3 py-2 bg-[#FF3B6B] text-white text-xs font-semibold rounded-lg cursor-pointer hover:bg-[#e02d5a]">
                    <Download className="w-3.5 h-3.5" /> Download
                  </button>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Export All Leads</h3>
            <p className="text-sm text-gray-500 mb-4">Download your complete lead database as a CSV file with all contact details.</p>
            <a href="/api/registrations/export" download
              className="flex items-center gap-2 px-4 py-3 bg-[#FF3B6B] text-white text-sm font-semibold rounded-lg cursor-pointer hover:bg-[#e02d5a] w-fit">
              <Download className="w-4 h-4" /> Download All Leads (CSV)
            </a>
            <div className="mt-4 p-3 bg-blue-50 border border-blue-100 rounded-lg text-xs text-blue-700">
              📊 Opens in Excel, Google Sheets or any spreadsheet app. Includes Name, Email, WhatsApp, Stage, Date.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReportsTab;
