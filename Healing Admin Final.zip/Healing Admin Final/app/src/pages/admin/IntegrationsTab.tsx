import React, { useState, useEffect } from 'react';
import { Save, Check, RefreshCw, ExternalLink } from 'lucide-react';

const Field = ({ label, value, onChange, type = 'text', hint, placeholder }: {
  label: string; value: string; onChange: (v: string) => void;
  type?: string; hint?: string; placeholder?: string;
}) => (
  <div className="mb-3">
    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">{label}</label>
    <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B] font-mono" />
    {hint && <p className="text-xs text-gray-400 mt-1">{hint}</p>}
  </div>
);

interface Integration {
  id: string;
  name: string;
  logo: string;
  description: string;
  docs: string;
  color: string;
  fields: { key: string; label: string; placeholder: string; hint?: string }[];
}

const INTEGRATIONS: Integration[] = [
  {
    id: 'mailerlite', name: 'MailerLite', logo: '📨', color: '#09c269',
    description: 'Add leads to your MailerLite email list automatically.',
    docs: 'https://developers.mailerlite.com/',
    fields: [
      { key: 'mailerlite_api_key', label: 'API Key', placeholder: 'eyJ0eXAiOiJKV1QiLCJhbGci...', hint: 'Found in MailerLite → Integrations → API' },
      { key: 'mailerlite_group_id', label: 'Group/Segment ID', placeholder: '12345678', hint: 'The list ID to add subscribers to' },
    ],
  },
  {
    id: 'mailchimp', name: 'Mailchimp', logo: '🐵', color: '#FFE01B',
    description: 'Sync leads to a Mailchimp audience.',
    docs: 'https://mailchimp.com/developer/',
    fields: [
      { key: 'mailchimp_api_key', label: 'API Key', placeholder: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx-us1', hint: 'Found in Mailchimp → Account → Extras → API Keys' },
      { key: 'mailchimp_list_id', label: 'Audience/List ID', placeholder: 'abc123de', hint: 'Found in Audience → Settings → Audience name & defaults' },
      { key: 'mailchimp_server', label: 'Server Prefix', placeholder: 'us1', hint: 'Last part of your API key after the dash' },
    ],
  },
  {
    id: 'zapier', name: 'Zapier', logo: '⚡', color: '#FF4A00',
    description: 'Connect to 5000+ apps via Zapier webhooks.',
    docs: 'https://zapier.com/apps/webhook/integrations',
    fields: [
      { key: 'zapier_webhook_url', label: 'Zapier Webhook URL', placeholder: 'https://hooks.zapier.com/hooks/catch/...', hint: 'Create a Zap with Webhook trigger, then paste the URL here' },
    ],
  },
  {
    id: 'google_sheets', name: 'Google Sheets', logo: '📊', color: '#0F9D58',
    description: 'Send lead data to a Google Sheet via Apps Script.',
    docs: 'https://developers.google.com/apps-script',
    fields: [
      { key: 'gsheets_webhook_url', label: 'Apps Script Web App URL', placeholder: 'https://script.google.com/macros/s/.../exec', hint: 'Deploy a Google Apps Script as a web app and paste the URL' },
    ],
  },
  {
    id: 'activecampaign', name: 'ActiveCampaign', logo: '📬', color: '#004CFF',
    description: 'Add leads to ActiveCampaign lists & automations.',
    docs: 'https://developers.activecampaign.com/',
    fields: [
      { key: 'ac_api_url', label: 'API URL', placeholder: 'https://youraccountname.api-us1.com', hint: 'Found in Settings → Developer' },
      { key: 'ac_api_key', label: 'API Key', placeholder: 'xxxxxxxxxxxxxxxx...', hint: 'Found in Settings → Developer' },
      { key: 'ac_list_id', label: 'List ID', placeholder: '1', hint: 'The list to add contacts to' },
    ],
  },
  {
    id: 'whatsapp_api', name: 'WhatsApp Business API', logo: '💬', color: '#25D366',
    description: 'Send automated WhatsApp messages via Meta Business API.',
    docs: 'https://developers.facebook.com/docs/whatsapp',
    fields: [
      { key: 'waba_phone_id', label: 'Phone Number ID', placeholder: '1234567890', hint: 'From Meta Business Manager → WhatsApp → API Setup' },
      { key: 'waba_access_token', label: 'Access Token', placeholder: 'EAAxxxx...', hint: 'Permanent or temporary access token from Meta' },
      { key: 'waba_template_name', label: 'Template Name', placeholder: 'hello_world', hint: 'Approved message template name' },
    ],
  },
];

const IntegrationsTab: React.FC = () => {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState<string | null>(null);
  const [saved, setSaved] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState<string | null>('zapier');

  useEffect(() => {
    fetch('/api/content').then(r => r.json()).then((d: Record<string, string>) => {
      setSettings(d);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const set = (key: string, val: string) => setSettings(s => ({ ...s, [key]: val }));

  const saveIntegration = async (integration: Integration) => {
    setSaving(integration.id);
    const payload: Record<string, string> = {};
    integration.fields.forEach(f => { payload[f.key] = settings[f.key] || ''; });
    await fetch('/api/content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    setSaved(integration.id);
    setTimeout(() => { setSaved(null); setSaving(null); }, 2500);
  };

  const isConfigured = (integration: Integration) =>
    integration.fields.some(f => settings[f.key] && settings[f.key].trim().length > 0);

  if (loading) return <div className="flex items-center justify-center py-20"><RefreshCw className="w-5 h-5 animate-spin text-[#FF3B6B]" /></div>;

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-lg font-bold text-gray-900">Integrations</h2>
        <p className="text-sm text-gray-500 mt-0.5">Connect your landing page to email marketing, CRM, and automation tools</p>
      </div>

      <div className="bg-blue-50 border border-blue-100 rounded-xl p-4 mb-6 text-sm text-blue-700">
        <strong>How it works:</strong> Save your API keys here. Then go to <strong>Automation</strong> tab to create rules that use these integrations (e.g. "When someone registers → Add to MailerLite list").
      </div>

      <div className="space-y-3">
        {INTEGRATIONS.map(integration => {
          const isOpen = expanded === integration.id;
          const configured = isConfigured(integration);
          return (
            <div key={integration.id} className={`bg-white border rounded-xl shadow-sm overflow-hidden transition-all ${configured ? 'border-green-200' : 'border-gray-200'}`}>
              <button
                onClick={() => setExpanded(isOpen ? null : integration.id)}
                className="w-full flex items-center gap-3 px-5 py-4 text-left hover:bg-gray-50 transition-colors cursor-pointer"
              >
                <span className="text-2xl">{integration.logo}</span>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-gray-900">{integration.name}</p>
                    {configured && (
                      <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">✓ Configured</span>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 mt-0.5">{integration.description}</p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <a
                    href={integration.docs}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={e => e.stopPropagation()}
                    className="text-xs text-gray-400 hover:text-blue-500 flex items-center gap-1 px-2 py-1 rounded-lg hover:bg-blue-50 transition-colors"
                  >
                    <ExternalLink className="w-3 h-3" /> Docs
                  </a>
                  <span className={`text-gray-400 text-sm transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}>▼</span>
                </div>
              </button>

              {isOpen && (
                <div className="border-t border-gray-100 px-5 py-4 bg-gray-50">
                  {integration.fields.map(f => (
                    <Field key={f.key} label={f.label} value={settings[f.key] || ''} onChange={v => set(f.key, v)}
                      placeholder={f.placeholder} hint={f.hint} type={f.key.includes('token') || f.key.includes('key') ? 'password' : 'text'} />
                  ))}
                  <button
                    onClick={() => saveIntegration(integration)}
                    disabled={saving === integration.id}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold cursor-pointer transition-all disabled:opacity-60 ${saved === integration.id ? 'bg-green-500 text-white' : 'bg-[#FF3B6B] hover:bg-[#e02d5a] text-white'}`}
                  >
                    {saved === integration.id ? <><Check className="w-4 h-4" /> Saved!</> : <><Save className="w-4 h-4" />{saving === integration.id ? 'Saving…' : `Save ${integration.name}`}</>}
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default IntegrationsTab;
