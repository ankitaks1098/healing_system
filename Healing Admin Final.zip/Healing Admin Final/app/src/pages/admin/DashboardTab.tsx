import React, { useState, useEffect, useCallback } from 'react';
import { Users, TrendingUp, Calendar, Clock, RefreshCw, ExternalLink, Zap, Edit3, MessageCircle, BarChart2 } from 'lucide-react';

interface Stats {
  total: number; today: number; week: number; month: number;
  daily: { date: string; count: string }[];
  byStage: { crm_stage: string; count: string }[];
}
interface Lead { id: number; name: string; email: string; whatsapp: string; created_at: string; crm_stage: string; }

const STAGE_LABELS: Record<string, string> = { new: 'New', contacted: 'Contacted', interested: 'Interested', follow_up: 'Follow Up', converted: 'Converted', lost: 'Lost' };
const STAGE_COLORS: Record<string, string> = { new: 'bg-blue-100 text-blue-700', contacted: 'bg-yellow-100 text-yellow-700', interested: 'bg-purple-100 text-purple-700', follow_up: 'bg-orange-100 text-orange-700', converted: 'bg-green-100 text-green-700', lost: 'bg-red-100 text-red-700' };

const SubNav = ({ tabs, active, onChange }: { tabs: { id: string; label: string }[]; active: string; onChange: (id: string) => void }) => (
  <div className="flex gap-1 border-b border-gray-200 mb-5 overflow-x-auto">
    {tabs.map(t => (
      <button key={t.id} onClick={() => onChange(t.id)}
        className={`px-4 py-2.5 text-sm font-semibold border-b-2 whitespace-nowrap transition-all cursor-pointer ${active === t.id ? 'border-[#FF3B6B] text-[#FF3B6B]' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
        {t.label}
      </button>
    ))}
  </div>
);

const StatCard = ({ icon, label, value, sub, color }: { icon: React.ReactNode; label: string; value: string | number; sub?: string; color: string }) => (
  <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
    <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${color}`}>{icon}</div>
    <p className="text-2xl font-bold text-gray-900">{value}</p>
    <p className="text-sm font-medium text-gray-500 mt-0.5">{label}</p>
    {sub && <p className="text-xs text-gray-400 mt-1">{sub}</p>}
  </div>
);

const MiniBarChart = ({ data }: { data: { date: string; count: string }[] }) => {
  const max = Math.max(...data.map(d => parseInt(d.count)), 1);
  const last14 = data.slice(-14);
  return (
    <div className="flex items-end gap-1 h-16">
      {last14.length === 0 ? <div className="flex-1 flex items-center justify-center text-xs text-gray-400">No data yet</div>
        : last14.map((d, i) => {
          const h = Math.max(4, (parseInt(d.count) / max) * 64);
          return <div key={i} className="flex-1" title={`${d.date}: ${d.count}`}><div className="w-full rounded-t-sm bg-gradient-to-t from-[#FF3B6B] to-[#FF6B8A]" style={{ height: h }} /></div>;
        })}
    </div>
  );
};

const DashboardTab: React.FC = () => {
  const [sub, setSub] = useState('overview');
  const [stats, setStats] = useState<Stats | null>(null);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [sRes, lRes] = await Promise.all([fetch('/api/stats'), fetch('/api/registrations')]);
      setStats(await sRes.json());
      const allLeads = await lRes.json();
      setLeads(allLeads.slice(0, 10));
    } catch { }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  if (loading) return <div className="flex items-center justify-center py-24"><RefreshCw className="w-6 h-6 text-[#FF3B6B] animate-spin" /></div>;

  const total = stats?.total ?? 0;

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Dashboard</h2>
          <p className="text-sm text-gray-500 mt-0.5">Your healing business overview</p>
        </div>
        <div className="flex gap-2">
          <button onClick={load} className="flex items-center gap-2 px-3 py-2 rounded-lg border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 cursor-pointer"><RefreshCw className="w-4 h-4" /> Refresh</button>
          <a href="/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-3 py-2 rounded-lg bg-[#FF3B6B] text-white text-sm font-semibold cursor-pointer hover:bg-[#e02d5a]"><ExternalLink className="w-4 h-4" /> View Page</a>
        </div>
      </div>
      <SubNav tabs={[{ id: 'overview', label: '📊 Overview' }, { id: 'stats', label: '📈 Lead Statistics' }, { id: 'recent', label: '👥 Recent Leads' }, { id: 'actions', label: '⚡ Quick Actions' }]} active={sub} onChange={setSub} />

      {sub === 'overview' && (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
            <StatCard icon={<Users className="w-5 h-5 text-white" />} label="Total Leads" value={total} color="bg-[#FF3B6B]" sub="All time" />
            <StatCard icon={<Clock className="w-5 h-5 text-white" />} label="Today" value={stats?.today ?? 0} color="bg-blue-500" sub="Since midnight" />
            <StatCard icon={<Calendar className="w-5 h-5 text-white" />} label="This Week" value={stats?.week ?? 0} color="bg-purple-500" />
            <StatCard icon={<TrendingUp className="w-5 h-5 text-white" />} label="This Month" value={stats?.month ?? 0} color="bg-green-500" />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-5">
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
              <h3 className="font-semibold text-gray-900 mb-1">Leads — Last 14 Days</h3>
              <p className="text-xs text-gray-400 mb-4">Daily registration activity</p>
              <MiniBarChart data={stats?.daily ?? []} />
              <div className="flex justify-between mt-2 text-xs text-gray-400"><span>14 days ago</span><span>Today</span></div>
            </div>
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
              <h3 className="font-semibold text-gray-900 mb-1">CRM Pipeline</h3>
              <p className="text-xs text-gray-400 mb-4">Leads by stage</p>
              {stats?.byStage && stats.byStage.length > 0 ? (
                <div className="space-y-2">
                  {stats.byStage.map(s => (
                    <div key={s.crm_stage} className="flex items-center gap-3">
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full w-24 text-center flex-shrink-0 ${STAGE_COLORS[s.crm_stage] || 'bg-gray-100 text-gray-600'}`}>{STAGE_LABELS[s.crm_stage] || s.crm_stage}</span>
                      <div className="flex-1 bg-gray-100 rounded-full h-2 overflow-hidden">
                        <div className="h-2 bg-gradient-to-r from-[#FF3B6B] to-[#FF6B8A] rounded-full" style={{ width: `${total > 0 ? (parseInt(s.count) / total) * 100 : 0}%` }} />
                      </div>
                      <span className="text-sm font-bold text-gray-900 w-6 text-right">{s.count}</span>
                    </div>
                  ))}
                </div>
              ) : <p className="text-center py-8 text-gray-400 text-sm">No leads yet.</p>}
            </div>
          </div>
        </>
      )}

      {sub === 'stats' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Lead Volume Summary</h3>
            <div className="space-y-3">
              {[{ label: 'Total All-Time Leads', value: total, icon: '📊' }, { label: 'Today\'s Leads', value: stats?.today ?? 0, icon: '📅' }, { label: 'This Week\'s Leads', value: stats?.week ?? 0, icon: '📆' }, { label: 'This Month\'s Leads', value: stats?.month ?? 0, icon: '🗓' }].map(s => (
                <div key={s.label} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
                  <span className="text-xl">{s.icon}</span>
                  <span className="flex-1 text-sm font-medium text-gray-700">{s.label}</span>
                  <span className="text-lg font-bold text-gray-900">{s.value}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Leads by Stage</h3>
            {stats?.byStage && stats.byStage.length > 0 ? (
              <div className="space-y-3">
                {stats.byStage.map(s => (
                  <div key={s.crm_stage} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                    <div className="flex items-center gap-2">
                      <span className={`w-3 h-3 rounded-full ${s.crm_stage === 'new' ? 'bg-blue-500' : s.crm_stage === 'converted' ? 'bg-green-500' : s.crm_stage === 'lost' ? 'bg-red-400' : 'bg-yellow-500'}`} />
                      <span className="text-sm font-medium text-gray-700">{STAGE_LABELS[s.crm_stage] || s.crm_stage}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-sm text-gray-500">{total > 0 ? Math.round((parseInt(s.count) / total) * 100) : 0}%</span>
                      <span className="text-lg font-bold text-gray-900 w-8 text-right">{s.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            ) : <p className="text-center py-8 text-gray-400 text-sm">No stage data yet.</p>}
          </div>
          <div className="lg:col-span-2 bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <h3 className="font-semibold text-gray-900 mb-4">30-Day Activity Chart</h3>
            <MiniBarChart data={stats?.daily ?? []} />
          </div>
        </div>
      )}

      {sub === 'recent' && (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">Recent Registrations</h3>
            <span className="text-xs text-gray-400">Last 10 leads</span>
          </div>
          {leads.length === 0 ? (
            <div className="text-center py-16 text-gray-400 text-sm">No leads yet. Once people register on your landing page, they'll appear here.</div>
          ) : (
            <div className="divide-y divide-gray-100">
              {leads.map(lead => (
                <div key={lead.id} className="px-5 py-3 flex items-center gap-4 hover:bg-gray-50">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#FF3B6B] to-[#FF6B8A] flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                    {lead.name[0]?.toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 text-sm">{lead.name}</p>
                    <p className="text-xs text-gray-400 truncate">{lead.email} · {lead.whatsapp}</p>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${STAGE_COLORS[lead.crm_stage || 'new'] || 'bg-gray-100 text-gray-600'}`}>{STAGE_LABELS[lead.crm_stage || 'new']}</span>
                    <span className="text-xs text-gray-400">{new Date(lead.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {sub === 'actions' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            { icon: '📋', title: 'View All Leads', desc: 'See every lead with contact details, export as CSV', color: 'bg-blue-500', action: () => window.location.hash = '' },
            { icon: '🎯', title: 'Update CRM Pipeline', desc: 'Move leads through sales stages and add notes', color: 'bg-purple-500', action: () => {} },
            { icon: '✏️', title: 'Edit Landing Page', desc: 'Update hero text, testimonials, FAQ and more', color: 'bg-orange-500', action: () => {} },
            { icon: '📢', title: 'Run A/B Test', desc: 'Test different headlines to improve conversions', color: 'bg-pink-500', action: () => {} },
            { icon: '🔗', title: 'Connect Integration', desc: 'Link MailerLite, Zapier or Google Sheets', color: 'bg-green-500', action: () => {} },
            { icon: '🤖', title: 'Set Up Automation', desc: 'Auto-notify yourself when a new lead comes in', color: 'bg-indigo-500', action: () => {} },
          ].map(a => (
            <div key={a.title} className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow cursor-pointer" onClick={a.action}>
              <div className={`w-11 h-11 ${a.color} rounded-xl flex items-center justify-center text-xl mb-3`}>{a.icon}</div>
              <p className="font-semibold text-gray-900 mb-1">{a.title}</p>
              <p className="text-xs text-gray-500">{a.desc}</p>
            </div>
          ))}
        </div>
      )}

      {sub === 'overview' && (
        <div className="bg-gradient-to-r from-[#FF3B6B] to-[#FF6B8A] rounded-xl p-5 text-white">
          <h3 className="font-bold text-base mb-3">🚀 Quick Tips</h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[{ icon: '📋', title: 'Move Leads Through CRM', desc: 'Go to CRM Pipeline to track which leads you\'ve contacted' }, { icon: '📢', title: 'A/B Test Headlines', desc: 'Try different headlines to see which converts better' }, { icon: '⚡', title: 'Set Up Automations', desc: 'Auto-reply to leads the moment they register' }].map(t => (
              <div key={t.title} className="bg-white/10 rounded-xl p-3">
                <p className="text-lg mb-1">{t.icon}</p>
                <p className="font-semibold text-sm">{t.title}</p>
                <p className="text-xs text-white/70 mt-0.5">{t.desc}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default DashboardTab;
