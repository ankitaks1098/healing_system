import React, { useState, useEffect } from 'react';
import { Save, Check, RefreshCw } from 'lucide-react';

const Field = ({ label, value, onChange, textarea, rows = 3, hint, placeholder }: {
  label: string; value: string; onChange: (v: string) => void;
  textarea?: boolean; rows?: number; hint?: string; placeholder?: string;
}) => (
  <div className="mb-4">
    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">{label}</label>
    {textarea ? (
      <textarea rows={rows} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B] resize-y" />
    ) : (
      <input type="text" value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
        className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B]" />
    )}
    {hint && <p className="text-xs text-gray-400 mt-1">{hint}</p>}
  </div>
);

const SEOTab: React.FC = () => {
  const [s, setS] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/content').then(r => r.json()).then((d: Record<string, string>) => {
      setS({
        seo_title: d.seo_title || 'Divine Healing — 1:1 Energy Healing for All Illnesses',
        seo_description: d.seo_description || 'Experience the power of energy healing from the comfort of your home. Book a FREE 1-on-1 session with expert healer Ankit Kumar.',
        seo_keywords: d.seo_keywords || 'energy healing, spiritual healing, chakra healing, distance healing, online healing session',
        seo_og_image: d.seo_og_image || '',
        seo_og_title: d.seo_og_title || '',
        seo_og_description: d.seo_og_description || '',
        seo_twitter_card: d.seo_twitter_card || 'summary_large_image',
        seo_canonical: d.seo_canonical || '',
        seo_robots: d.seo_robots || 'index, follow',
        seo_schema_name: d.seo_schema_name || 'Ankit Kumar',
        seo_schema_type: d.seo_schema_type || 'HealthcareProvider',
        seo_schema_description: d.seo_schema_description || '',
        seo_gtag_id: d.seo_gtag_id || '',
      });
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const set = (key: string, val: string) => setS(prev => ({ ...prev, [key]: val }));

  const save = async () => {
    setSaving(true);
    await fetch('/api/content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(s) });
    setSaved(true); setTimeout(() => setSaved(false), 2500); setSaving(false);
  };

  const titleLen = (s.seo_title || '').length;
  const descLen = (s.seo_description || '').length;

  if (loading) return <div className="flex items-center justify-center py-20"><RefreshCw className="w-5 h-5 animate-spin text-[#FF3B6B]" /></div>;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-bold text-gray-900">SEO Settings</h2>
          <p className="text-sm text-gray-500 mt-0.5">Optimize your landing page for search engines</p>
        </div>
        <button onClick={save} disabled={saving}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold cursor-pointer transition-all ${saved ? 'bg-green-500 text-white' : 'bg-[#FF3B6B] hover:bg-[#e02d5a] text-white'} disabled:opacity-60`}>
          {saved ? <><Check className="w-4 h-4" /> Saved!</> : <><Save className="w-4 h-4" />{saving ? 'Saving…' : 'Save SEO'}</>}
        </button>
      </div>

      {/* Google Preview */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 mb-4">
        <h3 className="font-semibold text-gray-900 mb-3">🔍 Google Search Preview</h3>
        <div className="border border-gray-200 rounded-xl p-4 bg-gray-50">
          <p className="text-xs text-gray-500 mb-1">https://yoursite.com</p>
          <p className="text-lg text-blue-600 font-medium leading-tight hover:underline cursor-pointer line-clamp-1">
            {s.seo_title || 'Page Title'}
          </p>
          <p className="text-sm text-gray-600 mt-1 line-clamp-2">
            {s.seo_description || 'Meta description will appear here.'}
          </p>
        </div>
        <div className="flex gap-4 mt-3 text-xs">
          <span className={titleLen > 60 ? 'text-red-500' : titleLen > 50 ? 'text-yellow-600' : 'text-green-600'}>
            Title: {titleLen}/60 chars {titleLen > 60 ? '⚠ Too long' : '✓'}
          </span>
          <span className={descLen > 160 ? 'text-red-500' : descLen > 140 ? 'text-yellow-600' : 'text-green-600'}>
            Description: {descLen}/160 chars {descLen > 160 ? '⚠ Too long' : '✓'}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 mb-4">
            <h3 className="font-semibold text-gray-900 mb-4">📄 Basic SEO</h3>
            <Field label={`Meta Title (${titleLen}/60)`} value={s.seo_title} onChange={v => set('seo_title', v)} hint="Keep under 60 characters for best results" />
            <Field label={`Meta Description (${descLen}/160)`} value={s.seo_description} onChange={v => set('seo_description', v)} textarea rows={3} hint="Keep under 160 characters" />
            <Field label="Keywords (comma separated)" value={s.seo_keywords} onChange={v => set('seo_keywords', v)} placeholder="energy healing, spiritual healer, distance healing" />
            <Field label="Canonical URL" value={s.seo_canonical} onChange={v => set('seo_canonical', v)} placeholder="https://yoursite.com" hint="Helps avoid duplicate content issues" />
            <div className="mb-4">
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Robots Directive</label>
              <select value={s.seo_robots} onChange={e => set('seo_robots', e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#FF3B6B]">
                <option value="index, follow">index, follow (default — recommended)</option>
                <option value="noindex, follow">noindex, follow (hide from Google)</option>
                <option value="index, nofollow">index, nofollow</option>
                <option value="noindex, nofollow">noindex, nofollow (block all bots)</option>
              </select>
            </div>
          </div>
        </div>

        <div>
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 mb-4">
            <h3 className="font-semibold text-gray-900 mb-4">🌐 Open Graph (Social Sharing)</h3>
            <p className="text-xs text-gray-500 mb-3">Controls how your page appears when shared on WhatsApp, Facebook, Twitter, etc.</p>
            <Field label="OG Title (leave blank to use Meta Title)" value={s.seo_og_title} onChange={v => set('seo_og_title', v)} />
            <Field label="OG Description (leave blank to use Meta Description)" value={s.seo_og_description} onChange={v => set('seo_og_description', v)} textarea rows={2} />
            <Field label="OG Image URL (1200x630px recommended)" value={s.seo_og_image} onChange={v => set('seo_og_image', v)} placeholder="https://yoursite.com/og-image.jpg" />
            {s.seo_og_image && (
              <img src={s.seo_og_image} alt="OG Preview" className="w-full h-32 object-cover rounded-lg mt-2 border border-gray-200" onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
            )}
            <div className="mb-4 mt-2">
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Twitter Card Type</label>
              <select value={s.seo_twitter_card} onChange={e => set('seo_twitter_card', e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#FF3B6B]">
                <option value="summary_large_image">summary_large_image (large preview)</option>
                <option value="summary">summary (small icon)</option>
              </select>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
            <h3 className="font-semibold text-gray-900 mb-4">🏗 Schema Markup</h3>
            <p className="text-xs text-gray-500 mb-3">Helps Google understand your business and show rich results.</p>
            <Field label="Business/Person Name" value={s.seo_schema_name} onChange={v => set('seo_schema_name', v)} />
            <div className="mb-4">
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Schema Type</label>
              <select value={s.seo_schema_type} onChange={e => set('seo_schema_type', e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:border-[#FF3B6B]">
                <option value="HealthcareProvider">HealthcareProvider</option>
                <option value="Person">Person</option>
                <option value="LocalBusiness">LocalBusiness</option>
                <option value="Organization">Organization</option>
                <option value="Course">Course</option>
                <option value="Event">Event</option>
              </select>
            </div>
            <Field label="Schema Description" value={s.seo_schema_description} onChange={v => set('seo_schema_description', v)} textarea rows={2} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SEOTab;
