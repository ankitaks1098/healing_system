import React, { useState, useEffect, useCallback } from 'react';
import { Plus, Trash2, Save, Check, RefreshCw, X, DollarSign, Package, Settings, Copy } from 'lucide-react';

interface PaymentPackage { id: number; name: string; description: string; amount: number; currency: string; sessions: number; validity_days: number; active: boolean; created_at: string; }
interface Payment { id: number; package_id: number | null; lead_name: string; lead_email: string; lead_phone: string; amount: number; currency: string; status: string; provider: string; provider_id: string; created_at: string; }

const SubNav = ({ tabs, active, onChange }: { tabs: { id: string; label: string }[]; active: string; onChange: (id: string) => void }) => (
  <div className="flex gap-1 border-b border-gray-200 mb-6 overflow-x-auto">
    {tabs.map(t => (
      <button key={t.id} onClick={() => onChange(t.id)}
        className={`px-4 py-2.5 text-sm font-semibold border-b-2 whitespace-nowrap transition-all cursor-pointer ${active === t.id ? 'border-[#FF3B6B] text-[#FF3B6B]' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
        {t.label}
      </button>
    ))}
  </div>
);

const STATUS_COLOR: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-700',
  paid: 'bg-green-100 text-green-700',
  failed: 'bg-red-100 text-red-700',
  refunded: 'bg-gray-100 text-gray-600',
};

const emptyPkg = (): Partial<PaymentPackage> => ({ name: '', description: '', amount: 0, currency: 'INR', sessions: 1, validity_days: 30, active: true });

const PaymentsTab: React.FC = () => {
  const [sub, setSub] = useState('packages');
  const [packages, setPackages] = useState<PaymentPackage[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [config, setConfig] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingPkg, setEditingPkg] = useState<Partial<PaymentPackage>>(emptyPkg());
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState<string | null>(null);
  const [copied, setCopied] = useState('');

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [pkgRes, payRes, cfgRes] = await Promise.all([
        fetch('/api/payment-packages'), fetch('/api/payments'), fetch('/api/content')
      ]);
      setPackages(await pkgRes.json());
      setPayments(await payRes.json());
      const cfg = await cfgRes.json();
      setConfig({ razorpay_key_id: cfg.razorpay_key_id || '', razorpay_key_secret: cfg.razorpay_key_secret || '', stripe_publishable_key: cfg.stripe_publishable_key || '', stripe_secret_key: cfg.stripe_secret_key || '', paypal_client_id: cfg.paypal_client_id || '', default_currency: cfg.default_currency || 'INR' });
    } catch { }
    setLoading(false);
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const savePkg = async () => {
    if (!editingPkg.name) return;
    setSaving(true);
    try {
      const method = editingPkg.id ? 'PUT' : 'POST';
      const url = editingPkg.id ? `/api/payment-packages/${editingPkg.id}` : '/api/payment-packages';
      await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editingPkg) });
      setShowForm(false); setEditingPkg(emptyPkg());
      loadAll();
    } catch { }
    setSaving(false);
  };

  const deletePkg = async (id: number) => {
    if (!confirm('Delete this package?')) return;
    await fetch(`/api/payment-packages/${id}`, { method: 'DELETE' });
    setPackages(p => p.filter(x => x.id !== id));
  };

  const saveConfig = async () => {
    setSaving(true);
    await fetch('/api/content', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(config) });
    setSaved('config'); setTimeout(() => { setSaved(null); setSaving(false); }, 2000);
  };

  const payLink = (pkg: PaymentPackage) => `${window.location.origin}/pay/${pkg.id}`;

  const formatAmount = (amount: number, currency: string) => {
    const sym: Record<string, string> = { INR: '₹', USD: '$', EUR: '€', GBP: '£' };
    return `${sym[currency] || currency}${Number(amount).toLocaleString()}`;
  };

  const totalRevenue = payments.filter(p => p.status === 'paid').reduce((s, p) => s + Number(p.amount), 0);

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Payments & Orders</h2>
          <p className="text-sm text-gray-500 mt-0.5">Manage packages, orders and payment settings</p>
        </div>
        <div className="flex gap-2">
          <button onClick={loadAll} className="p-2 border border-gray-200 rounded-lg text-gray-500 hover:bg-gray-50 cursor-pointer"><RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /></button>
          {sub === 'packages' && (
            <button onClick={() => { setShowForm(true); setEditingPkg(emptyPkg()); }}
              className="flex items-center gap-2 px-4 py-2 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold rounded-lg cursor-pointer">
              <Plus className="w-4 h-4" /> New Package
            </button>
          )}
        </div>
      </div>

      <SubNav tabs={[
        { id: 'packages', label: `📦 Packages (${packages.length})` },
        { id: 'orders', label: `📋 Orders (${payments.length})` },
        { id: 'config', label: '⚙ Payment Config' },
      ]} active={sub} onChange={setSub} />

      {/* Revenue Summary */}
      {sub !== 'config' && (
        <div className="grid grid-cols-3 gap-3 mb-5">
          <div className="bg-white border border-gray-200 rounded-xl p-4 text-center shadow-sm">
            <p className="text-xl font-bold text-green-600">₹{totalRevenue.toLocaleString()}</p>
            <p className="text-xs text-gray-500 mt-0.5">Total Revenue</p>
          </div>
          <div className="bg-white border border-gray-200 rounded-xl p-4 text-center shadow-sm">
            <p className="text-xl font-bold text-gray-900">{payments.filter(p => p.status === 'paid').length}</p>
            <p className="text-xs text-gray-500 mt-0.5">Paid Orders</p>
          </div>
          <div className="bg-white border border-gray-200 rounded-xl p-4 text-center shadow-sm">
            <p className="text-xl font-bold text-yellow-600">{payments.filter(p => p.status === 'pending').length}</p>
            <p className="text-xs text-gray-500 mt-0.5">Pending Orders</p>
          </div>
        </div>
      )}

      {sub === 'packages' && (
        <>
          {showForm && (
            <div className="bg-white border border-gray-200 rounded-xl p-5 mb-5 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900">{editingPkg.id ? 'Edit Package' : 'New Package'}</h3>
                <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-600 cursor-pointer"><X className="w-4 h-4" /></button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                <div className="sm:col-span-2">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Package Name *</label>
                  <input value={editingPkg.name || ''} onChange={e => setEditingPkg(p => ({ ...p, name: e.target.value }))}
                    placeholder="e.g. Single Healing Session, 3-Session Bundle"
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Description</label>
                  <textarea rows={2} value={editingPkg.description || ''} onChange={e => setEditingPkg(p => ({ ...p, description: e.target.value }))}
                    placeholder="What's included in this package..."
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B] resize-none" />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Price *</label>
                  <input type="number" min="0" value={editingPkg.amount || ''} onChange={e => setEditingPkg(p => ({ ...p, amount: parseFloat(e.target.value) }))}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Currency</label>
                  <select value={editingPkg.currency || 'INR'} onChange={e => setEditingPkg(p => ({ ...p, currency: e.target.value }))}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]">
                    <option value="INR">INR (₹)</option><option value="USD">USD ($)</option><option value="EUR">EUR (€)</option><option value="GBP">GBP (£)</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Number of Sessions</label>
                  <input type="number" min="1" value={editingPkg.sessions || 1} onChange={e => setEditingPkg(p => ({ ...p, sessions: parseInt(e.target.value) }))}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Valid for (days)</label>
                  <input type="number" min="1" value={editingPkg.validity_days || 30} onChange={e => setEditingPkg(p => ({ ...p, validity_days: parseInt(e.target.value) }))}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={savePkg} disabled={saving || !editingPkg.name}
                  className="flex items-center gap-2 px-4 py-2 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold rounded-lg cursor-pointer disabled:opacity-60">
                  <Save className="w-4 h-4" />{saving ? 'Saving…' : 'Save Package'}
                </button>
                <button onClick={() => setShowForm(false)} className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-sm cursor-pointer">Cancel</button>
              </div>
            </div>
          )}

          {packages.length === 0 ? (
            <div className="text-center py-16 border-2 border-dashed border-gray-200 rounded-xl text-gray-400">
              <Package className="w-10 h-10 mx-auto mb-3 text-gray-200" />
              <p className="font-semibold">No packages yet</p>
              <p className="text-sm mt-1">Create packages for your healing sessions</p>
              <button onClick={() => { setShowForm(true); setEditingPkg(emptyPkg()); }} className="mt-3 px-4 py-2 bg-[#FF3B6B] text-white text-sm font-semibold rounded-lg cursor-pointer">Create Package</button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {packages.map(pkg => (
                <div key={pkg.id} className={`bg-white border rounded-xl p-5 shadow-sm ${pkg.active ? 'border-gray-200' : 'border-gray-100 opacity-60'}`}>
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="font-bold text-gray-900">{pkg.name}</p>
                      <p className="text-2xl font-black text-[#FF3B6B] mt-1">{formatAmount(pkg.amount, pkg.currency)}</p>
                    </div>
                    <div className="flex gap-1">
                      <button onClick={() => { setEditingPkg(pkg); setShowForm(true); }} className="p-1.5 text-gray-400 hover:text-blue-500 cursor-pointer"><Edit3 className="w-4 h-4" /></button>
                      <button onClick={() => deletePkg(pkg.id)} className="p-1.5 text-gray-400 hover:text-red-500 cursor-pointer"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </div>
                  {pkg.description && <p className="text-sm text-gray-500 mb-3">{pkg.description}</p>}
                  <div className="flex gap-3 text-xs text-gray-500 mb-3">
                    <span>🎯 {pkg.sessions} session{pkg.sessions > 1 ? 's' : ''}</span>
                    <span>📅 Valid {pkg.validity_days} days</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => { navigator.clipboard.writeText(payLink(pkg)); setCopied(String(pkg.id)); setTimeout(() => setCopied(''), 2000); }}
                      className="flex-1 flex items-center justify-center gap-1 text-xs py-2 border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50 cursor-pointer">
                      {copied === String(pkg.id) ? <><Check className="w-3 h-3 text-green-500" /> Copied!</> : <><Copy className="w-3 h-3" /> Copy Pay Link</>}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {sub === 'orders' && (
        payments.length === 0 ? (
          <div className="text-center py-16 text-gray-400 text-sm border-2 border-dashed border-gray-200 rounded-xl">
            <DollarSign className="w-10 h-10 mx-auto mb-3 text-gray-200" />
            <p className="font-semibold">No orders yet</p>
            <p className="mt-1">Orders will appear here once customers pay.</p>
          </div>
        ) : (
          <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
            <table className="w-full text-sm">
              <thead className="border-b border-gray-200 bg-gray-50">
                <tr>
                  {['Date', 'Customer', 'Package', 'Amount', 'Status', 'Provider ID'].map(h => (
                    <th key={h} className="text-left py-3 px-4 text-xs font-semibold text-gray-500">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {payments.map(p => (
                  <tr key={p.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4 text-xs text-gray-500">{new Date(p.created_at).toLocaleDateString()}</td>
                    <td className="py-3 px-4"><p className="font-medium text-gray-900">{p.lead_name}</p><p className="text-xs text-gray-400">{p.lead_email}</p></td>
                    <td className="py-3 px-4 text-xs text-gray-600">{packages.find(pk => pk.id === p.package_id)?.name || '—'}</td>
                    <td className="py-3 px-4 font-semibold text-gray-900">{formatAmount(p.amount, p.currency)}</td>
                    <td className="py-3 px-4"><span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLOR[p.status] || 'bg-gray-100 text-gray-600'}`}>{p.status}</span></td>
                    <td className="py-3 px-4 text-xs text-gray-400 font-mono truncate max-w-[120px]">{p.provider_id || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      )}

      {sub === 'config' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {[
            { id: 'razorpay', name: 'Razorpay', logo: '💳', fields: [{ k: 'razorpay_key_id', l: 'Key ID', ph: 'rzp_live_...' }, { k: 'razorpay_key_secret', l: 'Key Secret', ph: 'Your secret key', type: 'password' }], docs: 'https://razorpay.com/docs/payment-button/', popular: true },
            { id: 'stripe', name: 'Stripe', logo: '⚡', fields: [{ k: 'stripe_publishable_key', l: 'Publishable Key', ph: 'pk_live_...' }, { k: 'stripe_secret_key', l: 'Secret Key', ph: 'sk_live_...', type: 'password' }], docs: 'https://stripe.com/docs/keys' },
            { id: 'paypal', name: 'PayPal', logo: '🅿', fields: [{ k: 'paypal_client_id', l: 'Client ID', ph: 'Your PayPal Client ID' }], docs: 'https://developer.paypal.com/docs/checkout/' },
          ].map(provider => (
            <div key={provider.id} className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <span className="text-2xl">{provider.logo}</span>
                <div>
                  <h3 className="font-semibold text-gray-900">{provider.name}</h3>
                  {provider.popular && <span className="text-xs bg-[#FF3B6B]/10 text-[#FF3B6B] px-2 py-0.5 rounded-full font-medium">Recommended for India</span>}
                </div>
              </div>
              {provider.fields.map(f => (
                <div key={f.k} className="mb-3">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">{f.l}</label>
                  <input type={(f as { type?: string }).type || 'text'} value={config[f.k] || ''} onChange={e => setConfig(c => ({ ...c, [f.k]: e.target.value }))}
                    placeholder={f.ph}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B] font-mono" />
                </div>
              ))}
              <div className="flex gap-2 mt-3">
                <button onClick={saveConfig} disabled={saving}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-semibold cursor-pointer ${saved === 'config' ? 'bg-green-500 text-white' : 'bg-[#FF3B6B] hover:bg-[#e02d5a] text-white'}`}>
                  {saved === 'config' ? <><Check className="w-3 h-3" /> Saved!</> : <><Save className="w-3 h-3" /> Save</>}
                </button>
                <a href={provider.docs} target="_blank" rel="noopener noreferrer"
                  className="flex items-center px-3 py-2 rounded-lg text-xs font-semibold border border-gray-200 text-gray-600 hover:bg-gray-50 cursor-pointer">Get API Keys ↗</a>
              </div>
            </div>
          ))}
          <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
            <h3 className="font-semibold text-gray-900 mb-4">General Settings</h3>
            <div>
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Default Currency</label>
              <select value={config.default_currency || 'INR'} onChange={e => setConfig(c => ({ ...c, default_currency: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]">
                <option value="INR">INR (₹ Indian Rupee)</option>
                <option value="USD">USD ($ US Dollar)</option>
                <option value="EUR">EUR (€ Euro)</option>
                <option value="GBP">GBP (£ British Pound)</option>
              </select>
            </div>
            <div className="mt-4 p-3 bg-blue-50 border border-blue-100 rounded-lg text-xs text-blue-700">
              💡 <strong>Razorpay</strong> is recommended for Indian businesses. It accepts UPI, cards, net banking, and wallets with zero setup.
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PaymentsTab;
