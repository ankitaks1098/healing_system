import React, { useState, useEffect, useCallback } from 'react';
import {
  Plus, Trash2, Save, Check, RefreshCw, X, Copy, Eye, Edit3, ChevronUp, ChevronDown, Code, FileText, BarChart2
} from 'lucide-react';

interface FieldDef {
  id: string;
  type: 'text' | 'email' | 'phone' | 'textarea' | 'select' | 'checkbox' | 'radio' | 'number' | 'date';
  label: string;
  placeholder: string;
  required: boolean;
  options: string[];
  helpText: string;
}

interface Form {
  id: number;
  name: string;
  description: string;
  fields: FieldDef[];
  settings: Record<string, string>;
  active: boolean;
  created_at: string;
}

interface Submission {
  id: number;
  data: Record<string, string>;
  created_at: string;
}

const FIELD_TYPES = [
  { type: 'text', label: '📝 Short Text', icon: '📝' },
  { type: 'email', label: '📧 Email', icon: '📧' },
  { type: 'phone', label: '📱 Phone', icon: '📱' },
  { type: 'number', label: '🔢 Number', icon: '🔢' },
  { type: 'textarea', label: '📄 Long Text', icon: '📄' },
  { type: 'select', label: '📋 Dropdown', icon: '📋' },
  { type: 'radio', label: '🔘 Radio', icon: '🔘' },
  { type: 'checkbox', label: '☑️ Checkbox', icon: '☑️' },
  { type: 'date', label: '📅 Date', icon: '📅' },
];

const mkField = (type: FieldDef['type']): FieldDef => ({
  id: `f_${Date.now()}_${Math.random().toString(36).slice(2,6)}`,
  type, label: `${type.charAt(0).toUpperCase() + type.slice(1)} Field`,
  placeholder: '', required: false, options: type === 'select' || type === 'radio' ? ['Option 1', 'Option 2'] : [],
  helpText: '',
});

const SubNav = ({ tabs, active, onChange }: { tabs: { id: string; label: string; icon: React.ReactNode }[]; active: string; onChange: (id: string) => void }) => (
  <div className="flex gap-1 border-b border-gray-200 mb-6 overflow-x-auto">
    {tabs.map(t => (
      <button key={t.id} onClick={() => onChange(t.id)}
        className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-semibold border-b-2 whitespace-nowrap transition-all cursor-pointer ${active === t.id ? 'border-[#FF3B6B] text-[#FF3B6B]' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
        {t.icon}{t.label}
      </button>
    ))}
  </div>
);

const FieldEditor = ({ field, onChange, onDelete, onMove, isFirst, isLast }: {
  field: FieldDef; onChange: (f: FieldDef) => void; onDelete: () => void;
  onMove: (dir: -1 | 1) => void; isFirst: boolean; isLast: boolean;
}) => {
  const [expanded, setExpanded] = useState(true);
  const set = (key: keyof FieldDef, val: unknown) => onChange({ ...field, [key]: val });
  const setOption = (i: number, val: string) => {
    const opts = [...field.options]; opts[i] = val; set('options', opts);
  };
  const addOption = () => set('options', [...field.options, `Option ${field.options.length + 1}`]);
  const removeOption = (i: number) => set('options', field.options.filter((_, idx) => idx !== i));

  return (
    <div className="bg-white border border-gray-200 rounded-xl mb-3 overflow-hidden shadow-sm">
      <div className="flex items-center gap-3 px-4 py-3 bg-gray-50 cursor-pointer" onClick={() => setExpanded(e => !e)}>
        <span className="text-base">{FIELD_TYPES.find(t => t.type === field.type)?.icon || '📝'}</span>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-gray-800">{field.label || 'Untitled Field'}</p>
          <p className="text-xs text-gray-400">{field.type}{field.required ? ' · Required' : ''}</p>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={e => { e.stopPropagation(); onMove(-1); }} disabled={isFirst} className="p-1 text-gray-400 hover:text-gray-600 disabled:opacity-30 cursor-pointer"><ChevronUp className="w-4 h-4" /></button>
          <button onClick={e => { e.stopPropagation(); onMove(1); }} disabled={isLast} className="p-1 text-gray-400 hover:text-gray-600 disabled:opacity-30 cursor-pointer"><ChevronDown className="w-4 h-4" /></button>
          <button onClick={e => { e.stopPropagation(); onDelete(); }} className="p-1 text-red-400 hover:text-red-600 cursor-pointer"><Trash2 className="w-4 h-4" /></button>
          <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${expanded ? 'rotate-180' : ''}`} />
        </div>
      </div>
      {expanded && (
        <div className="p-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Label</label>
            <input value={field.label} onChange={e => set('label', e.target.value)}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
          </div>
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Field Type</label>
            <select value={field.type} onChange={e => set('type', e.target.value)}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]">
              {FIELD_TYPES.map(t => <option key={t.type} value={t.type}>{t.label}</option>)}
            </select>
          </div>
          {field.type !== 'checkbox' && field.type !== 'select' && field.type !== 'radio' && (
            <div>
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Placeholder</label>
              <input value={field.placeholder} onChange={e => set('placeholder', e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
            </div>
          )}
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Help Text</label>
            <input value={field.helpText} onChange={e => set('helpText', e.target.value)} placeholder="Optional hint below field"
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
          </div>
          <div className="flex items-center gap-2">
            <input type="checkbox" id={`req_${field.id}`} checked={field.required} onChange={e => set('required', e.target.checked)} className="w-4 h-4 accent-[#FF3B6B]" />
            <label htmlFor={`req_${field.id}`} className="text-sm font-medium text-gray-700 cursor-pointer">Required field</label>
          </div>
          {(field.type === 'select' || field.type === 'radio') && (
            <div className="sm:col-span-2">
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-2">Options</label>
              <div className="space-y-2">
                {field.options.map((opt, i) => (
                  <div key={i} className="flex gap-2">
                    <input value={opt} onChange={e => setOption(i, e.target.value)}
                      className="flex-1 border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:border-[#FF3B6B]" />
                    <button onClick={() => removeOption(i)} className="text-red-400 hover:text-red-600 cursor-pointer"><X className="w-4 h-4" /></button>
                  </div>
                ))}
                <button onClick={addOption} className="text-xs text-[#FF3B6B] hover:text-[#e02d5a] font-semibold flex items-center gap-1 cursor-pointer">
                  <Plus className="w-3 h-3" /> Add Option
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const FormPreview = ({ fields }: { fields: FieldDef[] }) => (
  <div className="bg-white rounded-xl border border-gray-200 p-5 shadow-sm">
    <h4 className="font-semibold text-gray-700 mb-4 text-sm">Form Preview</h4>
    {fields.length === 0 ? (
      <div className="text-center py-8 text-gray-400 text-sm border-2 border-dashed border-gray-200 rounded-xl">Add fields to preview</div>
    ) : (
      <div className="space-y-4">
        {fields.map(f => (
          <div key={f.id}>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              {f.label}{f.required && <span className="text-red-500 ml-1">*</span>}
            </label>
            {f.type === 'textarea' && <textarea rows={3} placeholder={f.placeholder} disabled className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-gray-50" />}
            {(f.type === 'select') && (
              <select disabled className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-gray-50">
                <option value="">Select an option</option>
                {f.options.map(o => <option key={o} value={o}>{o}</option>)}
              </select>
            )}
            {f.type === 'radio' && (
              <div className="space-y-1">
                {f.options.map(o => (
                  <label key={o} className="flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                    <input type="radio" disabled className="accent-[#FF3B6B]" />{o}
                  </label>
                ))}
              </div>
            )}
            {f.type === 'checkbox' && (
              <label className="flex items-center gap-2 text-sm text-gray-700 cursor-pointer">
                <input type="checkbox" disabled className="accent-[#FF3B6B]" />{f.label}
              </label>
            )}
            {!['textarea', 'select', 'radio', 'checkbox'].includes(f.type) && (
              <input type={f.type} placeholder={f.placeholder} disabled className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm bg-gray-50" />
            )}
            {f.helpText && <p className="text-xs text-gray-400 mt-1">{f.helpText}</p>}
          </div>
        ))}
        <button className="w-full py-2.5 bg-gradient-to-r from-[#FF3B6B] to-[#FF6B8A] text-white font-semibold rounded-lg text-sm cursor-not-allowed">Submit</button>
      </div>
    )}
  </div>
);

const SubmissionsView = ({ formId, formFields }: { formId: number; formFields: FieldDef[] }) => {
  const [subs, setSubs] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/forms/${formId}/submissions`).then(r => r.json()).then(setSubs).catch(() => {}).finally(() => setLoading(false));
  }, [formId]);

  if (loading) return <div className="flex justify-center py-10"><RefreshCw className="w-5 h-5 animate-spin text-[#FF3B6B]" /></div>;
  if (subs.length === 0) return (
    <div className="text-center py-16 text-gray-400">
      <FileText className="w-10 h-10 mx-auto mb-3 text-gray-200" />
      <p className="font-semibold">No submissions yet</p>
      <p className="text-sm mt-1">Submissions will appear here once people fill out the form.</p>
    </div>
  );

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-gray-200">
            <th className="text-left py-2 px-3 text-xs font-semibold text-gray-500">Date</th>
            {formFields.map(f => <th key={f.id} className="text-left py-2 px-3 text-xs font-semibold text-gray-500">{f.label}</th>)}
          </tr>
        </thead>
        <tbody>
          {subs.map(s => (
            <tr key={s.id} className="border-b border-gray-100 hover:bg-gray-50">
              <td className="py-2 px-3 text-xs text-gray-500">{new Date(s.created_at).toLocaleDateString()}</td>
              {formFields.map(f => <td key={f.id} className="py-2 px-3 text-sm text-gray-700">{s.data[f.id] || '-'}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const FormBuilderTab: React.FC = () => {
  const [sub, setSub] = useState('forms');
  const [forms, setForms] = useState<Form[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Form | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [viewSub, setViewSub] = useState<Form | null>(null);
  const [copiedEmbed, setCopiedEmbed] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try { const r = await fetch('/api/forms'); setForms(await r.json()); } catch { }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const newForm = () => {
    setEditing({ id: 0, name: 'New Form', description: '', fields: [], settings: { submitLabel: 'Submit', successMessage: 'Thank you! We will get back to you shortly.' }, active: true, created_at: '' });
    setSub('builder');
  };

  const editForm = (f: Form) => { setEditing(f); setSub('builder'); };

  const saveForm = async () => {
    if (!editing) return;
    setSaving(true);
    try {
      const method = editing.id ? 'PUT' : 'POST';
      const url = editing.id ? `/api/forms/${editing.id}` : '/api/forms';
      const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editing) });
      const saved_ = await r.json();
      setEditing(saved_);
      setSaved(true); setTimeout(() => setSaved(false), 2000);
      load();
    } catch { }
    setSaving(false);
  };

  const deleteForm = async (id: number) => {
    if (!confirm('Delete this form and all its submissions?')) return;
    await fetch(`/api/forms/${id}`, { method: 'DELETE' });
    load();
  };

  const addField = (type: FieldDef['type']) => {
    if (!editing) return;
    setEditing(e => e ? { ...e, fields: [...e.fields, mkField(type)] } : e);
  };

  const updateField = (idx: number, f: FieldDef) => {
    if (!editing) return;
    const fields = [...editing.fields]; fields[idx] = f;
    setEditing(e => e ? { ...e, fields } : e);
  };

  const deleteField = (idx: number) => {
    if (!editing) return;
    setEditing(e => e ? { ...e, fields: e.fields.filter((_, i) => i !== idx) } : e);
  };

  const moveField = (idx: number, dir: -1 | 1) => {
    if (!editing) return;
    const fields = [...editing.fields];
    const to = idx + dir;
    if (to < 0 || to >= fields.length) return;
    [fields[idx], fields[to]] = [fields[to], fields[idx]];
    setEditing(e => e ? { ...e, fields } : e);
  };

  const embedCode = (form: Form) => `<!-- Divine Healing Form: ${form.name} -->
<script>
  (function() {
    var iframe = document.createElement('iframe');
    iframe.src = '${window.location.origin}/form/${form.id}';
    iframe.style.width = '100%';
    iframe.style.border = 'none';
    iframe.style.minHeight = '400px';
    document.currentScript.parentNode.insertBefore(iframe, document.currentScript);
  })();
</script>`;

  const TABS = [
    { id: 'forms', label: 'My Forms', icon: <FileText className="w-3.5 h-3.5" /> },
    { id: 'builder', label: editing ? `Editing: ${editing.name}` : 'Builder', icon: <Edit3 className="w-3.5 h-3.5" /> },
    ...(viewSub ? [{ id: 'submissions', label: 'Submissions', icon: <BarChart2 className="w-3.5 h-3.5" /> }] : []),
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Form Builder</h2>
          <p className="text-sm text-gray-500 mt-0.5">Build custom forms and embed them anywhere</p>
        </div>
        <button onClick={newForm} className="flex items-center gap-2 px-4 py-2 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold rounded-lg cursor-pointer">
          <Plus className="w-4 h-4" /> New Form
        </button>
      </div>
      <SubNav tabs={TABS} active={sub} onChange={setSub} />

      {sub === 'forms' && (
        loading ? <div className="flex justify-center py-16"><RefreshCw className="w-5 h-5 animate-spin text-[#FF3B6B]" /></div>
        : forms.length === 0 ? (
          <div className="border-2 border-dashed border-gray-200 rounded-xl p-14 text-center">
            <FileText className="w-10 h-10 text-gray-200 mx-auto mb-3" />
            <p className="font-semibold text-gray-500">No forms yet</p>
            <p className="text-gray-400 text-sm mt-1">Create your first form to capture leads.</p>
            <button onClick={newForm} className="mt-4 px-4 py-2 bg-[#FF3B6B] text-white rounded-lg text-sm font-semibold cursor-pointer">Create Form</button>
          </div>
        ) : (
          <div className="space-y-3">
            {forms.map(f => (
              <div key={f.id} className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm flex items-center gap-4">
                <div className="w-10 h-10 bg-[#FF3B6B]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                  <FileText className="w-5 h-5 text-[#FF3B6B]" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-gray-900">{f.name}</p>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${f.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                      {f.active ? '● Active' : '◌ Inactive'}
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 mt-0.5">{f.fields?.length || 0} fields · Created {new Date(f.created_at).toLocaleDateString()}</p>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => { setViewSub(f); setSub('submissions'); }}
                    className="text-xs px-3 py-1.5 border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50 cursor-pointer flex items-center gap-1">
                    <Eye className="w-3.5 h-3.5" /> Submissions
                  </button>
                  <button onClick={() => { navigator.clipboard.writeText(embedCode(f)); setCopiedEmbed(true); setTimeout(() => setCopiedEmbed(false), 2000); }}
                    className="text-xs px-3 py-1.5 border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50 cursor-pointer flex items-center gap-1">
                    {copiedEmbed ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Code className="w-3.5 h-3.5" />} Embed
                  </button>
                  <button onClick={() => editForm(f)} className="text-xs px-3 py-1.5 bg-[#FF3B6B] text-white rounded-lg hover:bg-[#e02d5a] cursor-pointer">Edit</button>
                  <button onClick={() => deleteForm(f.id)} className="p-1.5 text-gray-400 hover:text-red-500 cursor-pointer"><Trash2 className="w-4 h-4" /></button>
                </div>
              </div>
            ))}
          </div>
        )
      )}

      {sub === 'builder' && editing && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          <div className="lg:col-span-2">
            <div className="bg-white border border-gray-200 rounded-xl p-4 mb-4 shadow-sm">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Form Name</label>
                  <input value={editing.name} onChange={e => setEditing(f => f ? { ...f, name: e.target.value } : f)}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Submit Button Label</label>
                  <input value={editing.settings?.submitLabel || 'Submit'} onChange={e => setEditing(f => f ? { ...f, settings: { ...f.settings, submitLabel: e.target.value } } : f)}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Success Message</label>
                  <input value={editing.settings?.successMessage || ''} onChange={e => setEditing(f => f ? { ...f, settings: { ...f.settings, successMessage: e.target.value } } : f)}
                    className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={saveForm} disabled={saving}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold cursor-pointer ${saved ? 'bg-green-500 text-white' : 'bg-[#FF3B6B] hover:bg-[#e02d5a] text-white'} disabled:opacity-60`}>
                  {saved ? <><Check className="w-4 h-4" /> Saved!</> : <><Save className="w-4 h-4" />{saving ? 'Saving…' : 'Save Form'}</>}
                </button>
                <button onClick={() => setSub('forms')} className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-sm cursor-pointer">← Back to Forms</button>
              </div>
            </div>

            <div>
              {editing.fields.map((field, i) => (
                <FieldEditor key={field.id} field={field} onChange={f => updateField(i, f)}
                  onDelete={() => deleteField(i)} onMove={dir => moveField(i, dir)}
                  isFirst={i === 0} isLast={i === editing.fields.length - 1} />
              ))}
              {editing.fields.length === 0 && (
                <div className="border-2 border-dashed border-gray-200 rounded-xl p-8 text-center text-gray-400 text-sm">
                  ← Click a field type on the right to add it to your form
                </div>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm">
              <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-3">Add Field</h4>
              <div className="grid grid-cols-2 gap-2">
                {FIELD_TYPES.map(t => (
                  <button key={t.type} onClick={() => addField(t.type as FieldDef['type'])}
                    className="flex items-center gap-2 px-2 py-2 border border-gray-200 rounded-lg text-xs text-gray-700 hover:bg-[#FF3B6B]/5 hover:border-[#FF3B6B]/30 cursor-pointer transition-all">
                    <span>{t.icon}</span>{t.label.split(' ').slice(1).join(' ')}
                  </button>
                ))}
              </div>
            </div>
            <FormPreview fields={editing.fields} />
          </div>
        </div>
      )}

      {sub === 'submissions' && viewSub && (
        <div>
          <div className="flex items-center gap-3 mb-4">
            <button onClick={() => setSub('forms')} className="text-sm text-gray-500 hover:text-gray-700 cursor-pointer">← Forms</button>
            <span className="text-gray-300">/</span>
            <span className="text-sm font-semibold text-gray-900">{viewSub.name} — Submissions</span>
          </div>
          <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden p-4">
            <SubmissionsView formId={viewSub.id} formFields={viewSub.fields} />
          </div>
        </div>
      )}
    </div>
  );
};

export default FormBuilderTab;
