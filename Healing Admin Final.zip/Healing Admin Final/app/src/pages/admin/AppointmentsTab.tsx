import React, { useState, useEffect, useCallback } from 'react';
import { Plus, RefreshCw, Check, X, Calendar, Clock, User, Phone, Mail, Edit3, Trash2, Save } from 'lucide-react';

interface Slot { id: number; day_of_week: number; time_slot: string; duration_mins: number; active: boolean; }
interface Appointment {
  id: number; lead_name: string; lead_email: string; lead_phone: string;
  appointment_date: string; time_slot: string; duration_mins: number;
  status: 'pending' | 'confirmed' | 'cancelled' | 'completed';
  notes: string; admin_notes: string; created_at: string;
}

const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const DAY_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const TIME_OPTIONS = [
  '06:00','07:00','08:00','09:00','09:30','10:00','10:30','11:00','11:30',
  '12:00','13:00','14:00','14:30','15:00','15:30','16:00','16:30',
  '17:00','18:00','19:00','20:00','21:00',
];

const STATUS_STYLE: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-700',
  confirmed: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
  completed: 'bg-blue-100 text-blue-700',
};

const SubNav = ({ tabs, active, onChange }: { tabs: { id: string; label: string }[]; active: string; onChange: (id: string) => void }) => (
  <div className="flex gap-1 border-b border-gray-200 mb-6 overflow-x-auto">
    {tabs.map(t => (
      <button key={t.id} onClick={() => onChange(t.id)}
        className={`px-4 py-2.5 text-sm font-semibold border-b-2 whitespace-nowrap transition-all cursor-pointer ${active === t.id ? 'border-[#FF3B6B] text-[#FF3B6B]' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
        {t.label}
      </button>
    ))}
  </div>
);

const AppointmentsTab: React.FC = () => {
  const [sub, setSub] = useState('upcoming');
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [slots, setSlots] = useState<Slot[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingAppt, setEditingAppt] = useState<Appointment | null>(null);
  const [form, setForm] = useState({ lead_name: '', lead_email: '', lead_phone: '', appointment_date: '', time_slot: '10:00', duration_mins: '60', notes: '' });
  const [saving, setSaving] = useState(false);
  const [newSlot, setNewSlot] = useState({ day_of_week: '1', time_slot: '10:00', duration_mins: '60' });

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [aRes, sRes] = await Promise.all([fetch('/api/appointments'), fetch('/api/slots')]);
      setAppointments(await aRes.json());
      setSlots(await sRes.json());
    } catch { }
    setLoading(false);
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);

  const saveAppointment = async () => {
    if (!form.lead_name || !form.appointment_date) return;
    setSaving(true);
    try {
      const method = editingAppt ? 'PUT' : 'POST';
      const url = editingAppt ? `/api/appointments/${editingAppt.id}` : '/api/appointments';
      await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...form, duration_mins: parseInt(form.duration_mins) }) });
      setShowForm(false); setEditingAppt(null);
      setForm({ lead_name: '', lead_email: '', lead_phone: '', appointment_date: '', time_slot: '10:00', duration_mins: '60', notes: '' });
      loadAll();
    } catch { }
    setSaving(false);
  };

  const updateStatus = async (id: number, status: string) => {
    await fetch(`/api/appointments/${id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) });
    setAppointments(a => a.map(x => x.id === id ? { ...x, status: status as Appointment['status'] } : x));
  };

  const deleteAppt = async (id: number) => {
    if (!confirm('Delete this appointment?')) return;
    await fetch(`/api/appointments/${id}`, { method: 'DELETE' });
    setAppointments(a => a.filter(x => x.id !== id));
  };

  const addSlot = async () => {
    await fetch('/api/slots', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...newSlot, day_of_week: parseInt(newSlot.day_of_week), duration_mins: parseInt(newSlot.duration_mins) }) });
    loadAll();
  };

  const toggleSlot = async (slot: Slot) => {
    await fetch(`/api/slots/${slot.id}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ active: !slot.active }) });
    setSlots(s => s.map(x => x.id === slot.id ? { ...x, active: !x.active } : x));
  };

  const deleteSlot = async (id: number) => {
    await fetch(`/api/slots/${id}`, { method: 'DELETE' });
    setSlots(s => s.filter(x => x.id !== id));
  };

  const today = new Date();
  const upcoming = appointments.filter(a => new Date(a.appointment_date) >= today && a.status !== 'cancelled').sort((a, b) => a.appointment_date.localeCompare(b.appointment_date));
  const past = appointments.filter(a => new Date(a.appointment_date) < today || a.status === 'completed').sort((a, b) => b.appointment_date.localeCompare(a.appointment_date));
  const all = [...appointments].sort((a, b) => b.appointment_date.localeCompare(a.appointment_date));

  const ApptCard = ({ a }: { a: Appointment }) => (
    <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-[#FF3B6B]/10 flex flex-col items-center justify-center text-[#FF3B6B] flex-shrink-0">
            <span className="text-xs font-bold">{new Date(a.appointment_date).getDate()}</span>
            <span className="text-[10px]">{DAY_SHORT[new Date(a.appointment_date + 'T12:00:00').getDay()]}</span>
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <p className="font-semibold text-gray-900">{a.lead_name}</p>
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_STYLE[a.status] || 'bg-gray-100 text-gray-600'}`}>{a.status}</span>
            </div>
            <div className="flex items-center gap-3 mt-0.5 flex-wrap text-xs text-gray-500">
              <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{a.time_slot} ({a.duration_mins}min)</span>
              {a.lead_phone && <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{a.lead_phone}</span>}
              {a.lead_email && <span className="flex items-center gap-1"><Mail className="w-3 h-3" />{a.lead_email}</span>}
            </div>
            {a.notes && <p className="text-xs text-gray-400 mt-1 italic">"{a.notes}"</p>}
          </div>
        </div>
        <div className="flex items-center gap-1 flex-shrink-0">
          {a.status === 'pending' && (
            <button onClick={() => updateStatus(a.id, 'confirmed')}
              className="text-xs px-2.5 py-1 bg-green-500 text-white rounded-lg hover:bg-green-600 cursor-pointer">Confirm</button>
          )}
          {a.status === 'confirmed' && (
            <button onClick={() => updateStatus(a.id, 'completed')}
              className="text-xs px-2.5 py-1 bg-blue-500 text-white rounded-lg hover:bg-blue-600 cursor-pointer">Done</button>
          )}
          <select value={a.status} onChange={e => updateStatus(a.id, e.target.value)}
            className="text-xs border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:border-[#FF3B6B] cursor-pointer">
            <option value="pending">Pending</option>
            <option value="confirmed">Confirmed</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
          <button onClick={() => deleteAppt(a.id)} className="p-1 text-gray-400 hover:text-red-500 cursor-pointer"><Trash2 className="w-4 h-4" /></button>
        </div>
      </div>
    </div>
  );

  const BookingForm = () => (
    <div className="bg-white border border-gray-200 rounded-xl p-5 mb-5 shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold text-gray-900">{editingAppt ? 'Edit Appointment' : 'New Appointment'}</h3>
        <button onClick={() => { setShowForm(false); setEditingAppt(null); }} className="text-gray-400 hover:text-gray-600 cursor-pointer"><X className="w-4 h-4" /></button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
        {[['lead_name', 'Name *', 'text'], ['lead_email', 'Email', 'email'], ['lead_phone', 'Phone', 'tel']].map(([k, l, t]) => (
          <div key={k}>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">{l}</label>
            <input type={t} value={(form as Record<string, string>)[k]} onChange={e => setForm(f => ({ ...f, [k]: e.target.value }))}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
          </div>
        ))}
        <div>
          <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Date *</label>
          <input type="date" value={form.appointment_date} onChange={e => setForm(f => ({ ...f, appointment_date: e.target.value }))}
            className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
        </div>
        <div>
          <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Time</label>
          <select value={form.time_slot} onChange={e => setForm(f => ({ ...f, time_slot: e.target.value }))}
            className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]">
            {TIME_OPTIONS.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Duration</label>
          <select value={form.duration_mins} onChange={e => setForm(f => ({ ...f, duration_mins: e.target.value }))}
            className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]">
            <option value="30">30 minutes</option>
            <option value="45">45 minutes</option>
            <option value="60">60 minutes (1 hour)</option>
            <option value="90">90 minutes</option>
          </select>
        </div>
        <div className="sm:col-span-2">
          <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Notes</label>
          <textarea rows={2} value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Session topic, concerns, etc."
            className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B] resize-none" />
        </div>
      </div>
      <div className="flex gap-2">
        <button onClick={saveAppointment} disabled={saving || !form.lead_name || !form.appointment_date}
          className="flex items-center gap-2 px-4 py-2 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold rounded-lg cursor-pointer disabled:opacity-60">
          <Save className="w-4 h-4" />{saving ? 'Saving…' : 'Save Appointment'}
        </button>
        <button onClick={() => { setShowForm(false); setEditingAppt(null); }} className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-sm cursor-pointer">Cancel</button>
      </div>
    </div>
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Appointment Booking</h2>
          <p className="text-sm text-gray-500 mt-0.5">Manage healing sessions and availability</p>
        </div>
        <button onClick={() => { setShowForm(true); setEditingAppt(null); }}
          className="flex items-center gap-2 px-4 py-2 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold rounded-lg cursor-pointer">
          <Plus className="w-4 h-4" /> Book Appointment
        </button>
      </div>
      <SubNav tabs={[{ id: 'upcoming', label: `Upcoming (${upcoming.length})` }, { id: 'all', label: `All (${all.length})` }, { id: 'settings', label: '⚙ Availability' }]} active={sub} onChange={setSub} />

      {showForm && <BookingForm />}

      {sub === 'upcoming' && (
        loading ? <div className="flex justify-center py-16"><RefreshCw className="w-5 h-5 animate-spin text-[#FF3B6B]" /></div>
        : upcoming.length === 0 ? (
          <div className="text-center py-16 text-gray-400 border-2 border-dashed border-gray-200 rounded-xl">
            <Calendar className="w-10 h-10 mx-auto mb-3 text-gray-200" />
            <p className="font-semibold">No upcoming appointments</p>
            <button onClick={() => setShowForm(true)} className="mt-3 px-4 py-2 bg-[#FF3B6B] text-white text-sm font-semibold rounded-lg cursor-pointer">Book First Appointment</button>
          </div>
        ) : (
          <div className="space-y-3">{upcoming.map(a => <ApptCard key={a.id} a={a} />)}</div>
        )
      )}

      {sub === 'all' && (
        loading ? <div className="flex justify-center py-16"><RefreshCw className="w-5 h-5 animate-spin text-[#FF3B6B]" /></div>
        : all.length === 0 ? (
          <div className="text-center py-16 text-gray-400 text-sm">No appointments yet.</div>
        ) : (
          <div>
            <div className="grid grid-cols-4 gap-3 mb-5">
              {['pending', 'confirmed', 'completed', 'cancelled'].map(s => (
                <div key={s} className={`text-center p-3 rounded-xl border ${STATUS_STYLE[s]} bg-opacity-50`}>
                  <p className="text-xl font-bold">{appointments.filter(a => a.status === s).length}</p>
                  <p className="text-xs capitalize">{s}</p>
                </div>
              ))}
            </div>
            <div className="space-y-3">{all.map(a => <ApptCard key={a.id} a={a} />)}</div>
          </div>
        )
      )}

      {sub === 'settings' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
            <h3 className="font-semibold text-gray-900 mb-4">Add Available Time Slot</h3>
            <div className="grid grid-cols-3 gap-3 mb-3">
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Day</label>
                <select value={newSlot.day_of_week} onChange={e => setNewSlot(s => ({ ...s, day_of_week: e.target.value }))}
                  className="w-full border border-gray-200 rounded-lg px-2 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]">
                  {DAYS.map((d, i) => <option key={i} value={i}>{d}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Time</label>
                <select value={newSlot.time_slot} onChange={e => setNewSlot(s => ({ ...s, time_slot: e.target.value }))}
                  className="w-full border border-gray-200 rounded-lg px-2 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]">
                  {TIME_OPTIONS.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Duration</label>
                <select value={newSlot.duration_mins} onChange={e => setNewSlot(s => ({ ...s, duration_mins: e.target.value }))}
                  className="w-full border border-gray-200 rounded-lg px-2 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]">
                  <option value="30">30 min</option><option value="45">45 min</option><option value="60">60 min</option>
                </select>
              </div>
            </div>
            <button onClick={addSlot} className="flex items-center gap-2 px-4 py-2 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold rounded-lg cursor-pointer">
              <Plus className="w-4 h-4" /> Add Slot
            </button>
          </div>

          <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm">
            <h3 className="font-semibold text-gray-900 mb-4">Available Slots ({slots.length})</h3>
            {slots.length === 0 ? (
              <p className="text-sm text-gray-400">No slots configured. Add slots to let clients see your availability.</p>
            ) : (
              <div className="space-y-2 max-h-[320px] overflow-y-auto">
                {DAYS.map((day, di) => {
                  const daySlots = slots.filter(s => s.day_of_week === di);
                  if (daySlots.length === 0) return null;
                  return (
                    <div key={di}>
                      <p className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">{day}</p>
                      {daySlots.map(slot => (
                        <div key={slot.id} className={`flex items-center gap-3 px-3 py-2 rounded-lg border mb-1 ${slot.active ? 'border-green-200 bg-green-50' : 'border-gray-200 bg-gray-50 opacity-60'}`}>
                          <Clock className="w-3.5 h-3.5 text-gray-400" />
                          <span className="text-sm font-medium text-gray-700">{slot.time_slot}</span>
                          <span className="text-xs text-gray-400">{slot.duration_mins}min</span>
                          <div className="ml-auto flex gap-1">
                            <button onClick={() => toggleSlot(slot)} className={`text-xs px-2 py-1 rounded cursor-pointer ${slot.active ? 'text-yellow-600 hover:bg-yellow-50' : 'text-green-600 hover:bg-green-50'}`}>
                              {slot.active ? 'Disable' : 'Enable'}
                            </button>
                            <button onClick={() => deleteSlot(slot.id)} className="p-1 text-gray-400 hover:text-red-500 cursor-pointer"><X className="w-3 h-3" /></button>
                          </div>
                        </div>
                      ))}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default AppointmentsTab;
