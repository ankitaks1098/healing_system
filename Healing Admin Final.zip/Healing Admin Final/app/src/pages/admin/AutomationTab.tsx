import React, { useState, useEffect, useCallback } from 'react';
import { Plus, Trash2, RefreshCw, Save, Check, X, Zap } from 'lucide-react';

interface Automation {
  id: number;
  name: string;
  trigger_type: string;
  action_type: string;
  action_config: Record<string, string>;
  active: boolean;
  created_at: string;
}

const TRIGGER_LABELS: Record<string, string> = {
  on_registration: '🎯 When someone registers',
};

const ACTION_LABELS: Record<string, string> = {
  send_whatsapp_admin: '📱 Send WhatsApp to Admin',
  send_whatsapp_lead: '💬 Send WhatsApp to Lead',
  add_tag: '🏷 Add Tag to Lead',
  add_to_crm_stage: '📋 Move Lead to CRM Stage',
  send_email_admin: '📧 Send Email to Admin',
  send_email_lead: '📧 Send Email to Lead',
  webhook: '🔗 Send to Webhook URL',
};

const ACTION_COLORS: Record<string, string> = {
  send_whatsapp_admin: 'bg-green-100 text-green-700',
  send_whatsapp_lead: 'bg-green-100 text-green-700',
  add_tag: 'bg-purple-100 text-purple-700',
  add_to_crm_stage: 'bg-blue-100 text-blue-700',
  send_email_admin: 'bg-orange-100 text-orange-700',
  send_email_lead: 'bg-orange-100 text-orange-700',
  webhook: 'bg-gray-100 text-gray-700',
};

const emptyForm = () => ({
  name: '',
  trigger_type: 'on_registration',
  action_type: 'send_whatsapp_admin',
  action_config: {} as Record<string, string>,
  active: true,
});

const AutomationTab: React.FC = () => {
  const [automations, setAutomations] = useState<Automation[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState(emptyForm());
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch('/api/automations');
      setAutomations(await r.json());
    } catch { }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const create = async () => {
    if (!form.name || !form.action_type) return;
    setSaving(true);
    try {
      await fetch('/api/automations', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      setSaved(true);
      setTimeout(() => { setSaved(false); setCreating(false); setForm(emptyForm()); }, 1500);
      load();
    } catch { }
    setSaving(false);
  };

  const toggleActive = async (a: Automation) => {
    await fetch(`/api/automations/${a.id}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ active: !a.active })
    });
    setAutomations(list => list.map(x => x.id === a.id ? { ...x, active: !x.active } : x));
  };

  const deleteAuto = async (id: number) => {
    if (!confirm('Delete this automation?')) return;
    await fetch(`/api/automations/${id}`, { method: 'DELETE' });
    setAutomations(list => list.filter(x => x.id !== id));
  };

  const setConfig = (key: string, val: string) =>
    setForm(f => ({ ...f, action_config: { ...f.action_config, [key]: val } }));

  const renderConfigFields = () => {
    switch (form.action_type) {
      case 'send_whatsapp_admin':
      case 'send_whatsapp_lead':
        return (
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">
              {form.action_type === 'send_whatsapp_admin' ? 'Admin WhatsApp Number' : 'Use lead\'s registered number'}
            </label>
            {form.action_type === 'send_whatsapp_admin' && (
              <input type="text" placeholder="+919876543210" value={form.action_config.number || ''}
                onChange={e => setConfig('number', e.target.value)}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
            )}
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1 mt-3">Message Template</label>
            <textarea rows={3} placeholder="Hi {name}, you have a new lead: {email}"
              value={form.action_config.message || ''}
              onChange={e => setConfig('message', e.target.value)}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B] resize-none" />
            <p className="text-xs text-gray-400 mt-1">Variables: {'{name}'} {'{email}'} {'{whatsapp}'} {'{date}'}</p>
          </div>
        );
      case 'add_tag':
        return (
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Tag to Add</label>
            <input type="text" placeholder="e.g. new-lead, webinar-2025"
              value={form.action_config.tag || ''}
              onChange={e => setConfig('tag', e.target.value)}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
          </div>
        );
      case 'add_to_crm_stage':
        return (
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">CRM Stage</label>
            <select value={form.action_config.stage || 'new'}
              onChange={e => setConfig('stage', e.target.value)}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]">
              <option value="new">New</option>
              <option value="contacted">Contacted</option>
              <option value="interested">Interested</option>
              <option value="follow_up">Follow Up</option>
              <option value="converted">Converted</option>
            </select>
          </div>
        );
      case 'webhook':
        return (
          <div>
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Webhook URL</label>
            <input type="url" placeholder="https://hooks.zapier.com/..."
              value={form.action_config.url || ''}
              onChange={e => setConfig('url', e.target.value)}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
            <p className="text-xs text-gray-400 mt-1">Lead data will be sent as JSON via POST request</p>
          </div>
        );
      case 'send_email_admin':
      case 'send_email_lead':
        return (
          <div>
            {form.action_type === 'send_email_admin' && (
              <>
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Admin Email</label>
                <input type="email" placeholder="you@example.com"
                  value={form.action_config.to || ''}
                  onChange={e => setConfig('to', e.target.value)}
                  className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B] mb-3" />
              </>
            )}
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Email Subject</label>
            <input type="text" placeholder="New lead: {name}"
              value={form.action_config.subject || ''}
              onChange={e => setConfig('subject', e.target.value)}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B] mb-3" />
            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Email Body</label>
            <textarea rows={4} placeholder="Hi {name}, ..."
              value={form.action_config.body || ''}
              onChange={e => setConfig('body', e.target.value)}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B] resize-none" />
            <div className="mt-2 bg-amber-50 border border-amber-100 rounded-lg p-2 text-xs text-amber-700">
              ⚠️ Configure SMTP in Settings tab to enable email sending.
            </div>
          </div>
        );
      default: return null;
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Automation</h2>
          <p className="text-sm text-gray-500 mt-0.5">Automatically trigger actions when leads register</p>
        </div>
        <div className="flex gap-2">
          <button onClick={load} className="p-2 border border-gray-200 rounded-lg text-gray-500 hover:bg-gray-50 cursor-pointer">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button onClick={() => { setCreating(true); setForm(emptyForm()); }}
            className="flex items-center gap-2 px-4 py-2 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold rounded-lg cursor-pointer">
            <Plus className="w-4 h-4" /> New Automation
          </button>
        </div>
      </div>

      {creating && (
        <div className="bg-white border border-gray-200 rounded-xl shadow-sm p-5 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900">Create Automation</h3>
            <button onClick={() => setCreating(false)} className="text-gray-400 hover:text-gray-600 cursor-pointer"><X className="w-4 h-4" /></button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Automation Name</label>
              <input type="text" placeholder="e.g. Notify admin of new lead"
                value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]" />
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Trigger</label>
              <select value={form.trigger_type} onChange={e => setForm(f => ({ ...f, trigger_type: e.target.value }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]">
                {Object.entries(TRIGGER_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide block mb-1">Action</label>
              <select value={form.action_type} onChange={e => setForm(f => ({ ...f, action_type: e.target.value, action_config: {} }))}
                className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#FF3B6B]">
                {Object.entries(ACTION_LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
          </div>

          <div className="bg-gray-50 rounded-xl p-4 mb-4">
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">Action Configuration</p>
            {renderConfigFields()}
          </div>

          <div className="flex gap-2">
            <button onClick={create} disabled={saving || !form.name}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold cursor-pointer transition-all disabled:opacity-60 ${saved ? 'bg-green-500 text-white' : 'bg-[#FF3B6B] hover:bg-[#e02d5a] text-white'}`}>
              {saved ? <><Check className="w-4 h-4" /> Created!</> : saving ? 'Creating…' : <><Save className="w-4 h-4" /> Create Automation</>}
            </button>
            <button onClick={() => setCreating(false)} className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg text-sm cursor-pointer">Cancel</button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-16"><RefreshCw className="w-5 h-5 animate-spin text-[#FF3B6B]" /></div>
      ) : automations.length === 0 ? (
        <div className="bg-white border-2 border-dashed border-gray-200 rounded-xl p-14 text-center">
          <Zap className="w-10 h-10 text-gray-200 mx-auto mb-3" />
          <p className="text-gray-500 font-semibold">No automations yet</p>
          <p className="text-gray-400 text-sm mt-1">Create your first automation to trigger actions when leads register.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {automations.map(a => (
            <div key={a.id} className={`bg-white border rounded-xl p-4 shadow-sm flex items-center gap-4 ${a.active ? 'border-gray-200' : 'border-gray-100 opacity-60'}`}>
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 text-lg ${a.active ? 'bg-[#FF3B6B]/10' : 'bg-gray-100'}`}>
                <Zap className={`w-5 h-5 ${a.active ? 'text-[#FF3B6B]' : 'text-gray-400'}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="font-semibold text-gray-900 text-sm">{a.name}</p>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${a.active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                    {a.active ? '● Active' : '◌ Paused'}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-1 flex-wrap">
                  <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full">{TRIGGER_LABELS[a.trigger_type] || a.trigger_type}</span>
                  <span className="text-gray-300 text-xs">→</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${ACTION_COLORS[a.action_type] || 'bg-gray-100 text-gray-600'}`}>
                    {ACTION_LABELS[a.action_type] || a.action_type}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button onClick={() => toggleActive(a)}
                  className="text-xs px-3 py-1.5 rounded-lg border border-gray-200 hover:bg-gray-50 text-gray-600 cursor-pointer">
                  {a.active ? 'Pause' : 'Resume'}
                </button>
                <button onClick={() => deleteAuto(a.id)} className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg cursor-pointer">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AutomationTab;
