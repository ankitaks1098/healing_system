import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Trash2, RefreshCw, Upload, Copy, Check, Image } from 'lucide-react';

interface MediaFile {
  filename: string;
  url: string;
  size: number;
  created: string;
}

const formatSize = (bytes: number) => {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
};

const MediaTab: React.FC = () => {
  const [files, setFiles] = useState<MediaFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadErr, setUploadErr] = useState('');
  const [copied, setCopied] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch('/api/media');
      const data = await r.json();
      setFiles(data.sort((a: MediaFile, b: MediaFile) => new Date(b.created).getTime() - new Date(a.created).getTime()));
    } catch { }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const upload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    setUploading(true); setUploadErr('');
    try {
      for (const file of Array.from(fileList)) {
        const fd = new FormData();
        fd.append('image', file);
        const res = await fetch('/api/upload', { method: 'POST', body: fd });
        const data = await res.json();
        if (!data.url) setUploadErr(data.error || 'Upload failed');
      }
      await load();
    } catch { setUploadErr('Upload failed. Try again.'); }
    setUploading(false);
    if (inputRef.current) inputRef.current.value = '';
  };

  const deleteFile = async (filename: string) => {
    if (!confirm(`Delete "${filename}"? This cannot be undone.`)) return;
    await fetch(`/api/media/${encodeURIComponent(filename)}`, { method: 'DELETE' });
    setFiles(f => f.filter(x => x.filename !== filename));
  };

  const copyUrl = (url: string, filename: string) => {
    const fullUrl = `${window.location.origin}${url}`;
    navigator.clipboard.writeText(fullUrl).then(() => {
      setCopied(filename);
      setTimeout(() => setCopied(''), 2000);
    });
  };

  const totalSize = files.reduce((sum, f) => sum + f.size, 0);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Media Library</h2>
          <p className="text-sm text-gray-500 mt-0.5">{files.length} files · {formatSize(totalSize)} used</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={load} className="p-2 border border-gray-200 rounded-lg text-gray-500 hover:bg-gray-50 cursor-pointer">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => inputRef.current?.click()}
            disabled={uploading}
            className="flex items-center gap-2 px-4 py-2 bg-[#FF3B6B] hover:bg-[#e02d5a] text-white text-sm font-semibold rounded-lg cursor-pointer transition-all disabled:opacity-60"
          >
            {uploading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
            {uploading ? 'Uploading…' : 'Upload Images'}
          </button>
          <input ref={inputRef} type="file" multiple accept="image/jpeg,image/png,image/webp,image/gif" className="hidden" onChange={upload} />
        </div>
      </div>

      {uploadErr && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">{uploadErr}</div>
      )}

      {/* Upload Zone */}
      <div
        className="border-2 border-dashed border-gray-200 rounded-xl p-8 text-center mb-6 hover:border-[#FF3B6B]/50 hover:bg-rose-50/30 transition-all cursor-pointer"
        onClick={() => inputRef.current?.click()}
        onDragOver={e => e.preventDefault()}
        onDrop={async e => {
          e.preventDefault();
          const dt = e.dataTransfer;
          if (dt.files.length > 0) {
            const fakeEvent = { target: { files: dt.files, value: '' } } as unknown as React.ChangeEvent<HTMLInputElement>;
            await upload(fakeEvent);
          }
        }}
      >
        <Upload className="w-8 h-8 text-gray-300 mx-auto mb-2" />
        <p className="text-sm font-semibold text-gray-500">Click to upload or drag & drop images here</p>
        <p className="text-xs text-gray-400 mt-1">JPG, PNG, WebP, GIF · Max 10MB per file</p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-16"><RefreshCw className="w-5 h-5 animate-spin text-[#FF3B6B]" /></div>
      ) : files.length === 0 ? (
        <div className="text-center py-16">
          <Image className="w-12 h-12 text-gray-200 mx-auto mb-3" />
          <p className="text-gray-500 font-semibold">No images yet</p>
          <p className="text-gray-400 text-sm mt-1">Upload images to use on the landing page</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
          {files.map(file => (
            <div key={file.filename} className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm group hover:shadow-md transition-all">
              <div className="relative aspect-square bg-gray-100">
                <img
                  src={file.url}
                  alt={file.filename}
                  className="w-full h-full object-cover"
                  onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }}
                />
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <button
                    onClick={() => copyUrl(file.url, file.filename)}
                    className="p-2 bg-white rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
                    title="Copy URL"
                  >
                    {copied === file.filename ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4 text-gray-700" />}
                  </button>
                  <button
                    onClick={() => deleteFile(file.filename)}
                    className="p-2 bg-white rounded-lg hover:bg-red-50 cursor-pointer transition-colors"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </button>
                </div>
              </div>
              <div className="p-2">
                <p className="text-xs text-gray-700 font-medium truncate" title={file.filename}>{file.filename}</p>
                <p className="text-xs text-gray-400">{formatSize(file.size)}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MediaTab;
