import { createContext, useContext } from 'react';
import type { SiteContent } from './useSiteContent';
import { DEFAULTS } from './useSiteContent';

interface SiteContentContextType {
  content: SiteContent;
  get: (key: string) => string;
  loading: boolean;
  refetch: () => Promise<void>;
}

export const SiteContentContext = createContext<SiteContentContextType>({
  content: DEFAULTS,
  get: (key: string) => DEFAULTS[key] ?? '',
  loading: false,
  refetch: async () => {},
});

export function useSiteContentContext() {
  return useContext(SiteContentContext);
}
