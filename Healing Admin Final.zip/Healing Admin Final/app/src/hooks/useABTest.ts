import { useState, useEffect, useCallback } from 'react';

export interface ABTest {
  id: number;
  name: string;
  label: string;
  variant_a_text: string;
  variant_b_text: string;
  active: boolean;
}

function getOrCreateSessionId(): string {
  let sid = localStorage.getItem('ab_session_id');
  if (!sid) {
    sid = Math.random().toString(36).slice(2) + Date.now().toString(36);
    localStorage.setItem('ab_session_id', sid);
  }
  return sid;
}

function postEvent(payload: { test_id: number; variant: string; event_type: string; session_id: string }) {
  fetch('/api/ab-events', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  }).catch(() => {});
}

export function useABTest(testName: string): {
  text: string | null;
  variant: 'a' | 'b' | null;
  testId: number | null;
  trackConversion: () => void;
} {
  const [text, setText] = useState<string | null>(null);
  const [variant, setVariant] = useState<'a' | 'b' | null>(null);
  const [testId, setTestId] = useState<number | null>(null);

  useEffect(() => {
    fetch('/api/ab-tests')
      .then(r => r.json())
      .then((tests: ABTest[]) => {
        const test = tests.find(t => t.name === testName && t.active);
        if (!test) return;

        setTestId(test.id);
        const storageKey = `ab_v_${test.id}`;
        let assigned = localStorage.getItem(storageKey) as 'a' | 'b' | null;

        if (!assigned) {
          assigned = Math.random() < 0.5 ? 'a' : 'b';
          localStorage.setItem(storageKey, assigned);
          postEvent({ test_id: test.id, variant: assigned, event_type: 'impression', session_id: getOrCreateSessionId() });
        }

        setVariant(assigned);
        setText(assigned === 'a' ? test.variant_a_text : test.variant_b_text);
      })
      .catch(() => {});
  }, [testName]);

  const trackConversion = useCallback(() => {
    if (!testId || !variant) return;
    const convKey = `ab_conv_${testId}`;
    if (localStorage.getItem(convKey)) return;
    localStorage.setItem(convKey, '1');
    postEvent({ test_id: testId, variant, event_type: 'conversion', session_id: getOrCreateSessionId() });
  }, [testId, variant]);

  return { text, variant, testId, trackConversion };
}

export function trackAllABConversions() {
  const sid = localStorage.getItem('ab_session_id') || getOrCreateSessionId();
  Object.keys(localStorage).forEach(key => {
    if (!key.startsWith('ab_v_')) return;
    const testId = parseInt(key.slice(5));
    if (isNaN(testId)) return;
    const variant = localStorage.getItem(key);
    const convKey = `ab_conv_${testId}`;
    if (localStorage.getItem(convKey)) return;
    localStorage.setItem(convKey, '1');
    postEvent({ test_id: testId, variant: variant || 'a', event_type: 'conversion', session_id: sid });
  });
}
