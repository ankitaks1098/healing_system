import { useState, useEffect, useCallback } from 'react';

interface TimeLeft {
  hours: number;
  minutes: number;
  seconds: number;
}

export function useCountdown(initialMinutes: number = 15): TimeLeft {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>(() => {
    const totalSeconds = initialMinutes * 60;
    return {
      hours: Math.floor(totalSeconds / 3600),
      minutes: Math.floor((totalSeconds % 3600) / 60),
      seconds: totalSeconds % 60,
    };
  });

  const tick = useCallback(() => {
    setTimeLeft((prev) => {
      let totalSeconds = prev.hours * 3600 + prev.minutes * 60 + prev.seconds - 1;
      if (totalSeconds < 0) {
        totalSeconds = initialMinutes * 60;
      }
      return {
        hours: Math.floor(totalSeconds / 3600),
        minutes: Math.floor((totalSeconds % 3600) / 60),
        seconds: totalSeconds % 60,
      };
    });
  }, [initialMinutes]);

  useEffect(() => {
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [tick]);

  return timeLeft;
}
