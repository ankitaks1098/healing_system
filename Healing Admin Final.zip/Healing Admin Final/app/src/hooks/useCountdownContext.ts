import { createContext, useContext } from 'react';

interface TimeLeft {
  hours: number;
  minutes: number;
  seconds: number;
}

export const CountdownContext = createContext<TimeLeft>({
  hours: 0,
  minutes: 15,
  seconds: 0,
});

export function useCountdownContext(): TimeLeft {
  return useContext(CountdownContext);
}
