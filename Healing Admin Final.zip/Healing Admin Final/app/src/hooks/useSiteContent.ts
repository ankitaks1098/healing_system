import { useState, useEffect, useCallback } from 'react';

export interface SiteContent {
  [key: string]: string;
}

const DEFAULTS: SiteContent = {
  announce_text: 'Heal Naturally from the Root — Right from Your Home',
  announce_cta: '1:1 Healing Sessions for Complete Relief',
  hero_badge: 'Revealed: Heal Your Life Problem with Natural Healing',
  hero_headline: 'Heal, Release, and Renew Your Body and Mind — Transform Your Health and Well-being with Energy Healing for All Illnesses, Anytime, Anywhere',
  hero_highlighted: 'Your Health and Well-being',
  hero_subtext: 'Heal the root, not just the body',
  hero_cta1: 'Yes, I Want My Free Healing Session',
  hero_cta2: 'Start My Healing Now',
  hero_cta2_sub: 'Natural healing from the comfort of your home',
  hero_video_url: 'https://www.youtube.com/embed/dQw4w9WgXcQ?rel=0',
  hero_info_1: 'Live Session on Zoom (हिंदी में)',
  hero_info_2: 'First Session is Free ( Limited Time )',
  hero_info_3: '30-45 Minutes',
  about_title: 'About Your Energy Healer',
  about_p1: 'I am Ankit Kumar, a dedicated energy healer committed to helping you heal naturally and deeply. With years of experience in holistic healing practices, I specialize in clearing emotional, physical, and spiritual blockages that cause illness and imbalance.',
  about_p2: 'My healing sessions are personalized and conducted 1-to-1 online, making it easy for you to receive powerful energy healing from the comfort of your home—no matter where you are.',
  about_p3: 'I believe that true healing comes from within, and my mission is to guide you to reconnect with your inner energy, release what no longer serves you, and restore harmony in your body and mind.',
  about_achievement: "I've helped Many people release chronic pain, anxiety, and deep emotional stress and Many Illness through my online sessions.",
  about_cta: 'Book your 1-to-1 online healing session today',
  about_cert_title: 'Certified Reiki Healer',
  midcta_headline: 'When Medicine Fails, Energy Healing Works',
  midcta_subtitle: 'Book your 1-to-1 online healing session today',
  testimonials_title: 'Life-Changing Results with Energy Healing',
  testimonials_subtitle: 'Discover how people healed their body, mind, and soul through natural energy healing 1-to-1 sessions',
  faq_title: 'Frequently Asked Questions (FAQs)',
  finalcta_headline: 'You deserve a healthy, peaceful, and balanced life. Book your free session today and start your healing journey now.',
  finalcta_cta: 'Claim My Free Session',
  finalcta_sub: 'No medicines, no pain – just pure energy healing to treat the root cause of your illness.',
  footer_text: '© 2025 Ankit Kumar. All Rights Reserved | Design by Ankit Kumar Team',
  color_primary: '#FF3B6B',
  color_primary_light: '#FF6B8A',
  color_hero_from: '#4ECDC4',
  color_hero_mid: '#0F4C81',
  color_hero_to: '#1A1A6C',
  color_highlight: '#FFE66D',
  color_announce_from: '#FF3B6B',
  color_announce_to: '#FF6B8A',
  color_btn_from: '#FF3B6B',
  color_btn_to: '#FF6B8A',
  color_about_accent: '#FF3B6B',
  color_midcta_from: '#FF3B6B',
  color_midcta_to: '#FF6B8A',
  color_testimonials_bg_from: '#1A1A2E',
  color_testimonials_bg_to: '#0A0A0A',
  color_benefits_bg_from: '#1A1A2E',
  color_benefits_bg_to: '#0A0A0A',
  color_benefits_accent: '#FF3B6B',
  color_faq_card_bg: '#F0EFFF',
  color_faq_card_border: '#E0D8FF',
  color_faq_icon: '#7C3AED',
  color_footer_bg: '#1A1A2E',
};

export function useSiteContent() {
  const [content, setContent] = useState<SiteContent>(DEFAULTS);
  const [loading, setLoading] = useState(true);

  const fetchContent = useCallback(async () => {
    try {
      const res = await fetch('/api/content');
      if (res.ok) {
        const data: SiteContent = await res.json();
        setContent({ ...DEFAULTS, ...data });
      }
    } catch {
      // fallback to defaults
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchContent();
  }, [fetchContent]);

  const get = (key: string): string => content[key] ?? DEFAULTS[key] ?? '';

  return { content, get, loading, refetch: fetchContent };
}

export { DEFAULTS };
