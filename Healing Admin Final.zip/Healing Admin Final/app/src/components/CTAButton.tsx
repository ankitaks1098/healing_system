import React from 'react';
import { ChevronRight } from 'lucide-react';
import { useModal } from '../hooks/useModal';

interface CTAButtonProps {
  children: React.ReactNode;
  variant?: 'primary' | 'green' | 'large';
  className?: string;
  onClick?: () => void;
}

const CTA_GRADIENT = 'linear-gradient(to right, var(--color-btn-from), var(--color-btn-to))';

const CTAButton: React.FC<CTAButtonProps> = ({ children, variant = 'primary', className = '', onClick }) => {
  const { openModal } = useModal();

  const baseClasses = 'inline-flex items-center justify-center gap-2 font-semibold cursor-pointer transition-all duration-300 ease-out hover:-translate-y-0.5 active:translate-y-0';

  const variantClasses = {
    primary: 'text-white px-8 py-4 rounded-lg text-base shadow-[0_4px_15px_rgba(0,0,0,0.2)] hover:shadow-[0_6px_20px_rgba(0,0,0,0.3)]',
    green: 'bg-[#28A745] text-white px-6 py-2.5 rounded-full text-sm font-semibold hover:bg-[#218838]',
    large: 'text-white px-8 sm:px-12 py-4 sm:py-5 rounded-lg text-lg shadow-[0_4px_15px_rgba(0,0,0,0.2)] hover:shadow-[0_6px_20px_rgba(0,0,0,0.3)]',
  };

  const variantStyle: Record<string, React.CSSProperties> = {
    primary: { background: CTA_GRADIENT },
    green: {},
    large: { background: CTA_GRADIENT },
  };

  const handleClick = () => {
    if (onClick) {
      onClick();
    } else {
      openModal();
    }
  };

  return (
    <button
      onClick={handleClick}
      className={`${baseClasses} ${variantClasses[variant]} ${className}`}
      style={variantStyle[variant]}
    >
      {children}
      <ChevronRight className="w-5 h-5" />
    </button>
  );
};

export default CTAButton;
