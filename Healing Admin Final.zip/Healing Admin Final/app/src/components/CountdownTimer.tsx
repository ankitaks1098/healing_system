import React from 'react';
import { motion } from 'framer-motion';

interface CountdownTimerProps {
  hours: number;
  minutes: number;
  seconds: number;
  variant?: 'large' | 'small';
}

const CountdownTimer: React.FC<CountdownTimerProps> = ({ hours, minutes, seconds, variant = 'large' }) => {
  const isLarge = variant === 'large';

  const formatNumber = (num: number): string => num.toString().padStart(2, '0');

  const boxClass = isLarge
    ? 'min-w-[60px] sm:min-w-[72px] px-3 sm:px-4 py-3 sm:py-4 rounded-lg'
    : 'min-w-[36px] px-2 py-1.5 rounded-md';

  const numberClass = isLarge
    ? 'text-2xl sm:text-4xl font-bold'
    : 'text-sm sm:text-base font-bold';

  const labelClass = isLarge
    ? 'text-xs sm:text-sm mt-1'
    : 'text-[10px] mt-0.5';

  const separatorClass = isLarge
    ? 'text-2xl sm:text-4xl font-bold mx-1 sm:mx-2'
    : 'text-sm sm:text-base font-bold mx-0.5';

  return (
    <div className="flex items-start justify-center gap-1 sm:gap-2">
      {/* Hours */}
      <div className="flex flex-col items-center">
        <motion.div
          key={`h-${hours}`}
          initial={{ opacity: 0.7 }}
          animate={{ opacity: 1 }}
          className={`${boxClass} bg-black/50 text-white text-center`}
        >
          <span className={numberClass}>{formatNumber(hours)}</span>
        </motion.div>
        <span className={`${labelClass} text-white/80`}>Hours</span>
      </div>

      {/* Separator */}
      <span className={`${separatorClass} text-white mt-2 sm:mt-3`}>:</span>

      {/* Minutes */}
      <div className="flex flex-col items-center">
        <motion.div
          key={`m-${minutes}`}
          initial={{ opacity: 0.7 }}
          animate={{ opacity: 1 }}
          className={`${boxClass} bg-black/50 text-white text-center`}
        >
          <span className={numberClass}>{formatNumber(minutes)}</span>
        </motion.div>
        <span className={`${labelClass} text-white/80`}>Minutes</span>
      </div>

      {/* Separator */}
      <span className={`${separatorClass} text-white mt-2 sm:mt-3`}>:</span>

      {/* Seconds */}
      <div className="flex flex-col items-center">
        <motion.div
          key={`s-${seconds}`}
          initial={{ opacity: 0.7 }}
          animate={{ opacity: 1 }}
          className={`${boxClass} bg-black/50 text-white text-center`}
        >
          <span className={numberClass}>{formatNumber(seconds)}</span>
        </motion.div>
        <span className={`${labelClass} text-white/80`}>Seconds</span>
      </div>
    </div>
  );
};

export default React.memo(CountdownTimer);
