import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { useModal } from '../hooks/useModal';
import { useSiteContentContext } from '../hooks/useSiteContentContext';
import { trackAllABConversions } from '../hooks/useABTest';

interface FormData {
  name: string;
  email: string;
  whatsapp: string;
}

const WhatsAppIcon = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white flex-shrink-0" xmlns="http://www.w3.org/2000/svg">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
  </svg>
);

const RegistrationModal: React.FC = () => {
  const { isOpen, closeModal } = useModal();
  const { get } = useSiteContentContext();
  const [formData, setFormData] = useState<FormData>({ name: '', email: '', whatsapp: '' });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleClose = useCallback(() => {
    closeModal();
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ name: '', email: '', whatsapp: '' });
      setError(null);
    }, 300);
  }, [closeModal]);

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) handleClose();
    };
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, handleClose]);

  useEffect(() => {
    if (isOpen) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = '';
    return () => { document.body.style.overflow = ''; };
  }, [isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (error) setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.whatsapp) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'Something went wrong. Please try again.');
      }
      trackAllABConversions();
      setSubmitted(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleJoinWhatsApp = () => {
    const url = get('modal_wa_group_url') || 'https://chat.whatsapp.com/';
    window.open(url, '_blank', 'noopener,noreferrer');
    setTimeout(handleClose, 300);
  };

  const successTitle = get('modal_success_title') || 'Thank You for Registering!';
  const successDesc = get('modal_success_desc') || 'We will contact you on WhatsApp with all the details for your free healing session.';
  const waBtnText = get('modal_wa_btn_text') || 'Join WhatsApp Group';
  const waColorFrom = get('modal_wa_btn_color_from') || '#25D366';
  const waColorTo = get('modal_wa_btn_color_to') || '#128C7E';

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[999] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="absolute inset-0 bg-black/60"
            onClick={handleClose}
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.3 }}
            className="relative bg-white rounded-2xl shadow-[0_20px_60px_rgba(0,0,0,0.3)] w-full max-w-md z-10 overflow-hidden"
          >
            <button
              onClick={handleClose}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 transition-colors cursor-pointer z-10"
            >
              <X className="w-6 h-6" />
            </button>

            <div className="p-6 sm:p-8">
              {!submitted ? (
                <>
                  <h3 className="text-xl sm:text-2xl font-bold text-gray-900 text-center">
                    {get('modal_title') || 'Register for 1 to 1 Healing Session'}
                  </h3>
                  <p className="text-center text-[#FF3B6B] font-semibold mt-2 mb-6">
                    {get('modal_subtitle') || 'FREE Today (Normally Rs. 999)'}
                  </p>

                  <form onSubmit={handleSubmit} className="space-y-3">
                    <input
                      type="text" name="name" placeholder="Name"
                      value={formData.name} onChange={handleChange} required disabled={loading}
                      className="w-full border border-gray-200 rounded-lg px-4 py-3.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B] transition-all disabled:opacity-60"
                    />
                    <input
                      type="email" name="email" placeholder="Email ID"
                      value={formData.email} onChange={handleChange} required disabled={loading}
                      className="w-full border border-gray-200 rounded-lg px-4 py-3.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B] transition-all disabled:opacity-60"
                    />
                    <div className="flex">
                      <div className="flex items-center gap-1 border border-gray-200 border-r-0 rounded-l-lg px-3 bg-gray-50">
                        <span className="text-lg">&#x1F1EE;&#x1F1F3;</span>
                        <span className="text-sm text-gray-500">+91</span>
                      </div>
                      <input
                        type="tel" name="whatsapp" placeholder="Whatsapp No"
                        value={formData.whatsapp} onChange={handleChange} required disabled={loading}
                        className="flex-1 border border-gray-200 rounded-r-lg px-4 py-3.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#FF3B6B]/30 focus:border-[#FF3B6B] transition-all disabled:opacity-60"
                      />
                    </div>

                    {error && <p className="text-red-500 text-sm text-center">{error}</p>}

                    <button
                      type="submit" disabled={loading}
                      className="w-full bg-gradient-to-r from-[#FF3B6B] to-[#FF6B8A] text-white font-bold py-4 rounded-lg text-base hover:shadow-[0_6px_20px_rgba(255,59,107,0.4)] transition-all duration-300 cursor-pointer mt-4 disabled:opacity-70 disabled:cursor-not-allowed"
                    >
                      {loading ? 'Submitting...' : (get('modal_submit_text') || "LET'S GET STARTED")}
                    </button>

                    <p className="text-center text-gray-400 text-xs mt-3">
                      {get('modal_submit_hint') || '( We Will Send you more details on WhatsApp Only )'}
                    </p>
                  </form>

                  <div className="mt-6 pt-4 border-t border-gray-100">
                    <p className="text-center text-sm font-medium text-gray-700">
                      {get('modal_footer_text') || 'Get 30-45 Min FREE powerful ( Worth ₹999 ) and Healing Session to Help in Health.'}
                    </p>
                  </div>
                </>
              ) : (
                /* ── Success / WhatsApp State ── */
                <div className="text-center py-8">
                  {/* WhatsApp icon circle */}
                  <div
                    className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-5 shadow-lg"
                    style={{ background: `linear-gradient(135deg, ${waColorFrom}, ${waColorTo})` }}
                  >
                    <WhatsAppIcon />
                    <svg viewBox="0 0 24 24" className="w-10 h-10 fill-white" xmlns="http://www.w3.org/2000/svg">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                    </svg>
                  </div>

                  <h3 className="text-xl font-bold text-gray-900 mb-2">{successTitle}</h3>
                  <p className="text-gray-600 mb-8 leading-relaxed">{successDesc}</p>

                  {/* WhatsApp Group Join Button */}
                  <button
                    onClick={handleJoinWhatsApp}
                    className="w-full flex items-center justify-center gap-3 text-white font-bold py-4 rounded-xl text-base cursor-pointer transition-all hover:shadow-[0_6px_24px_rgba(37,211,102,0.45)] hover:scale-[1.02] active:scale-[0.98]"
                    style={{ background: `linear-gradient(135deg, ${waColorFrom}, ${waColorTo})` }}
                  >
                    <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white flex-shrink-0" xmlns="http://www.w3.org/2000/svg">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                    </svg>
                    {waBtnText}
                  </button>

                  <button
                    onClick={handleClose}
                    className="mt-3 w-full text-gray-400 hover:text-gray-600 text-sm font-medium py-2 cursor-pointer transition-colors"
                  >
                    No thanks, close
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default RegistrationModal;
