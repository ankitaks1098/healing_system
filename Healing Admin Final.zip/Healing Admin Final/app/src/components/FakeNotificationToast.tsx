import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Flame, X } from 'lucide-react';

interface NotifEntry {
  id: number;
  name: string;
  location: string;
  message: string;
  time_ago: string;
}

interface NotifSettings {
  notif_enabled: string;
  notif_initial_delay: string;
  notif_show_duration: string;
  notif_gap: string;
  notif_icon_color_from: string;
  notif_icon_color_to: string;
  notif_source_name: string;
  notif_position: string;
}

const DEFAULTS: NotifSettings = {
  notif_enabled: 'true',
  notif_initial_delay: '3',
  notif_show_duration: '4',
  notif_gap: '2',
  notif_icon_color_from: '#FF3B6B',
  notif_icon_color_to: '#FF6B8A',
  notif_source_name: 'FlexiFunnels',
  notif_position: 'bottom-left',
};

const FALLBACK: NotifEntry[] = [
  { id: 1, name: 'Ashish Gupta', location: 'Maharashtra', message: 'Registered to Healing Workshop', time_ago: '1 year ago' },
  { id: 2, name: 'Priya Sharma', location: 'Delhi', message: 'Booked a Free Healing Session', time_ago: '2 days ago' },
];

const FakeNotificationToast: React.FC = () => {
  const [entries, setEntries] = useState<NotifEntry[]>([]);
  const [settings, setSettings] = useState<NotifSettings>(DEFAULTS);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);
  const innerTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const mainTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Fetch entries + settings
  useEffect(() => {
    fetch('/api/notifications')
      .then(r => r.ok ? r.json() : [])
      .then((data: NotifEntry[]) => setEntries(data.length > 0 ? data : FALLBACK))
      .catch(() => setEntries(FALLBACK));

    fetch('/api/content')
      .then(r => r.ok ? r.json() : {})
      .then((data: Record<string, string>) => {
        setSettings(s => ({ ...s, ...data }));
      })
      .catch(() => {});
  }, []);

  const enabled = settings.notif_enabled !== 'false';
  const initialDelay = Math.max(1, Number(settings.notif_initial_delay) || 3) * 1000;
  const showDuration = Math.max(1, Number(settings.notif_show_duration) || 4) * 1000;
  const gap = Math.max(0.5, Number(settings.notif_gap) || 2) * 1000;

  // Start the cycle once entries are loaded
  useEffect(() => {
    if (!enabled || entries.length === 0 || dismissed) return;

    mainTimerRef.current = setTimeout(() => {
      setIsVisible(true);
    }, initialDelay);

    return () => {
      if (mainTimerRef.current) clearTimeout(mainTimerRef.current);
    };
  }, [enabled, entries, dismissed, initialDelay]);

  // Cycle through notifications
  useEffect(() => {
    if (!isVisible || entries.length === 0) return;

    const hideTimer = setTimeout(() => {
      setIsVisible(false);
      innerTimerRef.current = setTimeout(() => {
        setCurrentIndex(prev => (prev + 1) % entries.length);
        setIsVisible(true);
      }, gap);
    }, showDuration);

    return () => {
      clearTimeout(hideTimer);
      if (innerTimerRef.current) { clearTimeout(innerTimerRef.current); innerTimerRef.current = null; }
    };
  }, [isVisible, currentIndex, entries.length, showDuration, gap]);

  if (!enabled || entries.length === 0 || dismissed) return null;

  const current = entries[currentIndex];
  const isRight = settings.notif_position === 'bottom-right';

  const posClass = isRight ? 'right-4 left-auto' : 'left-4';

  return (
    <div className={`fixed bottom-4 z-[1000] max-w-[320px] w-[calc(100vw-2rem)] sm:w-auto ${posClass}`}>
      <AnimatePresence mode="wait">
        {isVisible && current && (
          <motion.div
            key={current.id + '-' + currentIndex}
            initial={{ x: isRight ? '120%' : '-120%', opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: isRight ? '120%' : '-120%', opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25, mass: 0.8 }}
            className="bg-white rounded-xl shadow-[0_4px_24px_rgba(0,0,0,0.18)] p-3 flex items-center gap-3 border border-gray-100"
          >
            {/* Avatar */}
            <div
              className="w-11 h-11 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm"
              style={{ background: `linear-gradient(135deg, ${settings.notif_icon_color_from} 0%, ${settings.notif_icon_color_to} 100%)` }}
            >
              <Flame className="w-5 h-5 text-white" />
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <p className="text-[13px] font-semibold text-gray-900 truncate">
                {current.name}{current.location ? `, ${current.location}` : ''}
              </p>
              <p className="text-xs text-gray-500 truncate">{current.message}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-[11px] text-gray-400">{current.time_ago}</span>
                {settings.notif_source_name && (
                  <span className="text-[11px] text-gray-400 flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-green-500 inline-block" />
                    {settings.notif_source_name}
                  </span>
                )}
              </div>
            </div>

            {/* Close button */}
            <button
              onClick={() => setDismissed(true)}
              className="ml-1 p-1 rounded-full text-gray-300 hover:text-gray-500 hover:bg-gray-100 transition-colors cursor-pointer flex-shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default FakeNotificationToast;
