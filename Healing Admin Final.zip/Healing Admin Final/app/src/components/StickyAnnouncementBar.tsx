import React from 'react';
import { useCountdownContext } from '../hooks/useCountdownContext';
import { useModal } from '../hooks/useModal';
import { useSiteContentContext } from '../hooks/useSiteContentContext';

const StickyAnnouncementBar: React.FC = () => {
  const { hours, minutes, seconds } = useCountdownContext();
  const { openModal } = useModal();
  const { get } = useSiteContentContext();

  const formatNumber = (num: number): string => num.toString().padStart(2, '0');

  return (
    <div
      className="fixed top-0 left-0 right-0 z-[100] shadow-md"
      style={{ background: 'linear-gradient(90deg, var(--color-announce-from) 0%, var(--color-announce-to) 100%)' }}
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2 sm:py-3 flex items-center justify-between gap-2 sm:gap-4">
        <p className="text-white font-semibold text-xs sm:text-sm leading-tight flex-shrink-0 max-w-[140px] sm:max-w-none truncate sm:whitespace-normal">
          {get('announce_text')}
        </p>
        <div className="flex items-center gap-1 sm:gap-2 flex-shrink-0">
          {[hours, minutes, seconds].map((val, i) => (
            <React.Fragment key={i}>
              {i > 0 && <span className="text-white text-xs">:</span>}
              <div className="bg-white/20 rounded-md px-1.5 sm:px-2.5 py-1 text-center min-w-[28px] sm:min-w-[36px]">
                <span className="text-white font-bold text-xs sm:text-sm">{formatNumber(val)}</span>
              </div>
            </React.Fragment>
          ))}
        </div>
        <button
          onClick={openModal}
          className="bg-[#28A745] hover:bg-[#218838] text-white text-xs sm:text-sm font-semibold px-3 sm:px-5 py-1.5 sm:py-2 rounded-full transition-colors duration-300 flex-shrink-0 cursor-pointer"
        >
          <span className="hidden sm:inline">{get('announce_cta')}</span>
          <span className="sm:hidden">Book Now</span>
        </button>
      </div>
    </div>
  );
};

export default StickyAnnouncementBar;
