import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { HelpCircle, ChevronDown } from 'lucide-react';

interface FAQAccordionItemProps {
  question: string;
  answer: string;
  isOpen: boolean;
  onClick: () => void;
  index: number;
}

const FAQAccordionItem: React.FC<FAQAccordionItemProps> = ({ question, answer, isOpen, onClick, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
      className="rounded-xl mb-3 overflow-hidden border"
      style={{ background: 'var(--color-faq-card-bg)', borderColor: 'var(--color-faq-card-border)' }}
    >
      <button
        onClick={onClick}
        className="w-full flex items-center justify-between p-5 sm:p-6 text-left cursor-pointer"
      >
        <div className="flex items-center gap-3 flex-1 pr-4">
          <HelpCircle className="w-5 h-5 flex-shrink-0" style={{ color: 'var(--color-faq-icon)' }} />
          <span className="text-base font-semibold text-gray-800">{question}</span>
        </div>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.3 }}
        >
          <ChevronDown className="w-5 h-5 flex-shrink-0" style={{ color: 'var(--color-faq-icon)' }} />
        </motion.div>
      </button>

      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="px-5 sm:px-6 pb-5 sm:pb-6 pt-0">
              <div className="border-t pt-4 ml-8" style={{ borderColor: 'var(--color-faq-card-border)' }}>
                <p className="text-sm text-gray-600 leading-relaxed">{answer}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default FAQAccordionItem;
