import React from 'react';
import { motion } from 'framer-motion';
import { ArrowUp } from 'lucide-react';

interface BenefitCardProps {
  title: string;
  index: number;
}

const BenefitCard: React.FC<BenefitCardProps> = ({ title, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.4, delay: index * 0.08 }}
      whileHover={{ backgroundColor: 'rgba(255,255,255,0.12)' }}
      className="bg-white/5 border border-white/10 rounded-xl p-5 text-center transition-colors duration-300 cursor-default"
    >
      <ArrowUp className="w-4 h-4 mx-auto mb-2" style={{ color: 'var(--color-benefits-accent)' }} />
      <p className="text-sm font-medium text-white leading-snug">{title}</p>
    </motion.div>
  );
};

export default BenefitCard;
