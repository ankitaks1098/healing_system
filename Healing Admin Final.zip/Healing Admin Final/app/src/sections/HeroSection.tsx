import React from 'react';
import { motion } from 'framer-motion';
import { Video, User, Calendar } from 'lucide-react';
import CountdownTimer from '../components/CountdownTimer';
import CTAButton from '../components/CTAButton';
import { useCountdownContext } from '../hooks/useCountdownContext';
import { useSiteContentContext } from '../hooks/useSiteContentContext';
import { useABTest } from '../hooks/useABTest';

const HeroSection: React.FC = () => {
  const { hours, minutes, seconds } = useCountdownContext();
  const { get } = useSiteContentContext();
  const { text: abHeadline } = useABTest('hero_headline');

  const infoIcons = [Video, User, Calendar];
  const infoKeys = ['hero_info_1', 'hero_info_2', 'hero_info_3'];

  const headline = abHeadline ?? get('hero_headline');
  const highlighted = get('hero_highlighted');
  const parts = highlighted && headline.includes(highlighted)
    ? headline.split(highlighted)
    : [headline, ''];

  return (
    <section
      id="hero"
      className="relative min-h-screen pt-20 sm:pt-24"
      style={{ background: 'linear-gradient(135deg, var(--color-hero-from) 0%, var(--color-hero-mid) 50%, var(--color-hero-to) 100%)' }}
    >
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12 sm:py-20">
        <div className="text-center">
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5, delay: 0.2 }}>
            <span className="inline-block bg-white/15 text-white text-sm font-medium px-6 py-2 rounded-full mb-6">
              {get('hero_badge')}
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.35 }}
            className="text-2xl sm:text-4xl md:text-5xl font-bold text-white leading-tight mb-4"
          >
            {parts[0]}
            {highlighted && <span style={{ color: 'var(--color-highlight)' }}>{highlighted}</span>}
            {parts[1]}
          </motion.h1>

          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5, delay: 0.5 }} className="mt-8">
            <CountdownTimer hours={hours} minutes={minutes} seconds={seconds} variant="large" />
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.7 }} className="mt-8">
            <CTAButton variant="large">{get('hero_cta1')}</CTAButton>
            <p className="text-white/70 text-sm mt-3">{get('hero_subtext')}</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.9 }}
            className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center max-w-4xl mx-auto"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-[0_8px_30px_rgba(0,0,0,0.2)] bg-black/20 aspect-video">
              <iframe
                src={get('hero_video_url')}
                title="Healing Introduction"
                className="absolute inset-0 w-full h-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
            <div className="flex flex-col gap-6 text-left lg:pl-4">
              {infoKeys.map((key, index) => {
                const Icon = infoIcons[index];
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4, delay: 1.0 + index * 0.1 }}
                    className="flex items-center gap-4"
                  >
                    <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center flex-shrink-0">
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-white font-medium text-base">{get(key)}</span>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 1.1 }} className="mt-10">
            <CTAButton variant="primary">{get('hero_cta2')}</CTAButton>
            <p className="text-white/70 text-sm mt-3">{get('hero_cta2_sub')}</p>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
