import React from 'react';
import { motion } from 'framer-motion';
import { ChevronRight } from 'lucide-react';
import { useModal } from '../hooks/useModal';
import { useSiteContentContext } from '../hooks/useSiteContentContext';

const MidCTASection: React.FC = () => {
  const { openModal } = useModal();
  const { get } = useSiteContentContext();

  return (
    <section
      className="cursor-pointer"
      style={{ background: 'linear-gradient(135deg, var(--color-midcta-from) 0%, var(--color-midcta-to) 100%)' }}
      onClick={openModal}
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.5, ease: 'easeOut' }}
        className="max-w-4xl mx-auto px-4 sm:px-6 py-10 text-center"
      >
        <div className="group inline-flex items-center gap-2">
          <h3 className="text-xl sm:text-2xl font-bold text-white">{get('midcta_headline')}</h3>
          <motion.div className="inline-flex" whileHover={{ x: 5 }} transition={{ duration: 0.3 }}>
            <ChevronRight className="w-6 h-6 text-white group-hover:translate-x-1 transition-transform duration-300" />
          </motion.div>
        </div>
        <p className="text-white/80 text-sm mt-2">{get('midcta_subtitle')}</p>
      </motion.div>
    </section>
  );
};

export default MidCTASection;
