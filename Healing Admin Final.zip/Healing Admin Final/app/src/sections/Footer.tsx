import React from 'react';
import { useSiteContentContext } from '../hooks/useSiteContentContext';

const Footer: React.FC = () => {
  const { get } = useSiteContentContext();

  return (
    <footer className="py-6" style={{ background: 'var(--color-footer-bg)' }}>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 text-center">
        <p className="text-sm text-white/60">{get('footer_text')}</p>
      </div>
    </footer>
  );
};

export default Footer;
