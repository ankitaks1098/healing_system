import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import FAQAccordionItem from '../components/FAQAccordionItem';
import { useSiteContentContext } from '../hooks/useSiteContentContext';

interface FAQ { id?: number; question: string; answer: string; }

const DEFAULT_FAQS: FAQ[] = [
  { question: 'Is the first healing session really free?', answer: 'Yes! Your first session is completely free — no hidden costs or commitments. Just experience the energy and decide for yourself.' },
  { question: 'What is energy healing and how does it work?', answer: "Energy healing is a natural and holistic process that clears blockages and restores balance to your energy system. It helps activate the body's natural ability to heal physically, emotionally, and spiritually." },
  { question: 'Can energy healing help with physical illnesses?', answer: "Yes, many people experience relief from chronic pain, fatigue, and other physical conditions. While it's not a replacement for medical treatment, it complements it by supporting the healing process from the root level." },
  { question: 'What types of issues can I book a healing session for?', answer: 'You can book a session for any physical, emotional, or spiritual challenge — like body pain, stress, anxiety, trauma, relationship issues, energy blockages, or even personal growth and spiritual awakening.' },
  { question: 'How many sessions will I need?', answer: 'It depends on your issue. Some people feel results after one session, while others may need a few more for deeper healing. We recommend starting with one session and continuing based on progress.' },
  { question: 'Can I book healing for my family member or friend?', answer: 'Yes, you can book on behalf of someone — just make sure they are aware and give permission to receive the healing.' },
];

const FAQSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const [faqs, setFaqs] = useState<FAQ[]>(DEFAULT_FAQS);
  const { get } = useSiteContentContext();

  useEffect(() => {
    fetch('/api/faqs')
      .then(r => r.ok ? r.json() : null)
      .then(data => { if (data && data.length > 0) setFaqs(data); })
      .catch(() => {});
  }, []);

  return (
    <section id="faq" className="bg-white py-16 sm:py-20">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5 }}
          className="text-2xl sm:text-4xl font-bold text-gray-900 text-center mb-10"
        >
          {get('faq_title')}
        </motion.h2>
        <div>
          {faqs.map((faq, index) => (
            <FAQAccordionItem
              key={faq.id ?? index}
              question={faq.question}
              answer={faq.answer}
              isOpen={openIndex === index}
              onClick={() => setOpenIndex(openIndex === index ? null : index)}
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
