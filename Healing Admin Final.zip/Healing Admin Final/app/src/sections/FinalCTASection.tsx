import React from 'react';
import { motion } from 'framer-motion';
import CTAButton from '../components/CTAButton';
import { useSiteContentContext } from '../hooks/useSiteContentContext';

const FinalCTASection: React.FC = () => {
  const { get } = useSiteContentContext();

  return (
    <section className="bg-white py-16 sm:py-20">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 text-center">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5 }}
          className="text-2xl sm:text-3xl font-bold text-gray-900 leading-snug mb-8"
        >
          {get('finalcta_headline')}
        </motion.h2>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <CTAButton variant="large">{get('finalcta_cta')}</CTAButton>
          <p className="text-gray-500 text-sm mt-4">{get('finalcta_sub')}</p>
        </motion.div>
      </div>
    </section>
  );
};

export default FinalCTASection;
