import React from 'react';
import { motion } from 'framer-motion';
import CTAButton from '../components/CTAButton';
import { useSiteContentContext } from '../hooks/useSiteContentContext';

const AboutSection: React.FC = () => {
  const { get } = useSiteContentContext();

  return (
    <section id="about" className="relative bg-white">
      <div className="border-t-2 border-dashed" style={{ borderColor: 'var(--color-about-accent)' }} />
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-16 sm:py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
          >
            <h2 className="text-2xl sm:text-4xl font-bold text-gray-900 mb-6">{get('about_title')}</h2>
            <div className="space-y-4 text-gray-600 leading-relaxed">
              <p>{get('about_p1')}</p>
              <p>{get('about_p2')}</p>
              <p>{get('about_p3')}</p>
            </div>
            <div className="mt-6 border-l-4 pl-4" style={{ borderColor: 'var(--color-about-accent)' }}>
              <p className="text-base font-semibold text-gray-800">{get('about_achievement')}</p>
            </div>
            <div className="lg:hidden mt-8">
              <img
                src={get('about_portrait_url') || '/images/healer-portrait.jpg'}
                alt="Ankit Kumar - Energy Healer"
                className="w-full max-w-sm mx-auto rounded-3xl shadow-[0_8px_30px_rgba(0,0,0,0.12)] object-cover aspect-[3/4]"
                loading="lazy"
              />
            </div>
            <div className="mt-8">
              <CTAButton variant="primary">{get('about_cta')}</CTAButton>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: 0.2, ease: 'easeOut' }}
            className="hidden lg:block"
          >
            <img
              src={get('about_portrait_url') || '/images/healer-portrait.jpg'}
              alt="Ankit Kumar - Energy Healer"
              className="w-full rounded-3xl shadow-[0_8px_30px_rgba(0,0,0,0.12)] object-cover aspect-[3/4]"
              loading="lazy"
            />
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, amount: 0.2 }}
          transition={{ duration: 0.6, delay: 0.3, ease: 'easeOut' }}
          className="mt-16 text-center"
        >
          <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-6">{get('about_cert_title')}</h3>
          <div className="inline-block border-4 border-[#FFD700] rounded-2xl overflow-hidden shadow-[0_8px_30px_rgba(0,0,0,0.15)] max-w-sm mx-auto">
            <img src={get('about_cert_url') || '/images/certificate.jpg'} alt="Reiki Healer Certification" className="w-full" loading="lazy" />
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default AboutSection;
