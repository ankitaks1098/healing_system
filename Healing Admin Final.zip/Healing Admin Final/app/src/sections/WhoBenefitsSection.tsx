import React from 'react';
import { motion } from 'framer-motion';
import BenefitCard from '../components/BenefitCard';

const benefits = [
  'Physical Illness & Pain Sufferers',
  'Emotional & Mental Health',
  'Stress & Burnout Recovery',
  'Life Transition & Personal Growth Seekers',
  'Addiction & Negative Habit Recovery',
  'Holistic Wellness & Preventive Healing',
  'Anyone who want to heal Yourself (Problem do not know)',
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.08,
    },
  },
};

const WhoBenefitsSection: React.FC = () => {
  return (
    <section
      id="benefits"
      style={{
        background: 'linear-gradient(180deg, var(--color-benefits-bg-from) 0%, var(--color-benefits-bg-to) 100%)',
      }}
    >
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-16 sm:py-20">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-10"
        >
          <h2 className="text-2xl sm:text-4xl font-bold text-white mb-3">
            Who Will Benefit the Most from This Workshop?
          </h2>
          <p className="text-base text-white/70 max-w-2xl mx-auto">
            No matter what you're struggling with — pain, stress, or emotional imbalance — energy
            healing brings relief from the inside out.
          </p>
        </motion.div>

        {/* Benefits Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {benefits.map((benefit, index) => (
            <BenefitCard key={index} title={benefit} index={index} />
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default WhoBenefitsSection;
