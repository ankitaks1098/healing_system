import React from 'react';
import { motion } from 'framer-motion';
import FeatureCard from '../components/FeatureCard';
import CountdownTimer from '../components/CountdownTimer';
import CTAButton from '../components/CTAButton';
import { useCountdownContext } from '../hooks/useCountdownContext';
import { useSiteContentContext } from '../hooks/useSiteContentContext';

const DEFAULTS = [
  { image: '/images/emotional-blocks.jpg', title: 'Release Emotional Blocks', description: 'Healing starts by freeing trapped emotions in your energy.' },
  { image: '/images/root-cause.jpg', title: 'Target the Root Cause', description: 'Energy healing fixes the cause, not just the symptoms.' },
  { image: '/images/heal-from-anywhere.jpg', title: 'Heal from Anywhere', description: 'Experience powerful energy healing online, no matter where you are.' },
];

const SecretsSection: React.FC = () => {
  const { hours, minutes, seconds } = useCountdownContext();
  const { get } = useSiteContentContext();

  const secrets = DEFAULTS.map((d, i) => ({
    image: get(`secrets_img_${i + 1}_url`) || d.image,
    title: get(`secrets_title_${i + 1}`) || d.title,
    description: get(`secrets_desc_${i + 1}`) || d.description,
  }));

  return (
    <section id="secrets" className="bg-white py-16 sm:py-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5 }}
          className="text-2xl sm:text-4xl font-bold text-gray-900 text-center max-w-3xl mx-auto mb-10"
        >
          Discover the 3 Hidden Secrets Most Doctors Never Tell You About Real Healing
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {secrets.map((secret, index) => (
            <FeatureCard
              key={index}
              image={secret.image}
              title={secret.title}
              description={secret.description}
              index={index}
            />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-12 text-center"
        >
          <CountdownTimer hours={hours} minutes={minutes} seconds={seconds} />
          <div className="mt-6">
            <CTAButton variant="primary">Tired of Illness? Get Relief Naturally</CTAButton>
            <p className="text-gray-500 text-sm mt-3">Heal your body, mind, and soul together</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default SecretsSection;
