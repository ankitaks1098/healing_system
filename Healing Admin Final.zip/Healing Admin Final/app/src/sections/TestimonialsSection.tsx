import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useSiteContentContext } from '../hooks/useSiteContentContext';

interface Testimonial {
  id: number;
  name: string;
  role: string;
  problem: string;
  type: 'text' | 'image' | 'whatsapp';
  content: string;
  image_url: string;
  sort_order: number;
  active: boolean;
}

const TestimonialsSection: React.FC = () => {
  const { get } = useSiteContentContext();
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);

  useEffect(() => {
    fetch('/api/testimonials')
      .then(r => r.ok ? r.json() : [])
      .then(data => setTestimonials(data))
      .catch(() => {});
  }, []);

  return (
    <section id="testimonials" style={{ background: 'linear-gradient(180deg, var(--color-testimonials-bg-from) 0%, var(--color-testimonials-bg-to) 100%)' }}>
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16 sm:py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.3 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-10"
        >
          <h2 className="text-2xl sm:text-4xl font-bold text-white mb-3">{get('testimonials_title')}</h2>
          <p className="text-base text-white/70 max-w-2xl mx-auto">{get('testimonials_subtitle')}</p>
        </motion.div>

        {testimonials.length === 0 ? (
          <p className="text-white/40 text-center py-10">No testimonials yet.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {testimonials.map((t, i) => (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.2 }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                className="rounded-2xl overflow-hidden shadow-[0_8px_30px_rgba(0,0,0,0.3)]"
              >
                {t.type === 'image' ? (
                  <div className="bg-black/30">
                    <div className="relative aspect-[9/16] max-h-[500px]">
                      <img
                        src={t.image_url}
                        alt={t.name}
                        className="w-full h-full object-cover"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                      <div className="absolute bottom-4 left-4 right-4">
                        {t.problem && <p className="text-white font-semibold text-sm">Problem Solved: {t.problem}</p>}
                        <p className="text-white/80 text-xs mt-1">{t.name}</p>
                        {t.role && <p className="text-white/60 text-xs">({t.role})</p>}
                      </div>
                    </div>
                  </div>
                ) : t.type === 'whatsapp' ? (
                  <div className="bg-[#0B141A] p-4 min-h-[500px] flex flex-col">
                    <div className="bg-[#1F2C34] -mx-4 -mt-4 px-4 py-3 flex items-center gap-3 mb-4">
                      <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center">
                        <span className="text-white text-xs font-bold">{t.name.charAt(0)}</span>
                      </div>
                      <div>
                        <p className="text-white text-sm font-medium">{t.name}</p>
                        <p className="text-green-400 text-xs">online</p>
                      </div>
                    </div>
                    <div className="flex-1 space-y-3">
                      <div className="flex justify-start">
                        <div className="bg-[#1F2C34] text-white rounded-lg rounded-tl-none px-3 py-2 max-w-[85%]">
                          <p className="text-sm">{t.content}</p>
                          <span className="text-gray-500 text-[10px] float-right mt-1 ml-2">10:30 AM</span>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 pt-3 border-t border-white/10">
                      {t.problem && <p className="text-white font-semibold text-sm">Problem Solved: {t.problem}</p>}
                      <p className="text-white/70 text-xs mt-1">{t.name}</p>
                    </div>
                  </div>
                ) : (
                  <div className="bg-[#1F2C34] p-6 min-h-[300px] flex flex-col justify-between">
                    <div>
                      <div className="w-10 h-10 rounded-full bg-[#FF3B6B]/20 flex items-center justify-center mb-4">
                        <span className="text-[#FF3B6B] font-bold text-lg">{t.name.charAt(0)}</span>
                      </div>
                      <p className="text-white/90 text-sm leading-relaxed">"{t.content}"</p>
                    </div>
                    <div className="mt-4 pt-4 border-t border-white/10">
                      <p className="text-white font-semibold text-sm">{t.name}</p>
                      {t.role && <p className="text-white/60 text-xs">{t.role}</p>}
                      {t.problem && <p className="text-[#FF3B6B] text-xs mt-1">✓ Problem Solved: {t.problem}</p>}
                    </div>
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default TestimonialsSection;
