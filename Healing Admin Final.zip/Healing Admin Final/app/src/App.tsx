import React, { useEffect } from 'react';
import { Routes, Route } from 'react-router';
import { ModalContext, useModalState } from './hooks/useModal';
import { CountdownContext } from './hooks/useCountdownContext';
import { SiteContentContext, useSiteContentContext } from './hooks/useSiteContentContext';
import { useCountdown } from './hooks/useCountdown';
import { useSiteContent } from './hooks/useSiteContent';
import StickyAnnouncementBar from './components/StickyAnnouncementBar';
import RegistrationModal from './components/RegistrationModal';
import FakeNotificationToast from './components/FakeNotificationToast';
import HeroSection from './sections/HeroSection';
import AboutSection from './sections/AboutSection';
import MidCTASection from './sections/MidCTASection';
import TestimonialsSection from './sections/TestimonialsSection';
import SecretsSection from './sections/SecretsSection';
import WhoBenefitsSection from './sections/WhoBenefitsSection';
import FAQSection from './sections/FAQSection';
import FinalCTASection from './sections/FinalCTASection';
import Footer from './sections/Footer';
import AdminPage from './pages/Admin';

/* Applies color theme CSS variables from site_content to :root */
const ThemeInjector: React.FC = () => {
  const { get } = useSiteContentContext();
  useEffect(() => {
    const r = document.documentElement;
    r.style.setProperty('--color-primary', get('color_primary') || '#FF3B6B');
    r.style.setProperty('--color-primary-light', get('color_primary_light') || '#FF6B8A');
    r.style.setProperty('--color-hero-from', get('color_hero_from') || '#4ECDC4');
    r.style.setProperty('--color-hero-mid', get('color_hero_mid') || '#0F4C81');
    r.style.setProperty('--color-hero-to', get('color_hero_to') || '#1A1A6C');
    r.style.setProperty('--color-highlight', get('color_highlight') || '#FFE66D');
    r.style.setProperty('--color-announce-from', get('color_announce_from') || '#FF3B6B');
    r.style.setProperty('--color-announce-to', get('color_announce_to') || '#FF6B8A');
    r.style.setProperty('--color-btn-from', get('color_btn_from') || '#FF3B6B');
    r.style.setProperty('--color-btn-to', get('color_btn_to') || '#FF6B8A');
    r.style.setProperty('--color-about-accent', get('color_about_accent') || '#FF3B6B');
    r.style.setProperty('--color-midcta-from', get('color_midcta_from') || '#FF3B6B');
    r.style.setProperty('--color-midcta-to', get('color_midcta_to') || '#FF6B8A');
    r.style.setProperty('--color-testimonials-bg-from', get('color_testimonials_bg_from') || '#1A1A2E');
    r.style.setProperty('--color-testimonials-bg-to', get('color_testimonials_bg_to') || '#0A0A0A');
    r.style.setProperty('--color-benefits-bg-from', get('color_benefits_bg_from') || '#1A1A2E');
    r.style.setProperty('--color-benefits-bg-to', get('color_benefits_bg_to') || '#0A0A0A');
    r.style.setProperty('--color-benefits-accent', get('color_benefits_accent') || '#FF3B6B');
    r.style.setProperty('--color-faq-card-bg', get('color_faq_card_bg') || '#F0EFFF');
    r.style.setProperty('--color-faq-card-border', get('color_faq_card_border') || '#E0D8FF');
    r.style.setProperty('--color-faq-icon', get('color_faq_icon') || '#7C3AED');
    r.style.setProperty('--color-footer-bg', get('color_footer_bg') || '#1A1A2E');
  }, [get]);
  return null;
};

/* Injects FB Pixel + GA4 scripts dynamically from site_content settings */
const TrackingScripts: React.FC = () => {
  useEffect(() => {
    fetch('/api/content')
      .then(r => r.json())
      .then((d: Record<string, string>) => {
        // Facebook Pixel
        if (d.fb_pixel_enabled === 'true' && d.fb_pixel_id) {
          if (!document.getElementById('fb-pixel-script')) {
            const s = document.createElement('script');
            s.id = 'fb-pixel-script';
            s.innerHTML = `
              !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
              n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
              n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
              t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}
              (window,document,'script','https://connect.facebook.net/en_US/fbevents.js');
              fbq('init','${d.fb_pixel_id}');fbq('track','PageView');
            `;
            document.head.appendChild(s);
          }
        }
        // Google Analytics 4
        if (d.ga_enabled === 'true' && d.ga_id) {
          if (!document.getElementById('ga-script')) {
            const s = document.createElement('script');
            s.id = 'ga-script';
            s.async = true;
            s.src = `https://www.googletagmanager.com/gtag/js?id=${d.ga_id}`;
            document.head.appendChild(s);
            const s2 = document.createElement('script');
            s2.id = 'ga-init-script';
            s2.innerHTML = `window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${d.ga_id}');`;
            document.head.appendChild(s2);
          }
        }
        // Custom head code
        if (d.custom_head_enabled === 'true' && d.custom_head_code) {
          if (!document.getElementById('custom-head-code')) {
            const wrapper = document.createElement('div');
            wrapper.id = 'custom-head-code';
            wrapper.innerHTML = d.custom_head_code;
            Array.from(wrapper.children).forEach(child => document.head.appendChild(child));
          }
        }
      })
      .catch(() => {});
  }, []);
  return null;
};

const LandingPage: React.FC = () => {
  const modalState = useModalState();
  const countdown = useCountdown(15);

  return (
    <ModalContext.Provider value={modalState}>
      <CountdownContext.Provider value={countdown}>
        <TrackingScripts />
        <StickyAnnouncementBar />
        <main className="pt-12 sm:pt-14">
          <HeroSection />
          <AboutSection />
          <MidCTASection />
          <TestimonialsSection />
          <SecretsSection />
          <WhoBenefitsSection />
          <FAQSection />
          <FinalCTASection />
          <Footer />
        </main>
        <RegistrationModal />
        <FakeNotificationToast />
      </CountdownContext.Provider>
    </ModalContext.Provider>
  );
};

const AppWithContent: React.FC = () => {
  const siteContent = useSiteContent();
  return (
    <SiteContentContext.Provider value={siteContent}>
      <ThemeInjector />
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/admin" element={<AdminPage />} />
      </Routes>
    </SiteContentContext.Provider>
  );
};

export default AppWithContent;
